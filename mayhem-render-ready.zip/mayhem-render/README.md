# MAYHEM — Render Ready

## Local
npm install
npm start

Open http://127.0.0.1:10000

## Render
Connect this folder/repository as a Render Web Service.
Build: npm install
Start: npm start
Plan: Free (testing).

The server uses process.env.PORT and binds to 0.0.0.0.

IMPORTANT: data/db.json is for testing. Render Free has an ephemeral filesystem, so local database changes can disappear after restart/redeploy/spin-down. Use a persistent database for real online data.
