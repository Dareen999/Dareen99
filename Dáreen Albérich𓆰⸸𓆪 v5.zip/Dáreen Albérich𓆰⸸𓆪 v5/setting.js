const fs = require('fs')
const chalk = require('chalk')
const Styles = (text, style = 1) => {
  var xStr = 'abcdefghijklmnopqrstuvwxyz1234567890'.split('');
  var yStr = {
    1: 'ᴀʙᴄᴅᴇꜰɢʜɪᴊᴋʟᴍɴᴏᴘqʀꜱᴛᴜᴠᴡxʏᴢ1234567890'
  };
  var replacer = [];
  xStr.map((v, i) =>
    replacer.push({
      original: v,
      convert: yStr[style].split('')[i]
    })
  );
  var str = text.toLowerCase().split('');
  var output = [];
  str.map((v) => {
    const find = replacer.find((x) => x.original == v);
    find ? output.push(find.convert) : output.push(v);
  });
  return output.join('');
};

global.namaowner = "Dáreen Albérich𓆰⸸𓆪"
global.owner = "6285156726377"
global.namabot = "Dáreen Albérich𓆰⸸𓆪"
global.botname = "Dáreen Albérich𓆰⸸𓆪"
global.autoJoin = false
global.domain = "https://kykoxdarenn.sevsbotz.xyz"
global.apikey = "ptla_lWf8eKK3lsrixrnOEvF2ketSSrFeSnUDXRgIbtODEfv"
global.capikey = "ptlc_7ruyChqlPeLBtkgjsSUzv4ka7eEoj94t6w8Gb4Ws7wc"
global.eggsnya = '17' // id eggs yang dipakai
global.location = '1' // id location
global.zanss = fs.readFileSync("./database/menu.mp4")
global.codeInvite = "FwtMxovJqW3Jj55x524hjT"
global.sessionName = 'Dáreen Albérich𓆰⸸𓆪' //Gausah Juga
global.save = "Dáreen Albérich𓆰⸸𓆪"
global.keyopenai = `sk-proj-EXdCaNbBfwrOJaqCjcTDT3BlbkFJyFvdbMAMopdT2vaEhuZj`
global.tekspushkon = ""
global.tekspushkonv2 = ""
global.packname = ""
global.author = "Dáreen Albérich𓆰⸸𓆪"

global.namastore = "Dáreen Albérich𓆰⸸𓆪"
global.dana = "6285156726377" // NOMER DANA KAMU
global.gopay = "6283147744531" // NOMER GOPAY KAMU
global.ovo = "6283147744531" // NOMER OVO KAMU
global.shp = "6283147744531" // NOMER SHOPE KAMU
global.qris = fs.readFileSync("./dareen/qris.jpg")
require("./database/youtube.js")

global.autojpmm = `JOIN SINI BANG

LINK LU : https://chat.whatsapp.com/invite/ISepEHtHpUOBKNV6PSIiFF`// TEXT JPM LU

const mess = {
   wait: "Bentar ya bre..",
   success: "Berhasil, bang✔",
   save: "𝕊𝕌𝕂𝕊𝔼𝕊 𝕊𝔸𝕍𝔼 ℕ𝕆𝕄𝔼ℝ 𝕆𝕋𝕆𝕄𝔸𝕋𝕀𝕊",
   on: "Sudah Aktif", 
   off: "Sudah Off",
   query: {
       text: "Teks Nya Mana Kak?",
       link: "Link Nya Mana Kak?",
   },
   error: {
       fitur: "Mohon Maaf Kak Fitur Eror Silahkan Chat Developer Bot Agar Bisa Segera Diperbaiki",
   },
   only: {
       group: "Fitur Nya Cuman Bisa Di Dalem Grup Yah Bang",
       private: "Di Chat Pribadi Bang Thomz Biar Bisa Di Pake",
       owner: "Ga Usah Pake Fitur Ini Asu Lu Bukan Bang Dáreen Albérich𓆰⸸𓆪",
       admin: "Ga Usah Pake Fitur Ini Asu Lu Bukan Admin",
       badmin: "Maaf Kak Kaya Nya Kakak Tidak Bisa Menggunakan Fitur Ini Di Karenakan Bot Bukan Admin Group",
       premium: "Only Premium and murbug",
   }
}

global.mess = mess
//=================================================//
//Gausah Juga
global.limitawal = {
    premium: "Infinity",
    free: 100
}
//=================================================//
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})